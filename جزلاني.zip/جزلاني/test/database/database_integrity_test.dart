// ignore_for_file: avoid_print

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/database/app_database.dart';
import 'package:my_finance/core/database/transactions/financial_transaction_engine.dart';

/// ── مساعد: بناء قاعدة بيانات اختبار في الذاكرة ─────────────────────────────
AppDatabase buildTestDatabase() =>
    AppDatabase(NativeDatabase.memory());

/// ── مساعد: إنشاء حساب تجريبي بمبلغ افتراضي ─────────────────────────────────
Future<AccountEntry> seedAccount(
  AppDatabase db, {
  String id = 'acc-01',
  int balanceMinorUnits = 1000000, // 10,000.00 ر.س
}) async {
  await db.accountsDao.insertAccount(AccountsCompanion.insert(
    id: id,
    name: 'حساب الاختبار',
    type: 'bank',
    colorHex: '#0E3B2E',
    iconName: 'bank',
    balanceMinorUnits: Value(balanceMinorUnits),
    createdAt: DateTime.now(),
    updatedAt: DateTime.now(),
  ));
  return (await db.accountsDao.getAccountById(id))!;
}

void main() {
  // ── مجموعة 1: إنشاء قاعدة البيانات والجداول ────────────────────────────────
  group('DB-01 — إنشاء قاعدة البيانات والجداول', () {
    test('يُنشئ قاعدة البيانات بدون أخطاء', () async {
      final db = buildTestDatabase();
      // مجرد البناء والاستعلام الأول كافيان للتحقق
      final accounts = await db.accountsDao.watchActiveAccounts().first;
      expect(accounts, isEmpty);
      await db.close();
    });

    test('PRAGMA foreign_keys مفعّل', () async {
      final db = buildTestDatabase();
      final result = await db
          .customSelect('PRAGMA foreign_keys;')
          .map((r) => r.read<int>('foreign_keys'))
          .get();
      expect(result.first, equals(1));
      await db.close();
    });
  });

  // ── مجموعة 2: عمليات الحسابات CRUD ─────────────────────────────────────────
  group('DB-02 — الحسابات والمحافظ (AccountsDao)', () {
    late AppDatabase db;
    setUp(() => db = buildTestDatabase());
    tearDown(() => db.close());

    test('إضافة واسترجاع حساب', () async {
      await db.accountsDao.insertAccount(AccountsCompanion.insert(
        id: 'acc-test',
        name: 'راجحي الجاري',
        type: 'bank',
        colorHex: '#0E3B2E',
        iconName: 'bank',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ));
      final account = await db.accountsDao.getAccountById('acc-test');
      expect(account, isNotNull);
      expect(account!.name, equals('راجحي الجاري'));
      expect(account.balanceMinorUnits, equals(0));
    });

    test('أرشفة الحساب بدلاً من الحذف', () async {
      await seedAccount(db);
      await db.accountsDao.archiveAccount('acc-01');
      final active = await db.accountsDao.watchActiveAccounts().first;
      expect(active, isEmpty);
      // الحساب لا يزال موجوداً في قاعدة البيانات
      final archived = await db.accountsDao.getAccountById('acc-01');
      expect(archived, isNotNull);
      expect(archived!.isArchived, isTrue);
    });

    test('حساب مجموع الأرصدة النشطة', () async {
      await seedAccount(db, id: 'acc-a', balanceMinorUnits: 500000);
      await seedAccount(db, id: 'acc-b', balanceMinorUnits: 300000);
      final total = await db.accountsDao.getTotalBalanceMinorUnits();
      expect(total, equals(800000));
    });
  });

  // ── مجموعة 3: نزاهة التمثيل المالي ──────────────────────────────────────────
  group('DB-03 — دقة تمثيل المبالغ المالية (Minor Units)', () {
    late AppDatabase db;
    setUp(() => db = buildTestDatabase());
    tearDown(() => db.close());

    test('مبلغ 1,250.75 ر.س يُخزَّن ويُسترجع بدقة كاملة', () async {
      const amountMinorUnits = 125075; // 1250.75 ر.س بالهللات
      await seedAccount(db, balanceMinorUnits: amountMinorUnits);
      final account = await db.accountsDao.getAccountById('acc-01');
      expect(account!.balanceMinorUnits, equals(amountMinorUnits));
      // التحويل للعرض بدون خطأ floating point
      final displayValue = account.balanceMinorUnits / 100.0;
      expect(displayValue, closeTo(1250.75, 0.001));
    });

    test('تخزين مبالغ كبيرة (مليارات) بدون integer overflow', () async {
      const largeAmount = 50000000000; // 500,000,000.00 ر.س
      await seedAccount(db, balanceMinorUnits: largeAmount);
      final account = await db.accountsDao.getAccountById('acc-01');
      expect(account!.balanceMinorUnits, equals(largeAmount));
    });
  });

  // ── مجموعة 4: المعاملات الذرية ──────────────────────────────────────────────
  group('DB-04 — المعاملات الذرية (Financial Transaction Engine)', () {
    late AppDatabase db;
    late FinancialTransactionEngine engine;
    setUp(() {
      db = buildTestDatabase();
      engine = FinancialTransactionEngine(db);
    });
    tearDown(() => db.close());

    test('تحويل داخلي: يخصم من المصدر ويضيف للوجهة بدقة', () async {
      await seedAccount(db, id: 'src', balanceMinorUnits: 1000000);
      await seedAccount(db, id: 'dst', balanceMinorUnits: 200000);

      await engine.executeInternalTransfer(
        txnId: 'txn-001',
        fromAccountId: 'src',
        toAccountId: 'dst',
        amountMinorUnits: 300000,
        date: DateTime.now(),
      );

      final src = await db.accountsDao.getAccountById('src');
      final dst = await db.accountsDao.getAccountById('dst');
      expect(src!.balanceMinorUnits, equals(700000));
      expect(dst!.balanceMinorUnits, equals(500000));
      // ثبات الثروة الإجمالية
      expect(src.balanceMinorUnits + dst.balanceMinorUnits,
          equals(1200000));
    });

    test('تحويل فاشل: رصيد غير كافٍ يُطلق استثناء دون تعديل البيانات',
        () async {
      await seedAccount(db, id: 'src', balanceMinorUnits: 100000);
      await seedAccount(db, id: 'dst', balanceMinorUnits: 50000);

      await expectLater(
        engine.executeInternalTransfer(
          txnId: 'txn-002',
          fromAccountId: 'src',
          toAccountId: 'dst',
          amountMinorUnits: 999999, // أكبر من الرصيد
          date: DateTime.now(),
        ),
        throwsA(isA<ArgumentError>()),
      );

      // الأرصدة يجب أن تبقى كما هي (Rollback)
      final src = await db.accountsDao.getAccountById('src');
      final dst = await db.accountsDao.getAccountById('dst');
      expect(src!.balanceMinorUnits, equals(100000));
      expect(dst!.balanceMinorUnits, equals(50000));
    });

    test('تسجيل مصروف: يُنشئ معاملة ويخصم الرصيد', () async {
      await seedAccount(db, id: 'acc-01', balanceMinorUnits: 500000);
      await engine.executeExpense(
        txnId: 'txn-003',
        accountId: 'acc-01',
        categoryId: null,
        amountMinorUnits: 15000,
        date: DateTime.now(),
        note: 'مطعم اختبار',
      );
      final account = await db.accountsDao.getAccountById('acc-01');
      expect(account!.balanceMinorUnits, equals(485000));
      final txns =
          await db.transactionsDao.watchAccountTransactions('acc-01').first;
      expect(txns.length, equals(1));
      expect(txns.first.type, equals('expense'));
    });

    test('إيداع دخل: يُضيف للرصيد ويسجّل معاملة income', () async {
      await seedAccount(db, id: 'acc-01', balanceMinorUnits: 0);
      await engine.executeIncomeDeposit(
        txnId: 'txn-004',
        accountId: 'acc-01',
        categoryId: null,
        amountMinorUnits: 2000000,
        date: DateTime.now(),
        note: 'راتب أكتوبر',
      );
      final account = await db.accountsDao.getAccountById('acc-01');
      expect(account!.balanceMinorUnits, equals(2000000));
    });
  });

  // ── مجموعة 5: الديون وسداد الأقساط ─────────────────────────────────────────
  group('DB-05 — الديون والأقساط (DebtsDao)', () {
    late AppDatabase db;
    late FinancialTransactionEngine engine;
    setUp(() {
      db = buildTestDatabase();
      engine = FinancialTransactionEngine(db);
    });
    tearDown(() => db.close());

    test('سداد قسط: يخفض الرصيد المتبقي ويُغيّر الحالة عند التسديد الكامل',
        () async {
      await seedAccount(db, id: 'acc-01', balanceMinorUnits: 2000000);
      await db.debtsDao.insertDebt(DebtsCompanion.insert(
        id: 'debt-01',
        title: 'تمويل سيارة',
        counterpartyName: 'بنك الراجحي',
        type: 'payable',
        totalMinorUnits: 500000,
        remainingMinorUnits: 500000,
        startDate: DateTime.now(),
      ));

      await engine.executeDebtPayment(
        paymentId: 'pay-01',
        txnId: 'txn-pay-01',
        debtId: 'debt-01',
        fromAccountId: 'acc-01',
        amountMinorUnits: 500000, // سداد كامل
        date: DateTime.now(),
      );

      final debt = await db.debtsDao.getDebtById('debt-01');
      expect(debt!.remainingMinorUnits, equals(0));
      expect(debt.status, equals('settled'));
      final account = await db.accountsDao.getAccountById('acc-01');
      expect(account!.balanceMinorUnits, equals(1500000));
    });
  });

  // ── مجموعة 6: الحذف الناعم والاستعادة ───────────────────────────────────────
  group('DB-06 — الحذف الناعم وسجل التدقيق (Soft Delete / Audit Trail)', () {
    late AppDatabase db;
    late FinancialTransactionEngine engine;
    setUp(() {
      db = buildTestDatabase();
      engine = FinancialTransactionEngine(db);
    });
    tearDown(() => db.close());

    test('المعاملة المحذوفة ناعماً لا تظهر في النشطة لكنها موجودة', () async {
      await seedAccount(db, id: 'acc-01', balanceMinorUnits: 500000);
      await engine.executeExpense(
        txnId: 'txn-soft',
        accountId: 'acc-01',
        categoryId: null,
        amountMinorUnits: 5000,
        date: DateTime.now(),
      );
      await db.transactionsDao.softDeleteTransaction('txn-soft');

      final active = await db.transactionsDao
          .watchAccountTransactions('acc-01')
          .first;
      expect(active, isEmpty);

      final restorable =
          await db.transactionsDao.getRestorableTransactions();
      expect(restorable.length, equals(1));
      expect(restorable.first.id, equals('txn-soft'));
    });
  });

  // ── مجموعة 7: صندوق الطوارئ ──────────────────────────────────────────────────
  group('DB-07 — صندوق الطوارئ (EmergencyFundDao)', () {
    late AppDatabase db;
    setUp(() => db = buildTestDatabase());
    tearDown(() => db.close());

    test('إنشاء الصندوق وإضافة مبلغ وسحب مشروط', () async {
      await db.emergencyFundDao.upsertConfig(
        EmergencyFundConfigCompanion.insert(
          id: const Value('primary_fund'),
          targetMinorUnits: 600000,
          currentMinorUnits: const Value(100000),
        ),
      );
      await db.emergencyFundDao.addToFund(50000);
      final config = await db.emergencyFundDao.getConfig();
      expect(config!.currentMinorUnits, equals(150000));

      // سحب طوارئ بسبب موثق
      await db.emergencyFundDao.withdrawFromFund(
        withdrawalId: 'ew-01',
        amountMinorUnits: 30000,
        reason: 'علاج طبي طارئ',
        compensationPlanNotes: 'استرداد 5% من الراتب القادم',
      );

      final updated = await db.emergencyFundDao.getConfig();
      expect(updated!.currentMinorUnits, equals(120000));
      expect(updated.compensationPlanActive, isTrue);

      final history = await db.emergencyFundDao.getWithdrawalHistory();
      expect(history.length, equals(1));
      expect(history.first.reason, contains('طبي'));
    });

    test('رفض السحب إذا تجاوز الرصيد المتاح', () async {
      await db.emergencyFundDao.upsertConfig(
        EmergencyFundConfigCompanion.insert(
          id: const Value('primary_fund'),
          targetMinorUnits: 600000,
          currentMinorUnits: const Value(10000),
        ),
      );
      await expectLater(
        db.emergencyFundDao.withdrawFromFund(
          withdrawalId: 'ew-fail',
          amountMinorUnits: 99999,
          reason: 'أزمة',
        ),
        throwsA(isA<ArgumentError>()),
      );
    });
  });

  // ── مجموعة 8: التواريخ ──────────────────────────────────────────────────────
  group('DB-08 — دقة حفظ التواريخ واسترجاعها', () {
    late AppDatabase db;
    late FinancialTransactionEngine engine;
    setUp(() {
      db = buildTestDatabase();
      engine = FinancialTransactionEngine(db);
    });
    tearDown(() => db.close());

    test('تاريخ المعاملة يُحفظ ويُسترجع بدون فقدان الدقة', () async {
      await seedAccount(db, id: 'acc-01', balanceMinorUnits: 500000);
      final txnDate = DateTime(2026, 10, 31, 14, 30, 00);
      await engine.executeExpense(
        txnId: 'txn-date',
        accountId: 'acc-01',
        categoryId: null,
        amountMinorUnits: 1000,
        date: txnDate,
      );
      final txns =
          await db.transactionsDao.watchAccountTransactions('acc-01').first;
      expect(txns.first.transactionDate.year, equals(2026));
      expect(txns.first.transactionDate.month, equals(10));
      expect(txns.first.transactionDate.day, equals(31));
    });
  });
}

