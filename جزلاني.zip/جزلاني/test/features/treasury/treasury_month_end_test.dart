import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/expenses_budgets/data/repositories/in_memory_expenses_budgets_repository.dart';
import 'package:my_finance/features/expenses_budgets/domain/entities/budget_entity.dart';
import 'package:my_finance/features/income/data/repositories/in_memory_income_repository.dart';
import 'package:my_finance/features/income/domain/entities/income_entry.dart';
import 'package:my_finance/features/income/domain/entities/income_type.dart';
import 'package:my_finance/features/treasury/application/treasury_controller.dart';
import 'package:my_finance/features/treasury/data/repositories/in_memory_treasury_repository.dart';
import 'package:my_finance/features/treasury/domain/entities/surplus_action.dart';
import 'package:my_finance/features/treasury/domain/entities/surplus_decision.dart';

void main() {
  late InMemoryFinancialEngineRepository engineRepo;
  late CentralFinancialEngine engine;
  late InMemoryExpensesBudgetsRepository expensesRepo;
  late InMemoryIncomeRepository incomeRepo;
  late InMemoryTreasuryRepository treasuryRepo;
  late TreasuryController controller;

  setUp(() {
    engineRepo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: engineRepo);
    expensesRepo = InMemoryExpensesBudgetsRepository();
    incomeRepo = InMemoryIncomeRepository();
    treasuryRepo = InMemoryTreasuryRepository(
      engineRepo: engineRepo,
      expensesBudgetsRepo: expensesRepo,
      incomeRepo: incomeRepo,
    );
    controller = TreasuryController(engine: engine, repository: treasuryRepo);

    // حسابان بنكيان
    engineRepo.accounts['acc_a'] = AccountEntity(
      id: 'acc_a',
      name: 'بنك الراجحي',
      type: AccountType.bank,
      currency: 'SAR',
      balance: Money.fromMajorUnits(15000.00),
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    engineRepo.accounts['acc_b'] = AccountEntity(
      id: 'acc_b',
      name: 'الأهلي (ادخار)',
      type: AccountType.bank,
      currency: 'SAR',
      balance: Money.fromMajorUnits(10000.00),
      colorHex: '#165342',
      iconName: 'savings',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    // مبالغ محجوزة وطوارئ
    engineRepo.emergencyFundBalance = Money.fromMajorUnits(4000.00);
    engineRepo.goalBalances['goal_home'] = Money.fromMajorUnits(6000.00);
  });

  group('Phase 08 — الخزينة الموحدة وإغلاق الشهر والفائض', () {
    // ── 1. اختبار لقطة الخزينة وعزل إجمالي الأموال عن السيولة ─────
    test('1. لقطة الخزينة: فصل إجمالي الأموال عن السيولة المتاحة والادخار والطوارئ', () async {
      await controller.loadTreasuryData();
      final snapshot = controller.state.snapshot;

      expect(snapshot, isNotNull);
      // إجمالي الأموال = 15,000 + 10,000 = 25,000 ر.س
      expect(snapshot!.totalFunds, equals(Money.fromMajorUnits(25000.00)));

      // الطوارئ = 4,000 ر.س
      expect(snapshot.emergencyFund, equals(Money.fromMajorUnits(4000.00)));

      // الأهداف = 6,000 ر.س
      expect(snapshot.goalsLocked, equals(Money.fromMajorUnits(6000.00)));

      // السيولة المتاحة = 25,000 - (4,000 + 6,000) = 15,000 ر.س
      expect(snapshot.availableLiquidity, equals(Money.fromMajorUnits(15000.00)));
    });

    // ── 2. اختبار التحويل الداخلي وثبات إجمالي الأموال ───────────
    test('2. التحويل الداخلي: ينقل الرصيد بين الحسابات دون أي تغيير في إجمالي الأموال', () async {
      await controller.loadTreasuryData();
      final totalBefore = controller.state.snapshot!.totalFunds;

      // تحويل 3,000 ر.س من حساب أ إلى حساب ب
      final success = await controller.executeInternalTransfer(
        fromAccountId: 'acc_a',
        toAccountId: 'acc_b',
        amount: Money.fromMajorUnits(3000.00),
        note: 'تحويل داخلي لتغذية الادخار',
        idempotencyKey: 'key-trans-01',
      );

      expect(success, isTrue);

      // حساب أ نقص وحساب ب زاد
      expect(engineRepo.accounts['acc_a']!.balance, equals(Money.fromMajorUnits(12000.00)));
      expect(engineRepo.accounts['acc_b']!.balance, equals(Money.fromMajorUnits(13000.00)));

      // إجمالي الأموال ثابت تماماً قبل وبعد التحويل (25,000 ر.س)
      expect(controller.state.snapshot!.totalFunds, equals(totalBefore));
    });

    // ── 3. اختبار استخراج ملخص إغلاق الشهر واحتساب الفائض ────────
    test('3. ملخص إغلاق الشهر: احتساب إجمالي الفائض من الميزانيات المتبقية', () async {
      const ym = '2026-10';

      // تسجيل ميزانية بقالة 2000 ر.س (متبقي منها 800 ر.س فائض)
      expensesRepo.budgets['cat_groceries_$ym'] = BudgetEntity(
        id: 'b1',
        categoryId: 'cat_groceries',
        categoryName: 'البقالة',
        categoryIcon: 'cart',
        categoryColorHex: '#0E3B2E',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(2000.00),
        spentAmount: Money.fromMajorUnits(1200.00),
        createdAt: DateTime.now(),
      );

      // تسجيل ميزانية مطاعم 1000 ر.س (متبقي منها 300 ر.س فائض)
      expensesRepo.budgets['cat_dining_$ym'] = BudgetEntity(
        id: 'b2',
        categoryId: 'cat_dining',
        categoryName: 'المطاعم',
        categoryIcon: 'coffee',
        categoryColorHex: '#DFBC75',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(1000.00),
        spentAmount: Money.fromMajorUnits(700.00),
        createdAt: DateTime.now(),
      );

      // تحميل ملخص إغلاق الشهر
      await controller.loadMonthEndSummary(ym);

      final summary = controller.state.activeMonthSummary;
      expect(summary, isNotNull);
      // إجمالي الفائض = 800 + 300 = 1,100 ر.س
      expect(summary!.totalSurplus, equals(Money.fromMajorUnits(1100.00)));
      expect(summary.budgetSurpluses.length, equals(2));
    });

    // ── 4. اختبار إلغاء الإغلاق دون أي تأثير جانبي ───────────────
    test('4. إلغاء الإغلاق: لا يتم تنفيذ أي تحويل أو تسجيل أي قيد مالي عند الإلغاء', () async {
      const ym = '2026-10';
      await controller.loadMonthEndSummary(ym);

      controller.cancelClosing();

      expect(controller.state.activeMonthSummary, isNull);
      expect(await treasuryRepo.isMonthClosed(ym), isFalse);
    });

    // ── 5. اختبار تنفيذ خيارات الفائض المتعددة ────────────────────
    test('5. خيارات الفائض: تنفيذ قرارات المستخدم (طوارئ، ادخار عام، هدف، ترحيل)', () async {
      const ym = '2026-10';

      // ميزانيتان بهما فائض
      expensesRepo.budgets['cat_groceries_$ym'] = BudgetEntity(
        id: 'b1',
        categoryId: 'cat_groceries',
        categoryName: 'البقالة',
        categoryIcon: 'cart',
        categoryColorHex: '#0E3B2E',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(1000.00),
        spentAmount: Money.fromMajorUnits(600.00), // فائض 400 ر.س
        createdAt: DateTime.now(),
      );

      expensesRepo.budgets['cat_dining_$ym'] = BudgetEntity(
        id: 'b2',
        categoryId: 'cat_dining',
        categoryName: 'المطاعم',
        categoryIcon: 'coffee',
        categoryColorHex: '#DFBC75',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(800.00),
        spentAmount: Money.fromMajorUnits(300.00), // فائض 500 ر.س
        createdAt: DateTime.now(),
      );

      await controller.loadMonthEndSummary(ym);

      // قرار 1: فائض البقالة (400 ر.س) يذهب إلى صندوق الطوارئ
      controller.updateSurplusDecision(SurplusDecision(
        categoryId: 'cat_groceries',
        categoryName: 'البقالة',
        surplusAmount: Money.fromMajorUnits(400.00),
        action: SurplusAction.transferToEmergency,
      ));

      // قرار 2: فائض المطاعم (500 ر.س) يذهب إلى الادخار العام
      controller.updateSurplusDecision(SurplusDecision(
        categoryId: 'cat_dining',
        categoryName: 'المطاعم',
        surplusAmount: Money.fromMajorUnits(500.00),
        action: SurplusAction.addToSavings,
      ));

      // تأكيد الإغلاق
      final success = await controller.confirmAndExecuteMonthEndClosing(
        periodYearMonth: ym,
        defaultAccountId: 'acc_a',
        notes: 'إغلاق ناجح لشهر أكتوبر',
        idempotencyKey: 'close-test-exec-1',
      );

      expect(success, isTrue);

      // 1. صندوق الطوارئ زاد بمقدار 400 ر.س (كان 4000 فأصبح 4400)
      expect(engineRepo.emergencyFundBalance, equals(Money.fromMajorUnits(4400.00)));

      // 2. الادخار العام زاد بمقدار 500 ر.س
      expect(treasuryRepo.generalSavingsBalance, equals(Money.fromMajorUnits(500.00)));

      // 3. تم توثيق الشهر كمغلق في السجلات
      expect(await treasuryRepo.isMonthClosed(ym), isTrue);
    });

    // ── 6. اختبار منع إغلاق الشهر مرتين (No Double Close) ────────
    test('6. حظر الإغلاق المزدوج: يرفض إعادة إغلاق شهر مغلق مسبقاً', () async {
      const ym = '2026-10';

      expensesRepo.budgets['cat_test_$ym'] = BudgetEntity(
        id: 'b_test',
        categoryId: 'cat_test',
        categoryName: 'اختبار',
        categoryIcon: 'tag',
        categoryColorHex: '#000000',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(500.00),
        spentAmount: Money.fromMajorUnits(200.00),
        createdAt: DateTime.now(),
      );

      await controller.loadMonthEndSummary(ym);

      // الإغلاق الأول: ينجح
      final firstClose = await controller.confirmAndExecuteMonthEndClosing(
        periodYearMonth: ym,
        idempotencyKey: 'close-first-key',
      );
      expect(firstClose, isTrue);

      // محاولة الإغلاق الثاني لنفس الشهر:
      await controller.loadMonthEndSummary(ym);
      final secondClose = await controller.confirmAndExecuteMonthEndClosing(
        periodYearMonth: ym,
        idempotencyKey: 'close-second-key',
      );

      // يجب أن يفشل حتماً
      expect(secondClose, isFalse);
    });

    // ── 7. اختبار مراجعة سجلات الأشهر المغلقة ─────────────────────
    test('7. أرشيف الأشهر المغلقة: حفظ السجلات وإمكانية مراجعة القرارات السابقة', () async {
      const ym = '2026-09';
      expensesRepo.budgets['cat_b_$ym'] = BudgetEntity(
        id: 'b_sep',
        categoryId: 'cat_b',
        categoryName: 'ميزانية سبتمبر',
        categoryIcon: 'tag',
        categoryColorHex: '#000000',
        periodYearMonth: ym,
        allocatedAmount: Money.fromMajorUnits(1000.00),
        spentAmount: Money.fromMajorUnits(700.00),
        createdAt: DateTime.now(),
      );

      await controller.loadMonthEndSummary(ym);
      await controller.confirmAndExecuteMonthEndClosing(
        periodYearMonth: ym,
        notes: 'ملاحظة توثيقية لشهر سبتمبر',
        idempotencyKey: 'close-sep-key',
      );

      final history = await treasuryRepo.getAllClosedMonthRecords();
      expect(history.length, equals(1));
      expect(history.first.periodYearMonth, equals(ym));
      expect(history.first.notes, equals('ملاحظة توثيقية لشهر سبتمبر'));
      expect(history.first.decisions.length, equals(1));
    });
  });
}

