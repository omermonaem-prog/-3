import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/analytics/application/analytics_controller.dart';
import 'package:my_finance/features/analytics/application/services/report_export_service.dart';
import 'package:my_finance/features/analytics/data/repositories/in_memory_analytics_repository.dart';
import 'package:my_finance/features/analytics/domain/entities/category_expense_breakdown.dart';
import 'package:my_finance/features/analytics/domain/entities/financial_calendar_event.dart';
import 'package:my_finance/features/analytics/domain/entities/monthly_financial_summary.dart';

void main() {
  late InMemoryAnalyticsRepository repository;
  late AnalyticsController controller;

  setUp(() {
    repository = InMemoryAnalyticsRepository();
    controller = AnalyticsController(repository: repository);
  });

  // ════════════════════════════════════════════════════════════════
  // 1. اختبارات ملخصات الدخل والمصروفات والوفر الشهري
  // ════════════════════════════════════════════════════════════════
  group('1. اختبارات ملخصات الدخل والمصروفات والوفر', () {
    test('حساب صافي الوفر ونسبة الادخار بدقة وفصل الراتب عن الدخل الإضافي', () async {
      repository.monthlySummaries.add(
        MonthlyFinancialSummary(
          periodYearMonth: '2026-10',
          monthLabel: 'أكتوبر 2026',
          totalIncome: Money.fromMajorUnits(20000.00),
          salaryIncome: Money.fromMajorUnits(15000.00),
          additionalIncome: Money.fromMajorUnits(5000.00),
          totalExpenses: Money.fromMajorUnits(12000.00),
        ),
      );

      await controller.loadAll();

      final summary = controller.state.selectedMonthSummary;
      expect(summary, isNotNull);
      expect(summary!.salaryIncome, equals(Money.fromMajorUnits(15000.00)));
      expect(summary.additionalIncome, equals(Money.fromMajorUnits(5000.00)));
      expect(summary.totalIncome, equals(Money.fromMajorUnits(20000.00)));
      expect(summary.totalExpenses, equals(Money.fromMajorUnits(12000.00)));

      // صافي الوفر = 20,000 - 12,000 = 8,000 ر.س
      expect(summary.netSavings, equals(Money.fromMajorUnits(8000.00)));
      expect(summary.hasSurplus, isTrue);

      // نسبة الادخار = (8000 / 20000) * 100 = 40.0%
      expect(summary.savingsRatePercentage, equals(40.0));
    });

    test('التعامل الصحيح مع الأشهر التي تشهد عجزاً مالياً', () async {
      repository.monthlySummaries.add(
        MonthlyFinancialSummary(
          periodYearMonth: '2026-09',
          monthLabel: 'سبتمبر 2026',
          totalIncome: Money.fromMajorUnits(10000.00),
          salaryIncome: Money.fromMajorUnits(10000.00),
          additionalIncome: const Money.zero(),
          totalExpenses: Money.fromMajorUnits(12500.00),
        ),
      );

      await controller.loadAll();

      final summary = controller.state.selectedMonthSummary;
      expect(summary!.hasSurplus, isFalse);
      expect(summary.netSavings.isNegative, isTrue);
      expect(summary.netSavings, equals(Money.fromMajorUnits(-2500.00)));
      expect(summary.savingsRatePercentage, equals(0.0));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 2. اختبارات توزيع المصروفات حسب التصنيف
  // ════════════════════════════════════════════════════════════════
  group('2. اختبارات تحليل المصروفات حسب التصنيف', () {
    test('توزيع المصروفات ومجموع النسب المئوية', () async {
      repository.categoryBreakdowns.addAll([
        const CategoryExpenseBreakdown(
          categoryId: 'cat_rent',
          categoryName: 'السكن والإيجار',
          totalAmount: Money.fromMinorUnits(500000), // 5,000 ر.س
          percentageOfTotal: 50.0,
          transactionCount: 1,
        ),
        const CategoryExpenseBreakdown(
          categoryId: 'cat_groceries',
          categoryName: 'المعيشة والتموين',
          totalAmount: Money.fromMinorUnits(300000), // 3,000 ر.س
          percentageOfTotal: 30.0,
          transactionCount: 12,
        ),
        const CategoryExpenseBreakdown(
          categoryId: 'cat_transport',
          categoryName: 'المواصلات',
          totalAmount: Money.fromMinorUnits(200000), // 2,000 ر.س
          percentageOfTotal: 20.0,
          transactionCount: 6,
        ),
      ]);

      await controller.loadAll();

      final list = controller.state.categoryBreakdowns;
      expect(list.length, equals(3));

      final totalPercentage = list.fold<double>(0.0, (sum, c) => sum + c.percentageOfTotal);
      expect(totalPercentage, equals(100.0));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 3. اختبارات توزيع الأقسام الخمسة (40/20/20/10/10)
  // ════════════════════════════════════════════════════════════════
  group('3. اختبارات توزيع الأقسام الخمسة', () {
    test('تقرير توزيع الدخل يغطي كافة الأقسام بالنسب المعتمدة', () async {
      await controller.loadAll();

      final buckets = controller.state.bucketReports;
      expect(buckets.length, equals(5));

      expect(buckets.any((b) => b.bucketName.contains('المسؤوليات') && b.targetPercentage == 40.0), isTrue);
      expect(buckets.any((b) => b.bucketName.contains('الادخار') && b.targetPercentage == 20.0), isTrue);
      expect(buckets.any((b) => b.bucketName.contains('الطوارئ') && b.targetPercentage == 20.0), isTrue);
      expect(buckets.any((b) => b.bucketName.contains('المهارات') && b.targetPercentage == 10.0), isTrue);
      expect(buckets.any((b) => b.bucketName.contains('الترفيه') && b.targetPercentage == 10.0), isTrue);
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 4. اختبارات التقويم المالي والأحداث
  // ════════════════════════════════════════════════════════════════
  group('4. اختبارات التقويم المالي', () {
    test('إدراج وفلترة أحداث التقويم المالي', () async {
      repository.calendarEvents.addAll([
        FinancialCalendarEvent(
          id: 'ev_sal',
          date: DateTime(2026, 10, 27),
          title: 'الراتب الشهري',
          amount: Money.fromMajorUnits(15000.00),
          type: CalendarEventType.income,
          status: CalendarEventStatus.completed,
        ),
        FinancialCalendarEvent(
          id: 'ev_bill',
          date: DateTime(2026, 10, 28),
          title: 'فاتورة الكهرباء',
          amount: Money.fromMajorUnits(350.00),
          type: CalendarEventType.obligationDue,
          status: CalendarEventStatus.pending,
        ),
      ]);

      await controller.loadAll();

      expect(controller.state.calendarEvents.length, equals(2));
      expect(controller.state.calendarEvents.first.type, equals(CalendarEventType.income));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 5. اختبارات التوقعات المالية وإخلاء المسؤولية
  // ════════════════════════════════════════════════════════════════
  group('5. اختبارات التوقعات المالية المستقبلية والنزاهة', () {
    test('بناء نموذج التوقعات التقديرية وتوضيح أنها ليست حقائق قطعية', () async {
      repository.monthlySummaries.addAll([
        MonthlyFinancialSummary(
          periodYearMonth: '2026-08',
          monthLabel: 'أغسطس',
          totalIncome: Money.fromMajorUnits(15000.00),
          salaryIncome: Money.fromMajorUnits(15000.00),
          additionalIncome: const Money.zero(),
          totalExpenses: Money.fromMajorUnits(10000.00),
        ),
        MonthlyFinancialSummary(
          periodYearMonth: '2026-09',
          monthLabel: 'سبتمبر',
          totalIncome: Money.fromMajorUnits(15000.00),
          salaryIncome: Money.fromMajorUnits(15000.00),
          additionalIncome: const Money.zero(),
          totalExpenses: Money.fromMajorUnits(10000.00),
        ),
      ]);

      await controller.loadAll();

      final forecast = controller.state.forecastModel;
      expect(forecast, isNotNull);

      // متوسط الدخل: 15,000 | المصروف: 10,000 | الوفر: 5,000
      expect(forecast!.averageMonthlySavings, equals(Money.fromMajorUnits(5000.00)));

      // التوقع التقديري لـ 3 أشهر: 5000 * 3 = 15,000 ر.س
      expect(forecast.projectedNetWorthIn3Months, equals(Money.fromMajorUnits(15000.00)));

      // التوقع التقديري لـ 6 أشهر: 5000 * 6 = 30,000 ر.س
      expect(forecast.projectedNetWorthIn6Months, equals(Money.fromMajorUnits(30000.00)));

      // التأكد من وجود نص إخلاء المسؤولية الصريح
      expect(forecast.disclaimer, contains('تقديرات استرشادية'));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 6. اختبارات تصدير التقارير بصيغة CSV المتوافقة مع Excel
  // ════════════════════════════════════════════════════════════════
  group('6. اختبارات تصدير التقارير بصيغة CSV', () {
    test('تصدير ملخصات الأشهر بصيغة CSV وتضمين UTF-8 BOM', () {
      final summaries = [
        MonthlyFinancialSummary(
          periodYearMonth: '2026-10',
          monthLabel: 'أكتوبر 2026',
          totalIncome: Money.fromMajorUnits(12000.00),
          salaryIncome: Money.fromMajorUnits(10000.00),
          additionalIncome: Money.fromMajorUnits(2000.00),
          totalExpenses: Money.fromMajorUnits(8000.00),
        ),
      ];

      final csv = ReportExportService.exportMonthlySummariesToCsv(summaries);

      // التأكد من وجود UTF-8 BOM
      expect(csv.startsWith('\uFEFF'), isTrue);

      // التأكد من وجود الترويسة
      expect(csv, contains('إجمالي الدخل (ر.س)'));
      expect(csv, contains('الراتب الأساسي (ر.س)'));
      expect(csv, contains('أكتوبر 2026'));
      expect(csv, contains('12000.00'));
      expect(csv, contains('8000.00'));
    });

    test('تصدير توزيع التصنيفات وأحداث التقويم بصيغة CSV', () {
      final categories = [
        const CategoryExpenseBreakdown(
          categoryId: 'cat_groceries',
          categoryName: 'تموين',
          totalAmount: Money.fromMinorUnits(150000),
          percentageOfTotal: 100.0,
          transactionCount: 5,
        ),
      ];

      final csv = ReportExportService.exportCategoriesToCsv(categories);
      expect(csv.startsWith('\uFEFF'), isTrue);
      expect(csv, contains('تموين'));
      expect(csv, contains('1500.00'));
    });
  });
}

