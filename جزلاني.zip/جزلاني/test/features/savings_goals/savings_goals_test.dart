import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import 'package:my_finance/features/savings_goals/application/savings_goals_controller.dart';
import 'package:my_finance/features/savings_goals/data/repositories/in_memory_savings_goals_repository.dart';
import 'package:my_finance/features/savings_goals/domain/entities/emergency_movement.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_entity.dart';
import 'package:my_finance/features/savings_goals/domain/entities/goal_funding_entry.dart';
import 'package:my_finance/features/savings_goals/domain/entities/savings_movement.dart';

void main() {
  late InMemoryFinancialEngineRepository engineRepo;
  late CentralFinancialEngine engine;
  late InMemorySavingsGoalsRepository savingsGoalsRepo;
  late SavingsGoalsController controller;

  setUp(() {
    engineRepo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: engineRepo);
    savingsGoalsRepo = InMemorySavingsGoalsRepository();
    controller = SavingsGoalsController(
      repository: savingsGoalsRepo,
      engine: engine,
    );

    // حساب تجريبي
    engineRepo.accounts['acc_main'] = AccountEntity(
      id: 'acc_main',
      name: 'الحساب الجاري',
      type: AccountType.bank,
      currency: 'SAR',
      balance: Money.fromMajorUnits(20000.00),
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  });

  // ════════════════════════════════════════════════════════════════
  // 1. اختبارات الادخار العام (General Savings)
  // ════════════════════════════════════════════════════════════════
  group('1. اختبارات الادخار العام (General Savings)', () {
    test('إيداع في الادخار العام يرفع الرصيد ويسجل حركة في السجل المالي', () async {
      final success = await controller.depositToSavings(
        amount: Money.fromMajorUnits(3000.00),
        destinationDescription: 'إيداع من فائض الميزانية',
        idempotencyKey: 'idemp_dep_1',
      );

      expect(success, isTrue);
      expect(controller.state.generalSavings, equals(Money.fromMajorUnits(3000.00)));
      expect(controller.state.savingsMovements.length, equals(1));
      expect(controller.state.savingsMovements.first.type, equals(SavingsMovementType.deposit));
      expect(controller.state.savingsMovements.first.amount, equals(Money.fromMajorUnits(3000.00)));
    });

    test('سحب يدوي من الادخار العام إلى السيولة المتاحة', () async {
      await controller.depositToSavings(
        amount: Money.fromMajorUnits(5000.00),
        idempotencyKey: 'idemp_dep_init',
      );

      final success = await controller.withdrawFromSavings(
        amount: Money.fromMajorUnits(1500.00),
        destinationType: SavingsMovementType.withdrawalToLiquidity,
        destinationDescription: 'سحب إلى السيولة المتاحة',
        targetAccountId: 'acc_main',
        idempotencyKey: 'idemp_with_liq',
      );

      expect(success, isTrue);
      expect(controller.state.generalSavings, equals(Money.fromMajorUnits(3500.00)));
      // الحساب الجاري زاد رصيده من 20000 إلى 21500
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(21500.00)));
    });

    test('تحويل من الادخار العام إلى صندوق الطوارئ', () async {
      await controller.depositToSavings(
        amount: Money.fromMajorUnits(4000.00),
        idempotencyKey: 'idemp_dep_sav',
      );

      final success = await controller.withdrawFromSavings(
        amount: Money.fromMajorUnits(2000.00),
        destinationType: SavingsMovementType.transferToEmergency,
        destinationDescription: 'تعزيز صندوق الطوارئ من الادخار',
        idempotencyKey: 'idemp_sav_to_ef',
      );

      expect(success, isTrue);
      expect(controller.state.generalSavings, equals(Money.fromMajorUnits(2000.00)));
      expect(controller.state.emergencyFund, equals(Money.fromMajorUnits(2000.00)));
    });

    test('فشل السحب إذا كان المبلغ المطلوب أكبر من رصيد الادخار المتاح', () async {
      await controller.depositToSavings(
        amount: Money.fromMajorUnits(500.00),
        idempotencyKey: 'idemp_dep_small',
      );

      final success = await controller.withdrawFromSavings(
        amount: Money.fromMajorUnits(1000.00),
        destinationType: SavingsMovementType.withdrawalToLiquidity,
        destinationDescription: 'سحب مفرط',
        idempotencyKey: 'idemp_overdraw',
      );

      expect(success, isFalse);
      expect(controller.state.generalSavings, equals(Money.fromMajorUnits(500.00)));
      expect(controller.state.errorMessage, isNotNull);
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 2. اختبارات صندوق الطوارئ (Emergency Fund)
  // ════════════════════════════════════════════════════════════════
  group('2. اختبارات صندوق الطوارئ (Emergency Fund)', () {
    test('تعزيز رصيد صندوق الطوارئ بنجاح', () async {
      final success = await controller.depositToEmergency(
        amount: Money.fromMajorUnits(6000.00),
        notes: 'تغذية صندوق الطوارئ ربع السنوية',
        idempotencyKey: 'idemp_ef_dep_1',
      );

      expect(success, isTrue);
      expect(controller.state.emergencyFund, equals(Money.fromMajorUnits(6000.00)));
      expect(controller.state.emergencyMovements.length, equals(1));
      expect(controller.state.emergencyMovements.first.type, equals(EmergencyMovementType.deposit));
    });

    test('سحب طارئ استثنائي يتطلب سبباً صريحاً ويحدّث الرصيد بدقة', () async {
      await controller.depositToEmergency(
        amount: Money.fromMajorUnits(10000.00),
        idempotencyKey: 'idemp_ef_init',
      );

      final success = await controller.withdrawFromEmergency(
        amount: Money.fromMajorUnits(3500.00),
        reason: 'إصلاح عاجل للسيارة بعد حادث مفاجئ',
        compensationPlan: 'تعويض 1000 ريال شهرياً على 4 أشهر',
        toAccountId: 'acc_main',
        idempotencyKey: 'idemp_ef_with_1',
      );

      expect(success, isTrue);
      expect(controller.state.emergencyFund, equals(Money.fromMajorUnits(6500.00)));
      expect(controller.state.emergencyMovements.length, equals(2));

      final lastMovement = controller.state.emergencyMovements.first;
      expect(lastMovement.type, equals(EmergencyMovementType.withdrawal));
      expect(lastMovement.reason, equals('إصلاح عاجل للسيارة بعد حادث مفاجئ'));
      expect(lastMovement.compensationPlan, isNotNull);

      // تأكيد وصول المبلغ للحساب
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(23500.00)));
    });

    test('رفض السحب الطارئ إذا كان السبب فارغاً', () async {
      await controller.depositToEmergency(
        amount: Money.fromMajorUnits(5000.00),
        idempotencyKey: 'idemp_ef_init_2',
      );

      final success = await controller.withdrawFromEmergency(
        amount: Money.fromMajorUnits(1000.00),
        reason: '   ', // سبب فارغ
        idempotencyKey: 'idemp_ef_empty_reason',
      );

      expect(success, isFalse);
      expect(controller.state.emergencyFund, equals(Money.fromMajorUnits(5000.00)));
      expect(controller.state.errorMessage, contains('سبب واضح'));
    });

    test('رفض السحب الطارئ إذا تجاوز الرصيد المتاح', () async {
      await controller.depositToEmergency(
        amount: Money.fromMajorUnits(2000.00),
        idempotencyKey: 'idemp_ef_init_3',
      );

      final success = await controller.withdrawFromEmergency(
        amount: Money.fromMajorUnits(5000.00),
        reason: 'ظرف طارئ كبير',
        idempotencyKey: 'idemp_ef_excess',
      );

      expect(success, isFalse);
      expect(controller.state.emergencyFund, equals(Money.fromMajorUnits(2000.00)));
    });
  });

  // ════════════════════════════════════════════════════════════════
  // 3. اختبارات الأهداف المالية والمشتريات (Goals & Purchases)
  // ════════════════════════════════════════════════════════════════
  group('3. اختبارات الأهداف المالية والمشتريات (Goals & Purchases)', () {
    test('إنشاء هدف مالي جديد بالحالة النشطة ورصيد صفري', () async {
      final success = await controller.createGoal(
        title: 'شراء لابتوب جديد',
        description: 'لابتوب لتطوير التطبيقات',
        targetAmount: Money.fromMajorUnits(8000.00),
      );

      expect(success, isTrue);
      expect(controller.state.goals.length, equals(1));

      final goal = controller.state.goals.first;
      expect(goal.title, equals('شراء لابتوب جديد'));
      expect(goal.savedAmount, equals(const Money.zero()));
      expect(goal.targetAmount, equals(Money.fromMajorUnits(8000.00)));
      expect(goal.status, equals(GoalStatus.active));
      expect(goal.isReadyForPurchase, isFalse);
    });

    test('تخصيص أموال للهدف من الحساب البنكي (تحويل محاسبي وليس مصروفاً)', () async {
      await controller.createGoal(
        title: 'سفر عائلي',
        description: 'رحلة إجازة الصيف',
        targetAmount: Money.fromMajorUnits(10000.00),
      );
      final goal = controller.state.goals.first;

      final success = await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.account,
        sourceAccountId: 'acc_main',
        sourceAccountName: 'الحساب الجاري',
        amount: Money.fromMajorUnits(4000.00),
        idempotencyKey: 'idemp_alloc_acc_1',
      );

      expect(success, isTrue);

      final updatedGoal = controller.state.goals.first;
      expect(updatedGoal.savedAmount, equals(Money.fromMajorUnits(4000.00)));
      expect(updatedGoal.remainingAmount, equals(Money.fromMajorUnits(6000.00)));
      expect(updatedGoal.progressPercentage, equals(40.0));

      // التأكد أن رصيد الحساب نقص 4000
      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(16000.00)));

      // التأكد أن المعاملة ليست TransactionType.expense
      final txns = engineRepo.transactions.values.toList();
      expect(txns.any((t) => t.type == TransactionType.goalAllocation), isTrue);
      expect(txns.any((t) => t.type == TransactionType.expense), isFalse);
    });

    test('تخصيص أموال للهدف من الادخار العام', () async {
      await controller.depositToSavings(
        amount: Money.fromMajorUnits(7000.00),
        idempotencyKey: 'idemp_dep_for_goal',
      );

      await controller.createGoal(
        title: 'شراء أثاث',
        description: 'تأثيث غرفة المعيشة',
        targetAmount: Money.fromMajorUnits(5000.00),
      );
      final goal = controller.state.goals.first;

      final success = await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.generalSavings,
        amount: Money.fromMajorUnits(3000.00),
        idempotencyKey: 'idemp_alloc_sav_1',
      );

      expect(success, isTrue);
      expect(controller.state.generalSavings, equals(Money.fromMajorUnits(4000.00)));

      final updatedGoal = controller.state.goals.first;
      expect(updatedGoal.savedAmount, equals(Money.fromMajorUnits(3000.00)));
    });

    test('استرداد مخصصات من الهدف وإعادتها للحساب', () async {
      await controller.createGoal(
        title: 'شراء دراجة',
        description: '',
        targetAmount: Money.fromMajorUnits(2000.00),
      );
      final goal = controller.state.goals.first;

      await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.account,
        sourceAccountId: 'acc_main',
        amount: Money.fromMajorUnits(1500.00),
        idempotencyKey: 'idemp_alloc_bike',
      );

      final success = await controller.deallocateFromGoal(
        goalId: goal.id,
        toAccountId: 'acc_main',
        amount: Money.fromMajorUnits(500.00),
        idempotencyKey: 'idemp_dealloc_bike',
      );

      expect(success, isTrue);
      final updatedGoal = controller.state.goals.first;
      expect(updatedGoal.savedAmount, equals(Money.fromMajorUnits(1000.00)));

      final acc = await engineRepo.getAccountById('acc_main');
      expect(acc?.balance, equals(Money.fromMajorUnits(19000.00)));
    });

    test('اكتمال الهدف تلقائياً عند بلوغ المبلغ المستهدف', () async {
      await controller.createGoal(
        title: 'شاشة حاسوب',
        description: '',
        targetAmount: Money.fromMajorUnits(1200.00),
      );
      final goal = controller.state.goals.first;

      await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.account,
        sourceAccountId: 'acc_main',
        amount: Money.fromMajorUnits(1200.00),
        idempotencyKey: 'idemp_alloc_screen',
      );

      final updatedGoal = controller.state.goals.first;
      expect(updatedGoal.isReadyForPurchase, isTrue);
      expect(updatedGoal.status, equals(GoalStatus.achieved));
      expect(updatedGoal.remainingAmount, equals(const Money.zero()));
    });

    test('تسجيل شراء الهدف المالي بنجاح بعد اكتماله وتحديث الخزينة وحالته', () async {
      await controller.createGoal(
        title: 'كاميرا تصوير',
        description: '',
        targetAmount: Money.fromMajorUnits(5000.00),
      );
      final goal = controller.state.goals.first;

      await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.account,
        sourceAccountId: 'acc_main',
        amount: Money.fromMajorUnits(5000.00),
        idempotencyKey: 'idemp_alloc_cam',
      );

      expect(controller.state.totalGoalsSaved, equals(Money.fromMajorUnits(5000.00)));

      // تنفيذ الشراء
      final purchaseSuccess = await controller.purchaseGoal(
        goalId: goal.id,
        idempotencyKey: 'idemp_purch_cam',
      );

      expect(purchaseSuccess, isTrue);

      final purchasedGoal = controller.state.goals.first;
      expect(purchasedGoal.status, equals(GoalStatus.purchased));

      // بعد الشراء، الأموال لم تعد محجوزة كهدف ادخاري نشط
      expect(controller.state.totalGoalsSaved, equals(const Money.zero()));
    });

    test('منع شراء هدف لم يكتمل مبلغه المستهدف بعد', () async {
      await controller.createGoal(
        title: 'ساعة ذكية',
        description: '',
        targetAmount: Money.fromMajorUnits(2000.00),
      );
      final goal = controller.state.goals.first;

      await controller.allocateToGoal(
        goalId: goal.id,
        sourceType: GoalFundingSource.account,
        sourceAccountId: 'acc_main',
        amount: Money.fromMajorUnits(1000.00),
        idempotencyKey: 'idemp_alloc_watch',
      );

      final purchaseSuccess = await controller.purchaseGoal(
        goalId: goal.id,
        idempotencyKey: 'idemp_premature_purch',
      );

      expect(purchaseSuccess, isFalse);
      expect(controller.state.errorMessage, contains('لم يكتمل ادخار'));
    });

    test('إيقاف الهدف مؤقتاً ثم استئنافه', () async {
      await controller.createGoal(
        title: 'تطوير مكتب',
        description: '',
        targetAmount: Money.fromMajorUnits(3000.00),
      );
      final goal = controller.state.goals.first;

      await controller.pauseGoal(goal.id);
      expect(controller.state.goals.first.status, equals(GoalStatus.paused));

      await controller.resumeGoal(goal.id);
      expect(controller.state.goals.first.status, equals(GoalStatus.active));
    });
  });
}

