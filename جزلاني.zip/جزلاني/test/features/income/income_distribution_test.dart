import 'package:flutter_test/flutter_test.dart';
import 'package:my_finance/core/finance/money.dart';
import 'package:my_finance/features/financial_engine/application/central_financial_engine.dart';
import 'package:my_finance/features/financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import 'package:my_finance/features/financial_engine/domain/entities/account_entity.dart';
import 'package:my_finance/features/financial_engine/domain/entities/transaction_entity.dart';
import 'package:my_finance/features/income/application/income_controller.dart';
import 'package:my_finance/features/income/application/income_state.dart';
import 'package:my_finance/features/income/data/repositories/in_memory_income_repository.dart';
import 'package:my_finance/features/income/domain/entities/income_distribution_spec.dart';
import 'package:my_finance/features/income/domain/entities/income_type.dart';

void main() {
  late InMemoryFinancialEngineRepository engineRepo;
  late CentralFinancialEngine engine;
  late InMemoryIncomeRepository incomeRepo;
  late IncomeController controller;

  setUp(() {
    engineRepo = InMemoryFinancialEngineRepository();
    engine = CentralFinancialEngine(repository: engineRepo);
    incomeRepo = InMemoryIncomeRepository();
    controller = IncomeController(engine: engine, repository: incomeRepo);

    // تجهيز حساب تجريبي للاستقبال
    engineRepo.accounts['acc_test'] = AccountEntity(
      id: 'acc_test',
      name: 'حساب الراتب البنكي',
      type: AccountType.bank,
      currency: 'SAR',
      balance: const Money.zero(),
      colorHex: '#0E3B2E',
      iconName: 'landmark',
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  });

  group('Phase 06 — نظام إدارة الراتب الأساسي والدخل الإضافي وتوزيعهما', () {
    // ── 1. اختبار معاينة التوزيع والنسب المئوية الإلزامية ───────
    test('1. معاينة التوزيع: تطابق النسب 40%، 20%، 20%، 10%، 10% وتستوفي القيد الصفري', () {
      final salary = Money.fromMajorUnits(10000.00);
      final preview = IncomeDistributionSpec.calculatePreview(salary);

      expect(preview.items.length, equals(5));

      // فحص النسب والمبالغ
      expect(preview.items[0].category.key, equals('responsibilities'));
      expect(preview.items[0].amount, equals(Money.fromMajorUnits(4000.00))); // 40%

      expect(preview.items[1].category.key, equals('general_savings'));
      expect(preview.items[1].amount, equals(Money.fromMajorUnits(2000.00))); // 20%

      expect(preview.items[2].category.key, equals('emergency_fund'));
      expect(preview.items[2].amount, equals(Money.fromMajorUnits(2000.00))); // 20%

      expect(preview.items[3].category.key, equals('skills_and_work'));
      expect(preview.items[3].amount, equals(Money.fromMajorUnits(1000.00))); // 10%

      expect(preview.items[4].category.key, equals('entertainment'));
      expect(preview.items[4].amount, equals(Money.fromMajorUnits(1000.00))); // 10%

      // القيد الصفري: المجموع = 10,000.00 ر.س بالضبط
      expect(preview.isZeroSumValid, isTrue);
      expect(preview.totalDistributed, equals(salary));
    });

    // ── 2. اختبار التقريب وحفظ الهللات في مبالغ كسرية فردية ────
    test('2. دقة التقريب (Largest Remainder): لا تضيع أي هللة عند تقسيم مبالغ كسرية معقدة', () {
      // راتب قدره 13,333.33 ر.س
      final oddSalary = Money.fromMinorUnits(1333333);
      final preview = IncomeDistributionSpec.calculatePreview(oddSalary);

      final totalDistributed = preview.items.fold<Money>(
        const Money.zero(),
        (sum, item) => sum + item.amount,
      );

      // شرط النزاهة المحاسبية الصارم: المجموع يطابق الأصل بدقة الهللة
      expect(totalDistributed, equals(oddSalary));
      expect(preview.isZeroSumValid, isTrue);
    });

    // ── 3. اختبار الإلغاء دون أي تغيير في الأرصدة ───────────────
    test('3. الإلغاء دون تأكيد: لا يغير الأرصدة أو يسجل أي قيد مالي إطلاقاً', () async {
      final initialBalance = engineRepo.accounts['acc_test']!.balance;

      // إنشاء المعاينة
      controller.generateDistributionPreview(Money.fromMajorUnits(5000.00));
      expect(controller.state.activePreview, isNotNull);

      // إلغاء المعاينة
      controller.cancelDistributionPreview();
      expect(controller.state.activePreview, isNull);

      // التأكد من عدم حدوث أي تغيير في الرصيد أو السجلات
      expect(engineRepo.accounts['acc_test']!.balance, equals(initialBalance));
      expect(engineRepo.emergencyFundBalance, equals(const Money.zero()));
      expect(await incomeRepo.getAllIncomes(), isEmpty);
    });

    // ── 4. اختبار تأكيد وتنفيذ التوزيع ذرياً ─────────────────────
    test('4. التأكيد وتنفيذ التوزيع: يوزع المبالغ ذرياً ويغذي صندوق الطوارئ والخزينة', () async {
      final salary = Money.fromMajorUnits(8000.00);

      controller.generateDistributionPreview(salary);

      final success = await controller.confirmAndExecuteDistribution(
        accountId: 'acc_test',
        type: IncomeType.salary,
        amount: salary,
        date: DateTime.now(),
        source: 'شركة التقنية المتقدمة',
        description: 'راتب شهر نوفمبر 2026',
        notes: 'تم استلام الراتب مع بدل سكن',
        idempotencyKey: 'idemp-salary-exec-01',
      );

      expect(success, isTrue);

      // 1. تم تغذية صندوق الطوارئ بـ 20% (1,600.00 ر.س)
      expect(engineRepo.emergencyFundBalance, equals(Money.fromMajorUnits(1600.00)));

      // 2. تم حفظ سجل الدخل وتوثيقه كموزع
      final incomes = await incomeRepo.getAllIncomes();
      expect(incomes.length, equals(1));
      expect(incomes.first.type, equals(IncomeType.salary));
      expect(incomes.first.isDistributed, isTrue);
      expect(incomes.first.distributionSummary, isNotNull);

      // 3. حالة المتحكم توثق نتيجة التوزيع المعتمدة
      expect(controller.state.lastExecutedResult, isNotNull);
      expect(controller.state.lastExecutedResult!.totalDistributed, equals(salary));
    });

    // ── 5. اختبار تسجيل الدخل الإضافي مفصولاً عن الراتب ──────────
    test('5. تسجيل دخل إضافي: يفصل بين نوعي الدخل في البيانات والإجماليات', () async {
      // 1. تسجيل راتب أساسي
      await controller.recordDirectIncome(
        accountId: 'acc_test',
        type: IncomeType.salary,
        amount: Money.fromMajorUnits(12000.00),
        date: DateTime.now(),
        source: 'الشركة',
        description: 'راتب شهري',
        idempotencyKey: 'key-sal-1',
      );

      // 2. تسجيل دخل إضافي
      await controller.recordDirectIncome(
        accountId: 'acc_test',
        type: IncomeType.additional,
        amount: Money.fromMajorUnits(3500.00),
        date: DateTime.now(),
        source: 'عميل استشاري',
        description: 'تطوير موقع ويب',
        idempotencyKey: 'key-add-1',
      );

      // التحقق من الفصل التام في الإجماليات
      expect(controller.state.totalSalary, equals(Money.fromMajorUnits(12000.00)));
      expect(controller.state.totalAdditional, equals(Money.fromMajorUnits(3500.00)));
      expect(controller.state.totalAll, equals(Money.fromMajorUnits(15500.00)));

      // التحقق من الفلترة
      controller.setFilter(IncomeFilter.salary);
      expect(controller.state.filteredIncomes.length, equals(1));
      expect(controller.state.filteredIncomes.first.type, equals(IncomeType.salary));

      controller.setFilter(IncomeFilter.additional);
      expect(controller.state.filteredIncomes.length, equals(1));
      expect(controller.state.filteredIncomes.first.type, equals(IncomeType.additional));

      controller.setFilter(IncomeFilter.all);
      expect(controller.state.filteredIncomes.length, equals(2));
    });

    // ── 6. اختبار منع التوزيع المكرر (Idempotency Guard) ────────
    test('6. منع التوزيع المكرر: يرفض إعادة التنفيذ بنفس المفتاح ولا يحتسب الأموال مرتين', () async {
      final amount = Money.fromMajorUnits(5000.00);
      const idempotencyKey = 'fixed-network-key-xyz-789';

      controller.generateDistributionPreview(amount);

      // المرة الأولى: تنجح
      final firstSuccess = await controller.confirmAndExecuteDistribution(
        accountId: 'acc_test',
        type: IncomeType.salary,
        amount: amount,
        date: DateTime.now(),
        source: 'العمل',
        description: 'راتب',
        idempotencyKey: idempotencyKey,
      );
      expect(firstSuccess, isTrue);

      final emergencyAfterFirst = engineRepo.emergencyFundBalance;

      // محاولة التنفيذ للمرة الثانية بنفس المفتاح:
      controller.generateDistributionPreview(amount);
      final secondSuccess = await controller.confirmAndExecuteDistribution(
        accountId: 'acc_test',
        type: IncomeType.salary,
        amount: amount,
        date: DateTime.now(),
        source: 'العمل',
        description: 'راتب مكرر',
        idempotencyKey: idempotencyKey,
      );

      // يجب أن تفشل العملية الثانية
      expect(secondSuccess, isFalse);

      // رصيد صندوق الطوارئ لم يتضاعف
      expect(engineRepo.emergencyFundBalance, equals(emergencyAfterFirst));
    });

    // ── 7. اختبار تعديل وتصحيح الدخل وفق سياسة التصحيح المحاسبي ─
    test('7. تعديل الدخل: يعكس القيد القديم ويثبت المصحح مع حفظ أثر وسجل المعاملة الأصلية', () async {
      // 1. تسجيل دخل به خطأ في المبلغ (سُجل 1,000 ر.س بدلاً من 1,500 ر.س)
      await controller.recordDirectIncome(
        accountId: 'acc_test',
        type: IncomeType.additional,
        amount: Money.fromMajorUnits(1000.00),
        date: DateTime.now(),
        source: 'عميل',
        description: 'دفعة استشارة',
        idempotencyKey: 'idemp-init-inc',
      );

      final incomes = await incomeRepo.getAllIncomes();
      final originalIncomeId = incomes.first.id;

      // 2. تصحيح القيد المالي
      final correctSuccess = await controller.correctIncome(
        originalIncomeId: originalIncomeId,
        newAmount: Money.fromMajorUnits(1500.00),
        newDate: DateTime.now(),
        newSource: 'عميل',
        newDescription: 'دفعة استشارة (مصححة)',
        reason: 'تصحيح نقص في قيمة الفاتورة',
        idempotencyKey: 'idemp-correct-inc',
      );

      expect(correctSuccess, isTrue);

      // 3. التحقق من السجلات:
      // المعاملة الأصلية أصبحت reversed
      final oldEntry = await incomeRepo.getIncomeById(originalIncomeId);
      expect(oldEntry!.status, equals(TransactionStatus.reversed));

      // يوجد سجل مصحح جديد بحالة corrected
      final updatedIncomes = await incomeRepo.getAllIncomes();
      final correctedEntry = updatedIncomes.firstWhere((i) => i.status == TransactionStatus.corrected);
      expect(correctedEntry.amount, equals(Money.fromMajorUnits(1500.00)));

      // الإجمالي المحسوب في التطبيق يعتمد المبلغ المصحح فقط
      expect(controller.state.totalAdditional, equals(Money.fromMajorUnits(1500.00)));
    });
  });
}

