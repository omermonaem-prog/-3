import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../domain/entities/income_entry.dart';
import '../../domain/entities/income_type.dart';

/// بطاقة عرض سجل الدخل المالي
class IncomeCard extends StatelessWidget {
  final IncomeEntry entry;
  final VoidCallback? onCorrect;

  const IncomeCard({
    super.key,
    required this.entry,
    this.onCorrect,
  });

  @override
  Widget build(BuildContext context) {
    final isSalary = entry.type == IncomeType.salary;
    final dateStr =
        '${entry.date.year}/${entry.date.month.toString().padLeft(2, '0')}/${entry.date.day.toString().padLeft(2, '0')}';

    return LuxuryCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // الشعار ونوع الدخل
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: isSalary
                          ? AppColors.forestGreen.withValues(alpha: 0.1)
                          : AppColors.champagneGold.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      isSalary ? Icons.account_balance_wallet : Icons.trending_up,
                      color: isSalary ? AppColors.forestGreen : AppColors.champagneGold,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.description,
                        style: AppTypography.headingH3.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${entry.source} • $dateStr',
                        style: AppTypography.bodySecondary,
                      ),
                    ],
                  ),
                ],
              ),
              // المبلغ المالي
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '+${entry.amount.formatArabic()}',
                    style: AppTypography.headingH2.copyWith(
                      color: entry.status == TransactionStatus.reversed
                          ? AppColors.slateMuted
                          : AppColors.cashIn,
                      fontWeight: FontWeight.w700,
                      decoration: entry.status == TransactionStatus.reversed
                          ? TextDecoration.lineThrough
                          : null,
                    ),
                  ),
                  const SizedBox(height: 4),
                  _buildStatusBadge(),
                ],
              ),
            ],
          ),

          if (entry.isDistributed && entry.distributionSummary != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.surfaceSubtleLight,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.borderSubtleLight),
              ),
              child: Row(
                children: [
                  const Icon(Icons.pie_chart, size: 16, color: AppColors.forestGreen),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'التوزيع: ${entry.distributionSummary}',
                      style: AppTypography.bodySecondary.copyWith(
                        fontSize: 12,
                        color: AppColors.forestGreen,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (entry.notes != null && entry.notes!.trim().isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'ملاحظات: ${entry.notes}',
              style: AppTypography.bodySecondary.copyWith(fontSize: 12),
            ),
          ],

          if (onCorrect != null && entry.status == TransactionStatus.completed) ...[
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: onCorrect,
                icon: const Icon(Icons.edit_note, size: 18, color: AppColors.slateMuted),
                label: Text(
                  'تصحيح المعاملة',
                  style: AppTypography.bodySecondary.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppColors.slateMuted,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatusBadge() {
    switch (entry.status) {
      case TransactionStatus.completed:
        return entry.isDistributed
            ? const StatusBadge(label: 'موزّع 100%', type: StatusBadgeType.success)
            : const StatusBadge(label: 'مباشر', type: StatusBadgeType.neutral);
      case TransactionStatus.reversed:
        return const StatusBadge(label: 'معكوس', type: StatusBadgeType.danger);
      case TransactionStatus.corrected:
        return const StatusBadge(label: 'مصحّح', type: StatusBadgeType.warning);
    }
  }
}

