import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/income_controller.dart';
import '../domain/entities/income_distribution_spec.dart';
import '../domain/entities/income_type.dart';
import '../widgets/income_distribution_preview_sheet.dart';

/// شاشة تسجيل الدخل الإضافي والحر (Record Additional Income Screen)
class RecordAdditionalIncomeScreen extends ConsumerStatefulWidget {
  const RecordAdditionalIncomeScreen({super.key});

  @override
  ConsumerState<RecordAdditionalIncomeScreen> createState() =>
      _RecordAdditionalIncomeScreenState();
}

class _RecordAdditionalIncomeScreenState
    extends ConsumerState<RecordAdditionalIncomeScreen> {
  final _amountController = TextEditingController();
  final _sourceController = TextEditingController(text: 'عمل حر / استشارة');
  final _descController = TextEditingController(text: 'مشروع إضافي');
  final _notesController = TextEditingController();

  DateTime _selectedDate = DateTime.now();
  String _selectedAccountId = 'acc_primary';
  final String _selectedAccountName = 'الحساب البنكي الرئيسي';
  bool _enableDistribution = true;

  @override
  void dispose() {
    _amountController.dispose();
    _sourceController.dispose();
    _descController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _onSubmitPressed() {
    final text = _amountController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال مبلغ الدخل أولاً')),
      );
      return;
    }

    try {
      final amount = Money.parse(text);
      if (!amount.isPositive) {
        throw ArgumentError('المبلغ يجب أن يكون موجباً');
      }

      if (_enableDistribution) {
        ref.read(incomeControllerProvider.notifier).generateDistributionPreview(amount);
        final state = ref.read(incomeControllerProvider);
        final preview = state.activePreview;

        if (preview != null) {
          _showPreviewModal(preview, amount);
        }
      } else {
        _executeDirectDeposit(amount);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في إدخال المبلغ: $e')),
      );
    }
  }

  Future<void> _executeDirectDeposit(Money amount) async {
    final key = 'add_inc_${DateTime.now().millisecondsSinceEpoch}';
    final success = await ref
        .read(incomeControllerProvider.notifier)
        .recordDirectIncome(
          accountId: _selectedAccountId,
          type: IncomeType.additional,
          amount: amount,
          date: _selectedDate,
          source: _sourceController.text.trim(),
          description: _descController.text.trim(),
          notes: _notesController.text.trim().isEmpty
              ? null
              : _notesController.text.trim(),
          idempotencyKey: key,
        );

    if (mounted && success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إيداع الدخل الإضافي في الحساب بنجاح')),
      );
      Navigator.pop(context);
    }
  }

  void _showPreviewModal(IncomeDistributionPreview preview, Money amount) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Consumer(
          builder: (context, ref, child) {
            final incomeState = ref.watch(incomeControllerProvider);

            return IncomeDistributionPreviewSheet(
              preview: preview,
              incomeType: IncomeType.additional,
              accountName: _selectedAccountName,
              isExecuting: incomeState.isExecutingDistribution,
              onCancel: () {
                ref.read(incomeControllerProvider.notifier).cancelDistributionPreview();
                Navigator.pop(ctx);
              },
              onConfirm: () async {
                final key = 'add_salary_${DateTime.now().millisecondsSinceEpoch}';
                final success = await ref
                    .read(incomeControllerProvider.notifier)
                    .confirmAndExecuteDistribution(
                      accountId: _selectedAccountId,
                      type: IncomeType.additional,
                      amount: amount,
                      date: _selectedDate,
                      source: _sourceController.text.trim(),
                      description: _descController.text.trim(),
                      notes: _notesController.text.trim().isEmpty
                          ? null
                          : _notesController.text.trim(),
                      idempotencyKey: key,
                    );

                if (mounted && success) {
                  Navigator.pop(ctx);
                  _showSuccessDialog(preview);
                }
              },
            );
          },
        );
      },
    );
  }

  void _showSuccessDialog(IncomeDistributionPreview preview) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: AppColors.surfaceLight,
        title: Row(
          children: [
            const Icon(Icons.check_circle, color: AppColors.cashIn, size: 28),
            const SizedBox(width: 10),
            Text('تم توزيع الدخل الإضافي', style: AppTypography.headingH2),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'تم توزيع ${preview.originalIncome.formatArabic()} بدقة تامة وتحديث الخزينة والمدخرات.',
              style: AppTypography.bodyPrimary,
            ),
            const SizedBox(height: 12),
            ...preview.items.map((item) => Text(
                  '• ${item.category.title}: ${item.amount.formatArabic()}',
                  style: AppTypography.bodySecondary,
                )),
          ],
        ),
        actions: [
          LuxuryButton(
            label: 'تم، العودة لسجل الدخل',
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('تسجيل دخل إضافي'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LuxuryCard(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'مبلغ الدخل الإضافي (ر.س)',
                    style: AppTypography.bodySecondary.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _amountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    style: AppTypography.financialNumberLarge.copyWith(
                      color: AppColors.champagneGold,
                      fontSize: 34,
                    ),
                    decoration: const InputDecoration(
                      hintText: '0.00',
                      border: InputBorder.none,
                      suffixText: 'ر.س',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            LuxuryCard(
              child: Column(
                children: [
                  TextField(
                    controller: _sourceController,
                    decoration: const InputDecoration(
                      labelText: 'المصدر / العميل / المنصة',
                      prefixIcon: Icon(Icons.work_outline, color: AppColors.champagneGold),
                      border: UnderlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _descController,
                    decoration: const InputDecoration(
                      labelText: 'وصف الدخل الإضافي',
                      prefixIcon: Icon(Icons.description_outlined, color: AppColors.champagneGold),
                      border: UnderlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.account_balance, color: AppColors.champagneGold),
                    title: Text('الحساب المستلم', style: AppTypography.bodySecondary),
                    subtitle: Text(_selectedAccountName, style: AppTypography.bodyPrimary),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_today, color: AppColors.champagneGold),
                    title: Text('تاريخ الاستلام', style: AppTypography.bodySecondary),
                    subtitle: Text(
                      '${_selectedDate.year}/${_selectedDate.month}/${_selectedDate.day}',
                      style: AppTypography.bodyPrimary,
                    ),
                    trailing: const Icon(Icons.edit_calendar, size: 18),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2030),
                      );
                      if (picked != null) {
                        setState(() => _selectedDate = picked);
                      }
                    },
                  ),
                  const Divider(),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('تطبيق التوزيع الذكي (40/20/20/10/10)', style: AppTypography.bodyPrimary),
                    subtitle: Text('توزيع الدخل الإضافي على بنود التوفير والميزانيات', style: AppTypography.bodySecondary),
                    value: _enableDistribution,
                    activeColor: AppColors.forestGreen,
                    onChanged: (val) => setState(() => _enableDistribution = val),
                  ),
                  TextField(
                    controller: _notesController,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'ملاحظات (اختياري)',
                      prefixIcon: Icon(Icons.notes, color: AppColors.slateMuted),
                      border: InputBorder.none,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            LuxuryButton(
              label: _enableDistribution ? 'معاينة التوزيع واعتماده' : 'إيداع الدخل في الحساب مباشرة',
              icon: _enableDistribution ? Icons.pie_chart_outline : Icons.save_alt,
              onPressed: _onSubmitPressed,
              type: LuxuryButtonType.primary,
            ),
          ],
        ),
      ),
    );
  }
}

