import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../domain/entities/income_entry.dart';
import '../../domain/entities/income_type.dart';
import '../../domain/repositories/income_repository.dart';

/// تطبيق مستودع الدخل بالاعتماد على قاعدة البيانات المحلية
class IncomeRepositoryImpl implements IncomeRepository {
  final AppDatabase _db;
  final Map<String, IncomeEntry> _localCache = {};

  IncomeRepositoryImpl(this._db);

  @override
  Future<void> saveIncome(IncomeEntry entry) async {
    _localCache[entry.id] = entry;
    // حفظ قيد المعاملة في جدول المعاملات
    final txnDao = _db.transactionsDao;
    await txnDao.insertTransaction(TransactionsCompanion.insert(
      id: entry.id,
      accountId: entry.accountId,
      type: 'income',
      amountMinorUnits: entry.amount.minorUnits,
      transactionDate: entry.date,
      note: Value('${entry.type.toDbString()}|${entry.source}|${entry.description}|${entry.notes ?? ''}'),
      createdAt: entry.createdAt,
    ));
  }

  @override
  Future<List<IncomeEntry>> getAllIncomes() async {
    final list = _localCache.values.toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<List<IncomeEntry>> getIncomesByType(IncomeType type) async {
    final list = _localCache.values.where((i) => i.type == type).toList();
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<IncomeEntry?> getIncomeById(String id) async => _localCache[id];

  @override
  Future<void> updateIncomeStatus(String id, TransactionStatus status) async {
    final item = _localCache[id];
    if (item != null) {
      _localCache[id] = item.copyWith(status: status);
    }
  }

  @override
  Future<Money> getTotalIncomeByType(IncomeType type) async {
    final items = _localCache.values
        .where((i) => i.type == type && i.status != TransactionStatus.reversed);
    return items.fold<Money>(
      const Money.zero(),
      (sum, item) => sum + item.amount,
    );
  }

  @override
  Future<Money> getTotalIncomeAll() async {
    final items = _localCache.values
        .where((i) => i.status != TransactionStatus.reversed);
    return items.fold<Money>(
      const Money.zero(),
      (sum, item) => sum + item.amount,
    );
  }
}

