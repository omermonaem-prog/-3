import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../entities/income_entry.dart';
import '../entities/income_type.dart';

/// العقد المجرد لمستودع إدارة وتتبع الدخل
abstract class IncomeRepository {
  Future<void> saveIncome(IncomeEntry entry);
  Future<List<IncomeEntry>> getAllIncomes();
  Future<List<IncomeEntry>> getIncomesByType(IncomeType type);
  Future<IncomeEntry?> getIncomeById(String id);
  Future<void> updateIncomeStatus(String id, TransactionStatus status);
  Future<Money> getTotalIncomeByType(IncomeType type);
  Future<Money> getTotalIncomeAll();
}

