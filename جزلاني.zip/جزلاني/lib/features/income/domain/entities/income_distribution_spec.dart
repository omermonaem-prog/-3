import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/allocation_plan.dart';

/// بنود التوزيع المالي الإلزامية المحددة في النظام 03
class IncomeDistributionCategory {
  final String key;
  final String title;
  final double percentage; // النسبة المئوية
  final AllocationTargetType targetType;
  final String iconName;
  final String colorHex;

  const IncomeDistributionCategory({
    required this.key,
    required this.title,
    required this.percentage,
    required this.targetType,
    required this.iconName,
    required this.colorHex,
  });
}

/// المواصفة الصارمة لتوزيع الدخل في مشروع MyFinance
class IncomeDistributionSpec {
  IncomeDistributionSpec._();

  /// قائمة الأقسام الخمسة المعتمدة ونسبها المئوية الصارمة:
  /// 1. المسؤوليات والبيت: 40%
  /// 2. الادخار العام: 20%
  /// 3. صندوق الطوارئ: 20%
  /// 4. تطوير المهارات والعمل: 10%
  /// 5. الترفيه: 10%
  static const List<IncomeDistributionCategory> standardCategories = [
    IncomeDistributionCategory(
      key: 'responsibilities',
      title: 'المسؤوليات والبيت',
      percentage: 40.0,
      targetType: AllocationTargetType.obligation,
      iconName: 'home',
      colorHex: '#0E3B2E', // أخضر الغابة الداكن
    ),
    IncomeDistributionCategory(
      key: 'general_savings',
      title: 'الادخار العام',
      percentage: 20.0,
      targetType: AllocationTargetType.flexibleBudget,
      iconName: 'piggy-bank',
      colorHex: '#C5A059', // ذهب شامبين
    ),
    IncomeDistributionCategory(
      key: 'emergency_fund',
      title: 'صندوق الطوارئ',
      percentage: 20.0,
      targetType: AllocationTargetType.emergencyFund,
      iconName: 'shield-alert',
      colorHex: '#8C1D1D', // أحمر وقاري
    ),
    IncomeDistributionCategory(
      key: 'skills_and_work',
      title: 'تطوير المهارات والعمل',
      percentage: 10.0,
      targetType: AllocationTargetType.flexibleBudget,
      iconName: 'briefcase',
      colorHex: '#165342', // زمرد تفاعلي
    ),
    IncomeDistributionCategory(
      key: 'entertainment',
      title: 'الترفيه',
      percentage: 10.0,
      targetType: AllocationTargetType.flexibleBudget,
      iconName: 'smile',
      colorHex: '#DFBC75', // بريق ذهبي
    ),
  ];

  /// التحقق من أن مجموع النسب يساوي 100%
  static double get totalPercentage =>
      standardCategories.fold(0.0, (sum, cat) => sum + cat.percentage);

  /// توليد معاينة التوزيع بدقة الهللة مع حماية Largest Remainder Method
  static IncomeDistributionPreview calculatePreview(Money incomeAmount) {
    if (!incomeAmount.isPositive) {
      throw ArgumentError('مبلغ الدخل يجب أن يكون موجباً لإنشاء التوزيع');
    }

    final percentages = standardCategories.map((c) => c.percentage).toList();
    // توزيع المبالغ بدقة الهللة دون فقدان أي كسر
    final shares = Money.apportionByPercentages(incomeAmount, percentages);

    final items = <IncomeDistributionPreviewItem>[];
    var calculatedTotal = const Money.zero();

    for (var i = 0; i < standardCategories.length; i++) {
      final cat = standardCategories[i];
      final share = shares[i];
      calculatedTotal += share;

      items.add(IncomeDistributionPreviewItem(
        category: cat,
        amount: share,
      ));
    }

    // التأكد من استيفاء شرط القيد الصفري بالكامل
    assert(calculatedTotal == incomeAmount, 'فشل القيد الصفري: مجموع الحصص لا يطابق الدخل الأصلي');

    return IncomeDistributionPreview(
      originalIncome: incomeAmount,
      items: items,
      totalDistributed: calculatedTotal,
    );
  }
}

/// بند في معاينة التوزيع
class IncomeDistributionPreviewItem {
  final IncomeDistributionCategory category;
  final Money amount;

  const IncomeDistributionPreviewItem({
    required this.category,
    required this.amount,
  });
}

/// ملخص معاينة التوزيع التفاعلي
class IncomeDistributionPreview {
  final Money originalIncome;
  final List<IncomeDistributionPreviewItem> items;
  final Money totalDistributed;

  const IncomeDistributionPreview({
    required this.originalIncome,
    required this.items,
    required this.totalDistributed,
  });

  /// التحقق من أن مجموع الموزع يساوي الأصلي تماماً
  bool get isZeroSumValid => originalIncome == totalDistributed;
}

