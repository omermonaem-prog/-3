import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import 'income_type.dart';

/// سجل تدفق الدخل المالي (Income Domain Entity)
class IncomeEntry {
  final String id;
  final String accountId;
  final String? accountName;
  final IncomeType type;
  final Money amount;
  final DateTime date;
  final String source;       // جهة العمل، العميل، المنصة
  final String description;  // راتب أكتوبر، أرباح استثمار، استشارة
  final String? notes;       // ملاحظات إضافية
  final bool isDistributed;  // هل تم تطبيق تدفق التوزيع الخماسي المعتمد
  final String? distributionSummary;
  final TransactionStatus status;
  final String idempotencyKey;
  final DateTime createdAt;

  const IncomeEntry({
    required this.id,
    required this.accountId,
    this.accountName,
    required this.type,
    required this.amount,
    required this.date,
    required this.source,
    required this.description,
    this.notes,
    this.isDistributed = false,
    this.distributionSummary,
    this.status = TransactionStatus.completed,
    required this.idempotencyKey,
    required this.createdAt,
  });

  IncomeEntry copyWith({
    String? id,
    String? accountId,
    String? accountName,
    IncomeType? type,
    Money? amount,
    DateTime? date,
    String? source,
    String? description,
    String? notes,
    bool? isDistributed,
    String? distributionSummary,
    TransactionStatus? status,
    String? idempotencyKey,
    DateTime? createdAt,
  }) {
    return IncomeEntry(
      id: id ?? this.id,
      accountId: accountId ?? this.accountId,
      accountName: accountName ?? this.accountName,
      type: type ?? this.type,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      source: source ?? this.source,
      description: description ?? this.description,
      notes: notes ?? this.notes,
      isDistributed: isDistributed ?? this.isDistributed,
      distributionSummary: distributionSummary ?? this.distributionSummary,
      status: status ?? this.status,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is IncomeEntry &&
        other.id == id &&
        other.type == type &&
        other.amount == amount &&
        other.idempotencyKey == idempotencyKey;
  }

  @override
  int get hashCode =>
      id.hashCode ^ type.hashCode ^ amount.hashCode ^ idempotencyKey.hashCode;

  @override
  String toString() =>
      'IncomeEntry(id: $id, type: ${type.name}, amount: ${amount.formatArabic()}, source: $source)';
}

