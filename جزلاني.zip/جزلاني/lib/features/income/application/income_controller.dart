import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/database/providers/database_providers.dart';
import '../../../../core/finance/money.dart';
import '../../financial_engine/application/central_financial_engine.dart';
import '../../financial_engine/domain/entities/allocation_plan.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../financial_engine/presentation/providers/financial_engine_providers.dart';
import '../data/repositories/income_repository_impl.dart';
import '../domain/entities/income_distribution_spec.dart';
import '../domain/entities/income_entry.dart';
import '../domain/entities/income_type.dart';
import '../domain/repositories/income_repository.dart';
import 'income_state.dart';

/// مزود مستودع الدخل
final incomeRepositoryProvider = Provider<IncomeRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return IncomeRepositoryImpl(db);
});

/// مزود متحكم الدخل (Income Controller Provider)
final incomeControllerProvider =
    StateNotifierProvider<IncomeController, IncomeState>((ref) {
  final engine = ref.watch(centralFinancialEngineProvider);
  final repo = ref.watch(incomeRepositoryProvider);
  return IncomeController(engine: engine, repository: repo);
});

/// المتحكم المسؤول عن تدفقات الدخل وتوزيع الراتب
class IncomeController extends StateNotifier<IncomeState> {
  final CentralFinancialEngine _engine;
  final IncomeRepository _repository;

  IncomeController({
    required CentralFinancialEngine engine,
    required IncomeRepository repository,
  })  : _engine = engine,
        _repository = repository,
        super(const IncomeState()) {
    loadIncomes();
  }

  /// تحميل كافة سجلات الدخل واحتساب الإجماليات
  Future<void> loadIncomes() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final incomes = await _repository.getAllIncomes();
      final salaryTotal = await _repository.getTotalIncomeByType(IncomeType.salary);
      final additionalTotal = await _repository.getTotalIncomeByType(IncomeType.additional);
      final allTotal = await _repository.getTotalIncomeAll();

      state = state.copyWith(
        isLoading: false,
        incomes: incomes,
        totalSalary: salaryTotal,
        totalAdditional: additionalTotal,
        totalAll: allTotal,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'تعذر تحميل سجلات الدخل: $e',
      );
    }
  }

  /// تبديل التصفية (الكل / الراتب الأساسي / الدخل الإضافي)
  void setFilter(IncomeFilter filter) {
    state = state.copyWith(filter: filter);
  }

  /// ── المرحلة 1: إنشاء معاينة توزيع النسب ──
  ///
  /// المسؤوليات 40%، الادخار 20%، الطوارئ 20%، المهارات 10%، الترفيه 10%
  void generateDistributionPreview(Money amount) {
    if (!amount.isPositive) {
      state = state.copyWith(
        errorMessage: 'يجب إدخال مبلغ موجب أكبر من الصفر',
      );
      return;
    }
    final preview = IncomeDistributionSpec.calculatePreview(amount);
    state = state.copyWith(
      activePreview: preview,
      clearError: true,
    );
  }

  /// ── المرحلة 2: إلغاء المعاينة دون أي تغيير في الأرصدة ──
  void cancelDistributionPreview() {
    state = state.copyWith(
      clearActivePreview: true,
      clearError: true,
    );
  }

  /// ── المرحلة 3: تأكيد وتنفيذ التوزيع ذرياً ──
  ///
  /// يستدعي المحرك المالي المركزي ذرياً، ويمنع النقر المكرر قطعياً
  Future<bool> confirmAndExecuteDistribution({
    required String accountId,
    required IncomeType type,
    required Money amount,
    required DateTime date,
    required String source,
    required String description,
    String? notes,
    required String idempotencyKey,
  }) async {
    // 1. حراسة النقر المتكرر (Prevent Double Execution)
    if (state.isExecutingDistribution) {
      return false;
    }

    final preview = state.activePreview;
    if (preview == null || preview.originalIncome != amount) {
      state = state.copyWith(
        errorMessage: 'يجب مراجعة معاينة التوزيع قبل التأكيد',
      );
      return false;
    }

    state = state.copyWith(isExecutingDistribution: true, clearError: true);

    try {
      final incomeId = 'inc_${DateTime.now().millisecondsSinceEpoch}';

      // 2. إعداد بنود الخطة للمحرك المالي
      final planItems = preview.items.map((item) {
        return AllocationPlanItem(
          id: '${incomeId}_${item.category.key}',
          title: item.category.title,
          targetType: item.category.targetType,
          targetId: item.category.key,
          mode: AllocationMode.percentage,
          percentage: item.category.percentage,
        );
      }).toList();

      final plan = AllocationPlan(
        id: 'plan_$incomeId',
        title: '${type.arabicLabel}: $description',
        totalIncome: amount,
        items: planItems,
        isConfirmed: true, // تأكيد صريح
        createdAt: date,
      );

      // 3. الاستدعاء الذري للمحرك المالي المركزي
      await _engine.executeIncomeAllocation(
        plan: plan,
        depositAccountId: accountId,
        idempotencyKey: idempotencyKey,
      );

      // 4. حفظ سجل الدخل في المستودع
      final summary = preview.items
          .map((i) => '${i.category.title}: ${i.amount.formatArabic()}')
          .join(' | ');

      final incomeEntry = IncomeEntry(
        id: incomeId,
        accountId: accountId,
        type: type,
        amount: amount,
        date: date,
        source: source,
        description: description,
        notes: notes,
        isDistributed: true,
        distributionSummary: summary,
        status: TransactionStatus.completed,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveIncome(incomeEntry);

      // 5. تحديث الحالة بالنتيجة والبيانات الجديدة
      await loadIncomes();

      state = state.copyWith(
        isExecutingDistribution: false,
        clearActivePreview: true,
        lastExecutedResult: preview,
        successMessage: 'تم تأكيد واعتماد توزيع ${type.arabicLabel} بنجاح',
      );

      return true;
    } catch (e) {
      state = state.copyWith(
        isExecutingDistribution: false,
        errorMessage: 'فشل تنفيذ التوزيع المالي: $e',
      );
      return false;
    }
  }

  /// تسجيل دخل مباشر دون تدفق التوزيع (حسب رغبة المستخدم)
  Future<bool> recordDirectIncome({
    required String accountId,
    required IncomeType type,
    required Money amount,
    required DateTime date,
    required String source,
    required String description,
    String? notes,
    required String idempotencyKey,
  }) async {
    if (state.isExecutingDistribution) return false;
    state = state.copyWith(isExecutingDistribution: true, clearError: true);

    try {
      final incomeId = 'inc_dir_${DateTime.now().millisecondsSinceEpoch}';

      await _engine.recordIncome(
        transactionId: incomeId,
        accountId: accountId,
        categoryId: null,
        amount: amount,
        date: date,
        note: '${type.arabicLabel} - $description ($source)',
        idempotencyKey: idempotencyKey,
      );

      final entry = IncomeEntry(
        id: incomeId,
        accountId: accountId,
        type: type,
        amount: amount,
        date: date,
        source: source,
        description: description,
        notes: notes,
        isDistributed: false,
        status: TransactionStatus.completed,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveIncome(entry);
      await loadIncomes();

      state = state.copyWith(
        isExecutingDistribution: false,
        successMessage: 'تم تسجيل ${type.arabicLabel} في الحساب بنجاح',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isExecutingDistribution: false,
        errorMessage: 'فشل تسجيل الدخل: $e',
      );
      return false;
    }
  }

  /// ── المرحلة 6: تعديل الدخل وفق سياسة تصحيح المعاملات المعتمدة ──
  ///
  /// يعكس المعاملة الأصلية أولاً ثم يثبت المعاملة المصححة مع ربطهما في السجل
  Future<bool> correctIncome({
    required String originalIncomeId,
    required Money newAmount,
    required DateTime newDate,
    required String newSource,
    required String newDescription,
    String? newNotes,
    required String reason,
    required String idempotencyKey,
  }) async {
    state = state.copyWith(isExecutingDistribution: true, clearError: true);
    try {
      final original = await _repository.getIncomeById(originalIncomeId);
      if (original == null) {
        throw ArgumentError('سجل الدخل الأصلي غير موجود');
      }

      final correctedTxnId = 'inc_corr_${DateTime.now().millisecondsSinceEpoch}';
      final correctedTxn = TransactionEntity(
        id: correctedTxnId,
        accountId: original.accountId,
        type: TransactionType.income,
        amount: newAmount,
        transactionDate: newDate,
        note: 'تصحيح دخل: $newDescription ($reason)',
        createdAt: DateTime.now(),
      );

      // الاستدعاء المحاسبي لعكس القديمة وإثبات الجديدة
      await _engine.correctTransaction(
        originalTransactionId: originalIncomeId,
        reversalTransactionId: 'rev_$originalIncomeId',
        correctedTransaction: correctedTxn,
        reason: reason,
        idempotencyKey: idempotencyKey,
      );

      // تحديث حالة السجل القديم إلى reversed
      await _repository.updateIncomeStatus(originalIncomeId, TransactionStatus.reversed);

      // حفظ السجل المصحح
      final correctedEntry = IncomeEntry(
        id: correctedTxnId,
        accountId: original.accountId,
        type: original.type,
        amount: newAmount,
        date: newDate,
        source: newSource,
        description: newDescription,
        notes: newNotes,
        isDistributed: original.isDistributed,
        status: TransactionStatus.corrected,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveIncome(correctedEntry);
      await loadIncomes();

      state = state.copyWith(
        isExecutingDistribution: false,
        successMessage: 'تم تصحيح سجل الدخل وربطه بالسجل الأصلي بنجاح',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isExecutingDistribution: false,
        errorMessage: 'فشل تصحيح الدخل: $e',
      );
      return false;
    }
  }

  void clearMessages() {
    state = state.copyWith(clearError: true, clearSuccess: true);
  }
}
