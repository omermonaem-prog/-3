import '../../../../core/finance/money.dart';
import '../domain/entities/income_distribution_spec.dart';
import '../domain/entities/income_entry.dart';
import '../domain/entities/income_type.dart';

enum IncomeFilter {
  all,
  salary,
  additional;

  String get labelArabic {
    switch (this) {
      case IncomeFilter.all:
        return 'الكل';
      case IncomeFilter.salary:
        return 'الراتب الأساسي';
      case IncomeFilter.additional:
        return 'الدخل الإضافي';
    }
  }
}

/// حالة إدارة وتوزيع الدخل في التطبيق
class IncomeState {
  final bool isLoading;
  final List<IncomeEntry> incomes;
  final IncomeFilter filter;
  final IncomeDistributionPreview? activePreview;
  final bool isExecutingDistribution;
  final IncomeDistributionPreview? lastExecutedResult;
  final Money totalSalary;
  final Money totalAdditional;
  final Money totalAll;
  final String? errorMessage;
  final String? successMessage;

  const IncomeState({
    this.isLoading = false,
    this.incomes = const [],
    this.filter = IncomeFilter.all,
    this.activePreview,
    this.isExecutingDistribution = false,
    this.lastExecutedResult,
    this.totalSalary = const Money.zero(),
    this.totalAdditional = const Money.zero(),
    this.totalAll = const Money.zero(),
    this.errorMessage,
    this.successMessage,
  });

  /// تصفية السجلات حسب التبويب المختار
  List<IncomeEntry> get filteredIncomes {
    switch (filter) {
      case IncomeFilter.all:
        return incomes;
      case IncomeFilter.salary:
        return incomes.where((i) => i.type == IncomeType.salary).toList();
      case IncomeFilter.additional:
        return incomes.where((i) => i.type == IncomeType.additional).toList();
    }
  }

  IncomeState copyWith({
    bool? isLoading,
    List<IncomeEntry>? incomes,
    IncomeFilter? filter,
    IncomeDistributionPreview? activePreview,
    bool clearActivePreview = false,
    bool? isExecutingDistribution,
    IncomeDistributionPreview? lastExecutedResult,
    bool clearLastResult = false,
    Money? totalSalary,
    Money? totalAdditional,
    Money? totalAll,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return IncomeState(
      isLoading: isLoading ?? this.isLoading,
      incomes: incomes ?? this.incomes,
      filter: filter ?? this.filter,
      activePreview: clearActivePreview ? null : (activePreview ?? this.activePreview),
      isExecutingDistribution: isExecutingDistribution ?? this.isExecutingDistribution,
      lastExecutedResult: clearLastResult ? null : (lastExecutedResult ?? this.lastExecutedResult),
      totalSalary: totalSalary ?? this.totalSalary,
      totalAdditional: totalAdditional ?? this.totalAdditional,
      totalAll: totalAll ?? this.totalAll,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage: clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

