import 'dart:convert';
import 'dart:typed_data';

/// خدمة التحقق من سلامة البيانات والتجزئة الرقمية (Data Integrity & SHA-256 Verifier)
///
/// تطبيق خوارزمية SHA-256 القياسية الصارمة بـ Pure Dart لضمان عدم وجود أي تبعيات خارجية
/// والتحقق من سلامة ملفات النسخ الاحتياطي وكشف أي تلاعب أو تلف قبل الاستعادة.
class DataIntegrityVerifier {
  /// توليد بصمة SHA-256 لأي نص أو كائن
  static String calculateSha256(String input) {
    final bytes = utf8.encode(input);
    final digest = _sha256(Uint8List.fromList(bytes));
    return digest.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// التحقق من مطابقة البصمة
  static bool verifyChecksum({
    required String data,
    required String expectedChecksum,
  }) {
    final computed = calculateSha256(data);
    return computed.toLowerCase() == expectedChecksum.toLowerCase();
  }

  // ── تنفيذ خوارزمية SHA-256 القياسية (FIPS 180-4) ───────────────

  static const List<int> _k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  static Uint8List _sha256(Uint8List message) {
    final bitLength = message.length * 8;

    final padLength = (message.length + 9) % 64 == 0
        ? 0
        : 64 - ((message.length + 9) % 64);
    final totalLength = message.length + 1 + padLength + 8;

    final padded = Uint8List(totalLength);
    padded.setRange(0, message.length, message);
    padded[message.length] = 0x80;

    final byteData = ByteData.sublistView(padded);
    byteData.setUint64(totalLength - 8, bitLength, Endian.big);

    var h0 = 0x6a09e667;
    var h1 = 0xbb67ae85;
    var h2 = 0x3c6ef372;
    var h3 = 0xa54ff53a;
    var h4 = 0x510e527f;
    var h5 = 0x9b05688c;
    var h6 = 0x1f83d9ab;
    var h7 = 0x5be0cd19;

    final w = Int32List(64);

    for (var chunk = 0; chunk < totalLength; chunk += 64) {
      for (var i = 0; i < 16; i++) {
        w[i] = byteData.getUint32(chunk + i * 4, Endian.big);
      }
      for (var i = 16; i < 64; i++) {
        final s0 = _rotr(w[i - 15], 7) ^ _rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        final s1 = _rotr(w[i - 2], 17) ^ _rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & 0xffffffff;
      }

      var a = h0;
      var b = h1;
      var c = h2;
      var d = h3;
      var e = h4;
      var f = h5;
      var g = h6;
      var h = h7;

      for (var i = 0; i < 64; i++) {
        final s1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25);
        final ch = (e & f) ^ ((~e) & g);
        final temp1 = (h + s1 + ch + _k[i] + w[i]) & 0xffffffff;
        final s0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22);
        final maj = (a & b) ^ (a & c) ^ (b & c);
        final temp2 = (s0 + maj) & 0xffffffff;

        h = g;
        g = f;
        f = e;
        e = (d + temp1) & 0xffffffff;
        d = c;
        c = b;
        b = a;
        a = (temp1 + temp2) & 0xffffffff;
      }

      h0 = (h0 + a) & 0xffffffff;
      h1 = (h1 + b) & 0xffffffff;
      h2 = (h2 + c) & 0xffffffff;
      h3 = (h3 + d) & 0xffffffff;
      h4 = (h4 + e) & 0xffffffff;
      h5 = (h5 + f) & 0xffffffff;
      h6 = (h6 + g) & 0xffffffff;
      h7 = (h7 + h) & 0xffffffff;
    }

    final result = Uint8List(32);
    final outData = ByteData.sublistView(result);
    outData.setUint32(0, h0, Endian.big);
    outData.setUint32(4, h1, Endian.big);
    outData.setUint32(8, h2, Endian.big);
    outData.setUint32(12, h3, Endian.big);
    outData.setUint32(16, h4, Endian.big);
    outData.setUint32(20, h5, Endian.big);
    outData.setUint32(24, h6, Endian.big);
    outData.setUint32(28, h7, Endian.big);

    return result;
  }

  static int _rotr(int val, int n) =>
      ((val >>> n) | (val << (32 - n))) & 0xffffffff;
}

