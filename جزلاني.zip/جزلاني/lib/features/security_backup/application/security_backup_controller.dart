import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/database/providers/database_providers.dart';
import '../data/repositories/security_backup_repository_impl.dart';
import '../domain/entities/app_lock_config.dart';
import '../domain/entities/backup_payload.dart';
import '../domain/repositories/security_backup_repository.dart';
import 'security_backup_state.dart';
import 'services/app_lock_service.dart';

/// موفر مستودع الأمان والنسخ الاحتياطي
final securityBackupRepositoryProvider =
    Provider<SecurityBackupRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return SecurityBackupRepositoryImpl(db);
});

/// موفر متحكم الأمان والنسخ الاحتياطي
final securityBackupControllerProvider =
    StateNotifierProvider<SecurityBackupController, SecurityBackupState>((ref) {
  final repo = ref.watch(securityBackupRepositoryProvider);
  return SecurityBackupController(repository: repo);
});

/// متحكم إدارة الأمان وقفل التطبيق والنسخ الاحتياطي والاستعادة
class SecurityBackupController extends StateNotifier<SecurityBackupState> {
  final SecurityBackupRepository _repository;

  SecurityBackupController({
    required SecurityBackupRepository repository,
  })  : _repository = repository,
        super(const SecurityBackupState()) {
    loadAll();
  }

  /// تحميل إعدادات القفل وقائمة النسخ الاحتياطية
  Future<void> loadAll() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final config = await _repository.getAppLockConfig();
      final backups = await _repository.getAllBackups();

      state = state.copyWith(
        isLoading: false,
        lockConfig: config,
        isAppLocked: config.isLockEnabled && config.pinHash != null,
        backups: backups,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تحميل بيانات الأمان والنسخ الاحتياطي: $e',
      );
    }
  }

  // ══════════════════════════════════════════════════════════════════
  // ── قفل التطبيق ورمز PIN (App Lock & Security) ───────────────────
  // ══════════════════════════════════════════════════════════════════

  /// تفعيل قفل التطبيق وتعيين رمز PIN جديد
  Future<bool> enablePinLock(String pin) async {
    if (pin.length < 4 || pin.length > 6) {
      state = state.copyWith(errorMessage: 'رمز PIN يجب أن يتكون من 4 إلى 6 أرقام');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final salt = AppLockService.generateSalt();
      final hash = AppLockService.hashPin(pin, salt);

      final newConfig = state.lockConfig.copyWith(
        isLockEnabled: true,
        pinHash: hash,
        salt: salt,
        failedAttempts: 0,
        lastActiveTimestamp: DateTime.now(),
      );

      await _repository.saveAppLockConfig(newConfig);
      state = state.copyWith(
        isLoading: false,
        lockConfig: newConfig,
        isAppLocked: false,
        successMessage: 'تم تفعيل قفل التطبيق برمز PIN بنجاح',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تفعيل قفل التطبيق: $e',
      );
      return false;
    }
  }

  /// إلغاء قفل التطبيق بعد التحقق من الرمز الحالي
  Future<bool> disablePinLock(String currentPin) async {
    final config = state.lockConfig;
    if (config.pinHash == null || config.salt == null) {
      return true;
    }

    final isValid = AppLockService.verifyPin(
      inputPin: currentPin,
      salt: config.salt!,
      expectedHash: config.pinHash!,
    );

    if (!isValid) {
      state = state.copyWith(errorMessage: 'رمز PIN الحالي غير صحيح');
      return false;
    }

    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final newConfig = config.copyWith(
        isLockEnabled: false,
        clearPin: true,
        failedAttempts: 0,
      );
      await _repository.saveAppLockConfig(newConfig);

      state = state.copyWith(
        isLoading: false,
        lockConfig: newConfig,
        isAppLocked: false,
        successMessage: 'تم إلغاء قفل التطبيق بنجاح',
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل إلغاء القفل: $e',
      );
      return false;
    }
  }

  /// فتح قفل التطبيق بواسطة PIN
  bool unlockWithPin(String pin) {
    final config = state.lockConfig;

    if (config.isTemporarilyLocked) {
      state = state.copyWith(
        errorMessage: 'التطبيق محظور مؤقتاً بسبب تكرار المحاولات الخاطئة. يرجى الانتظار.',
      );
      return false;
    }

    if (config.pinHash == null || config.salt == null) {
      state = state.copyWith(isAppLocked: false);
      return true;
    }

    final isValid = AppLockService.verifyPin(
      inputPin: pin,
      salt: config.salt!,
      expectedHash: config.pinHash!,
    );

    if (isValid) {
      final updatedConfig = config.copyWith(
        failedAttempts: 0,
        lastActiveTimestamp: DateTime.now(),
      );
      _repository.saveAppLockConfig(updatedConfig);
      state = state.copyWith(
        isAppLocked: false,
        lockConfig: updatedConfig,
        clearError: true,
      );
      return true;
    } else {
      final attempts = config.failedAttempts + 1;
      DateTime? lockedUntil;
      if (attempts >= 5) {
        lockedUntil = DateTime.now().add(const Duration(seconds: 30));
      }

      final updatedConfig = config.copyWith(
        failedAttempts: attempts,
        lockedUntil: lockedUntil,
      );
      _repository.saveAppLockConfig(updatedConfig);

      state = state.copyWith(
        lockConfig: updatedConfig,
        errorMessage: attempts >= 5
            ? 'تم حظر الإدخال مؤقتاً لمدة 30 ثانية لتكرار الأخطاء'
            : 'رمز PIN غير صحيح (محاولة $attempts من 5)',
      );
      return false;
    }
  }

  /// تحديث مهلة القفل التلقائي
  Future<void> updateAutoLockTimeout(int seconds) async {
    final updated = state.lockConfig.copyWith(
      autoLockTimeoutSeconds: seconds,
    );
    await _repository.saveAppLockConfig(updated);
    state = state.copyWith(lockConfig: updated);
  }

  // ══════════════════════════════════════════════════════════════════
  // ── النسخ الاحتياطي والاستعادة (Backup & Restore) ─────────────────
  // ══════════════════════════════════════════════════════════════════

  /// إنشاء نسخة احتياطية يدوية فورية
  Future<BackupPayload?> createManualBackup() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final payload = await _repository.createBackupPayload(isAutomatic: false);
      await loadAll();
      state = state.copyWith(
        successMessage: 'تم إنشاء النسخة الاحتياطية بنجاح (${payload.metadata.formattedSize})',
      );
      return payload;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل إنشاء النسخة الاحتياطية: $e',
      );
      return null;
    }
  }

  /// استعادة البيانات من نسخة احتياطية مسجلة
  Future<bool> restoreBackup(String backupId) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final payload = await _repository.getBackupPayload(backupId);
      if (payload == null) {
        state = state.copyWith(
          isLoading: false,
          errorMessage: 'ملف النسخة الاحتياطية غير موجود',
        );
        return false;
      }

      final success = await _repository.restoreFromPayload(payload);
      if (success) {
        await loadAll();
        state = state.copyWith(
          successMessage: 'تمت استعادة البيانات بنجاح والتحقق من سلامة الأرصدة 🎯',
        );
        return true;
      }
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل استعادة البيانات: $e',
      );
      return false;
    }
  }

  /// استعادة البيانات من نص JSON (ملف مستورد)
  Future<bool> restoreFromJsonString(String jsonStr) async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final payload = BackupPayload.fromJsonString(jsonStr);
      final success = await _repository.restoreFromPayload(payload);
      if (success) {
        await _repository.saveBackup(payload);
        await loadAll();
        state = state.copyWith(
          successMessage: 'تم فحص بصمة الملف واستعادة البيانات بنجاح 🎯',
        );
        return true;
      }
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل استعادة الملف المستورد: $e',
      );
      return false;
    }
  }

  /// حذف نسخة احتياطية
  Future<void> deleteBackup(String backupId) async {
    try {
      await _repository.deleteBackup(backupId);
      await loadAll();
    } catch (e) {
      state = state.copyWith(errorMessage: 'فشل حذف النسخة: $e');
    }
  }
}

