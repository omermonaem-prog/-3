import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../application/security_backup_controller.dart';
import 'app_lock_screen.dart';
import 'backup_management_screen.dart';

/// شاشة الإعدادات العامة والأمان والنسخ الاحتياطي
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  void _showSetPinDialog(BuildContext context, WidgetRef ref) {
    final controller = ref.read(securityBackupControllerProvider.notifier);
    final pinController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('تعيين رمز PIN لقفل التطبيق', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              decoration: InputDecoration(
                labelText: 'رمز PIN الجديد (4 إلى 6 أرقام) *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.lock_outline),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              final pin = pinController.text.trim();
              if (pin.length >= 4) {
                await controller.enablePinLock(pin);
                if (context.mounted) Navigator.pop(ctx);
              }
            },
            child: const Text('حفظ وتفعيل'),
          ),
        ],
      ),
    );
  }

  void _showDisablePinDialog(BuildContext context, WidgetRef ref) {
    final controller = ref.read(securityBackupControllerProvider.notifier);
    final pinController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('إلغاء قفل التطبيق', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('يرجى إدخال رمز PIN الحالي للتأكيد:', style: AppTypography.bodySecondary),
            const SizedBox(height: 12),
            TextField(
              controller: pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              decoration: InputDecoration(
                labelText: 'رمز PIN الحالي *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.lock_open_rounded),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.criticalRed,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              final success = await controller.disablePinLock(pinController.text.trim());
              if (success && context.mounted) Navigator.pop(ctx);
            },
            child: const Text('إلغاء القفل'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(securityBackupControllerProvider);
    final controller = ref.read(securityBackupControllerProvider.notifier);
    final lockConfig = state.lockConfig;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الإعدادات والأمان والنسخ الاحتياطي'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 1. قسم أمان وقفل التطبيق
            Text('أمان التطبيق وقفل الشاشة', style: AppTypography.headingH3),
            const SizedBox(height: 10),
            LuxuryCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  SwitchListTile(
                    value: lockConfig.isLockEnabled,
                    onChanged: (val) {
                      if (val) {
                        _showSetPinDialog(context, ref);
                      } else {
                        _showDisablePinDialog(context, ref);
                      }
                    },
                    title: const Text('قفل التطبيق برمز PIN'),
                    subtitle: Text(
                      lockConfig.isLockEnabled ? 'القفل مفعل برمز PIN مشفر' : 'التطبيق غير مقفل',
                      style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                    ),
                    activeColor: AppColors.forestGreen,
                  ),
                  if (lockConfig.isLockEnabled) ...[
                    const Divider(height: 16),
                    ListTile(
                      title: const Text('مهلة القفل التلقائي'),
                      subtitle: Text(
                        _getTimeoutLabel(lockConfig.autoLockTimeoutSeconds),
                        style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                      ),
                      trailing: DropdownButton<int>(
                        value: lockConfig.autoLockTimeoutSeconds,
                        underline: const SizedBox(),
                        items: const [
                          DropdownMenuItem(value: 0, child: Text('فوراً')),
                          DropdownMenuItem(value: 60, child: Text('بعد دقيقة')),
                          DropdownMenuItem(value: 300, child: Text('بعد 5 دقائق')),
                          DropdownMenuItem(value: 900, child: Text('بعد 15 دقيقة')),
                          DropdownMenuItem(value: -1, child: Text('أبداً')),
                        ],
                        onChanged: (val) {
                          if (val != null) controller.updateAutoLockTimeout(val);
                        },
                      ),
                    ),
                    const Divider(height: 16),
                    TextButton.icon(
                      onPressed: () => _showSetPinDialog(context, ref),
                      icon: const Icon(Icons.key_rounded, size: 18),
                      label: const Text('تغيير رمز PIN'),
                      style: TextButton.styleFrom(foregroundColor: AppColors.forestGreen),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 2. قسم النسخ الاحتياطي والاستعادة
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('النسخ الاحتياطي والاستعادة', style: AppTypography.headingH3),
                StatusBadge(
                  text: '${state.backups.length} نسخ محفوظة',
                  color: AppColors.surfaceSubtleLight,
                  textColor: AppColors.forestGreen,
                ),
              ],
            ),
            const SizedBox(height: 10),
            LuxuryCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'حفظ بياناتك المالية في ملف محمي وموقع رقمياً ببصمة SHA-256 للرجوع إليها في أي وقت.',
                    style: AppTypography.bodySecondary,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            final p = await controller.createManualBackup();
                            if (p != null && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('تم إنشاء النسخة الاحتياطية بنجاح (${p.metadata.formattedSize})'),
                                  backgroundColor: AppColors.forestGreen,
                                ),
                              );
                            }
                          },
                          icon: const Icon(Icons.backup_rounded, size: 18),
                          label: const Text('إنشاء نسخة فورية'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.forestGreen,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 0,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const BackupManagementScreen()),
                            );
                          },
                          icon: const Icon(Icons.folder_zip_outlined, size: 18),
                          label: const Text('إدارة النسخ'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.forestGreen,
                            side: const BorderSide(color: AppColors.forestGreen),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 3. تقرير الخصوصية والحماية المحلية
            Text('تقرير الخصوصية والبيانات المحلية', style: AppTypography.headingH3),
            const SizedBox(height: 10),
            LuxuryCard(
              backgroundColor: AppColors.surfaceSubtleLight,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSecurityAuditItem(
                    icon: Icons.storage_rounded,
                    title: 'تخزين محلي 100% (Local SQLite)',
                    desc: 'كافة البيانات المحاسبية والمعاملات محفوظة حصراً على جهازك في صندوق حماية Android الآمن.',
                  ),
                  const SizedBox(height: 12),
                  _buildSecurityAuditItem(
                    icon: Icons.cloud_off_rounded,
                    title: 'أوفلاين بالكامل (Zero External Network)',
                    desc: 'لا يتطلب التطبيق صلاحية الإنترنت، ولا يتم إرسال أي أرقام أو سجلات مالية لخوادم خارجية.',
                  ),
                  const SizedBox(height: 12),
                  _buildSecurityAuditItem(
                    icon: Icons.fingerprint_rounded,
                    title: 'أذونات محدودة للضرورة القصوى',
                    desc: 'تقتصر الأذونات على المصادقة البيومترية فقط مع دعم Android Keystore لتشفير المفاتيح.',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 4. حول التطبيق
            Center(
              child: Column(
                children: [
                  Text(
                    'جزلاني — MyFinance',
                    style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'الإصدار 1.0.0 (Release Build) • هوية Premium Fintech',
                    style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  String _getTimeoutLabel(int seconds) {
    switch (seconds) {
      case 0:
        return 'فور الخروج من التطبيق';
      case 60:
        return 'بعد دقيقة واحدة من عدم النشاط';
      case 300:
        return 'بعد 5 دقائق';
      case 900:
        return 'بعد 15 دقيقة';
      case -1:
        return 'لا يتم القفل تلقائياً';
      default:
        return '$seconds ثانية';
    }
  }

  Widget _buildSecurityAuditItem({
    required IconData icon,
    required String title,
    required String desc,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: AppColors.forestGreen, size: 20),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(height: 2),
              Text(desc, style: AppTypography.bodySecondary.copyWith(fontSize: 11)),
            ],
          ),
        ),
      ],
    );
  }
}

