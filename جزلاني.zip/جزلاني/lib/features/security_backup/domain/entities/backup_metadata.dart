/// البيانات الوصفية لملف النسخة الاحتياطية (Backup Metadata)
class BackupMetadata {
  final String id;
  final String filename;
  final DateTime createdAt;
  final int sizeInBytes;
  final int schemaVersion;
  final String appVersion;
  final String checksumSha256;
  final bool isAutomatic;
  final int totalAccounts;
  final int totalTransactions;

  const BackupMetadata({
    required this.id,
    required this.filename,
    required this.createdAt,
    required this.sizeInBytes,
    required this.schemaVersion,
    this.appVersion = '1.0.0',
    required this.checksumSha256,
    this.isAutomatic = false,
    this.totalAccounts = 0,
    this.totalTransactions = 0,
  });

  /// الحجم بتنسيق مقروء (كيلوبايت / ميجابايت)
  String get formattedSize {
    if (sizeInBytes < 1024) return '$sizeInBytes بايت';
    if (sizeInBytes < 1024 * 1024) {
      final kb = sizeInBytes / 1024.0;
      return '${kb.toStringAsFixed(1)} ك.ب';
    }
    final mb = sizeInBytes / (1024.0 * 1024.0);
    return '${mb.toStringAsFixed(2)} م.ب';
  }
}

