import '../entities/app_lock_config.dart';
import '../entities/backup_metadata.dart';
import '../entities/backup_payload.dart';

/// العقد التجريدي لمستودع الأمان والنسخ الاحتياطي
abstract class SecurityBackupRepository {
  // ── إعدادات القفل والأمان ────────────────────────────────────
  Future<AppLockConfig> getAppLockConfig();
  Future<void> saveAppLockConfig(AppLockConfig config);

  // ── النسخ الاحتياطي ───────────────────────────────────────────
  Future<List<BackupMetadata>> getAllBackups();
  Future<BackupPayload?> getBackupPayload(String backupId);
  Future<void> saveBackup(BackupPayload payload);
  Future<void> deleteBackup(String backupId);

  // ── توليد واستعادة البيانات ───────────────────────────────────
  /// توليد حمولة كاملة للبيانات الحالية للنسخ الاحتياطي
  Future<BackupPayload> createBackupPayload({bool isAutomatic = false});

  /// استعادة البيانات من الحمولة بعد اجتياز فحص السلامة (Integrity Check)
  Future<bool> restoreFromPayload(BackupPayload payload);
}

