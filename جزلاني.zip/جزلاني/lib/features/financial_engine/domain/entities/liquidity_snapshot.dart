import '../../../../core/finance/money.dart';

/// لقطة السيولة وصافي الثروة (Liquidity & Net Worth Snapshot)
///
/// تجسد القواعد المحاسبية الصارمة:
/// 1. الفرق الجوهري بين إجمالي الأموال (Total Funds) والسيولة المتاحة (Available Liquidity).
/// 2. عزل صندوق الطوارئ والأهداف والالتزامات عن السيولة المتاحة.
/// 3. معادلة صافي الثروة اللحظية (Net Worth Equation).
class LiquiditySnapshot {
  /// إجمالي الأموال الموجودة في كافة الحسابات والمحافظ والخزائن
  final Money totalFunds;

  /// رصيد صندوق الطوارئ المعزول كلياً عن الصرف اليومي
  final Money emergencyFundLocked;

  /// إجمالي المبالغ المحجوزة للأهداف المالية النشطة
  final Money goalsLocked;

  /// إجمالي المبالغ المحجوزة للالتزامات والفواتير الشهرية المؤكدة
  final Money obligationsLocked;

  /// السيولة الحقيقية المتاحة للإنفاق اليومي الحر
  /// المعادلة: TotalFunds - (EmergencyFund + GoalsLocked + ObligationsLocked)
  final Money availableLiquidity;

  /// القيمة السوقية الحالية المعتمدة للأصول الرأسمالية (عقارات، مركبات، ذهب، أسهم)
  final Money totalAssetsMarketValue;

  /// إجمالي المتبقي غير المسدد من الديون والقروض (عليّ)
  final Money totalRemainingDebts;

  /// الالتزامات المستحقة فورياً ولم تسدد بعد
  final Money dueObligations;

  /// صافي الثروة الدقيق (Net Worth)
  /// المعادلة: (TotalFunds + Assets) - (Debts + DueObligations)
  final Money netWorth;

  /// الطابع الزمني لاحتساب اللقطة
  final DateTime calculatedAt;

  const LiquiditySnapshot({
    required this.totalFunds,
    required this.emergencyFundLocked,
    required this.goalsLocked,
    required this.obligationsLocked,
    required this.availableLiquidity,
    required this.totalAssetsMarketValue,
    required this.totalRemainingDebts,
    required this.dueObligations,
    required this.netWorth,
    required this.calculatedAt,
  });

  /// حساب اللقطة وفق القواعد المحاسبية المعتمدة
  factory LiquiditySnapshot.calculate({
    required Money totalFunds,
    required Money emergencyFundLocked,
    required Money goalsLocked,
    required Money obligationsLocked,
    required Money totalAssetsMarketValue,
    required Money totalRemainingDebts,
    required Money dueObligations,
    DateTime? calculatedAt,
  }) {
    // 1. حساب السيولة المتاحة: إجمالي الأموال ناقص كافة المحجوزات
    final totalLocked = emergencyFundLocked + goalsLocked + obligationsLocked;
    final available = totalFunds - totalLocked;

    // 2. حساب صافي الثروة: (الأموال + الأصول) - (الديون + الالتزامات المستحقة)
    final totalAssetsAndCash = totalFunds + totalAssetsMarketValue;
    final totalLiabilities = totalRemainingDebts + dueObligations;
    final calculatedNetWorth = totalAssetsAndCash - totalLiabilities;

    return LiquiditySnapshot(
      totalFunds: totalFunds,
      emergencyFundLocked: emergencyFundLocked,
      goalsLocked: goalsLocked,
      obligationsLocked: obligationsLocked,
      availableLiquidity: available,
      totalAssetsMarketValue: totalAssetsMarketValue,
      totalRemainingDebts: totalRemainingDebts,
      dueObligations: dueObligations,
      netWorth: calculatedNetWorth,
      calculatedAt: calculatedAt ?? DateTime.now(),
    );
  }

  /// إجمالي المبالغ المحجوزة
  Money get totalLockedFunds =>
      emergencyFundLocked + goalsLocked + obligationsLocked;

  @override
  String toString() {
    return 'LiquiditySnapshot('
        'إجمالي الأموال: ${totalFunds.formatArabic()}, '
        'السيولة المتاحة: ${availableLiquidity.formatArabic()}, '
        'طوارئ محجوزة: ${emergencyFundLocked.formatArabic()}, '
        'أهداف محجوزة: ${goalsLocked.formatArabic()}, '
        'صافي الثروة: ${netWorth.formatArabic()})';
  }
}

