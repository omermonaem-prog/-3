/// سجل منع تكرار العملية (Idempotency Record)
///
/// يضمن عدم تنفيذ نفس العملية المالية مرتين حتى عند إعادة الإرسال أو انقطاع الاتصال.
class IdempotencyRecord {
  final String key;
  final String transactionId;
  final String operationType;
  final DateTime executedAt;
  final String? responseSummary;

  const IdempotencyRecord({
    required this.key,
    required this.transactionId,
    required this.operationType,
    required this.executedAt,
    this.responseSummary,
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is IdempotencyRecord && other.key == key;
  }

  @override
  int get hashCode => key.hashCode;
}

