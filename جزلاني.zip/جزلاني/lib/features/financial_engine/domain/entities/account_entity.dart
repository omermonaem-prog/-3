import '../../../../core/finance/money.dart';

enum AccountType {
  bank,
  cash,
  eWallet,
  vault;

  static AccountType fromString(String val) {
    switch (val.toLowerCase()) {
      case 'bank':
        return AccountType.bank;
      case 'cash':
        return AccountType.cash;
      case 'e_wallet':
      case 'ewallet':
        return AccountType.eWallet;
      case 'vault':
        return AccountType.vault;
      default:
        return AccountType.bank;
    }
  }

  String toDbString() {
    switch (this) {
      case AccountType.bank:
        return 'bank';
      case AccountType.cash:
        return 'cash';
      case AccountType.eWallet:
        return 'e_wallet';
      case AccountType.vault:
        return 'vault';
    }
  }
}

/// كيان الحساب المالي (Account Domain Entity)
class AccountEntity {
  final String id;
  final String name;
  final AccountType type;
  final String currency;
  final Money balance;
  final bool isArchived;
  final String colorHex;
  final String iconName;
  final DateTime createdAt;
  final DateTime updatedAt;

  const AccountEntity({
    required this.id,
    required this.name,
    required this.type,
    this.currency = 'SAR',
    required this.balance,
    this.isArchived = false,
    required this.colorHex,
    required this.iconName,
    required this.createdAt,
    required this.updatedAt,
  });

  AccountEntity copyWith({
    String? id,
    String? name,
    AccountType? type,
    String? currency,
    Money? balance,
    bool? isArchived,
    String? colorHex,
    String? iconName,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AccountEntity(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      currency: currency ?? this.currency,
      balance: balance ?? this.balance,
      isArchived: isArchived ?? this.isArchived,
      colorHex: colorHex ?? this.colorHex,
      iconName: iconName ?? this.iconName,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is AccountEntity &&
        other.id == id &&
        other.name == name &&
        other.type == type &&
        other.currency == currency &&
        other.balance == balance &&
        other.isArchived == isArchived;
  }

  @override
  int get hashCode =>
      id.hashCode ^
      name.hashCode ^
      type.hashCode ^
      currency.hashCode ^
      balance.hashCode ^
      isArchived.hashCode;

  @override
  String toString() =>
      'AccountEntity(id: $id, name: $name, type: ${type.name}, balance: ${balance.formatArabic()})';
}

