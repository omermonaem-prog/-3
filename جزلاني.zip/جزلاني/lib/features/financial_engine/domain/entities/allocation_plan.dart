import '../../../../core/finance/money.dart';

enum AllocationTargetType {
  emergencyFund,
  goal,
  obligation,
  flexibleBudget;

  static AllocationTargetType fromString(String val) {
    switch (val.toLowerCase()) {
      case 'emergency_fund':
        return AllocationTargetType.emergencyFund;
      case 'goal':
        return AllocationTargetType.goal;
      case 'obligation':
        return AllocationTargetType.obligation;
      case 'flexible_budget':
      case 'budget':
        return AllocationTargetType.flexibleBudget;
      default:
        return AllocationTargetType.flexibleBudget;
    }
  }

  String toDbString() {
    switch (this) {
      case AllocationTargetType.emergencyFund:
        return 'emergency_fund';
      case AllocationTargetType.goal:
        return 'goal';
      case AllocationTargetType.obligation:
        return 'obligation';
      case AllocationTargetType.flexibleBudget:
        return 'budget';
    }
  }
}

enum AllocationMode {
  percentage,
  fixedAmount;

  static AllocationMode fromString(String val) {
    switch (val.toLowerCase()) {
      case 'percentage':
        return AllocationMode.percentage;
      case 'fixed_amount':
        return AllocationMode.fixedAmount;
      default:
        return AllocationMode.percentage;
    }
  }
}

/// بند في خطة التوزيع المالي
class AllocationPlanItem {
  final String id;
  final String title;
  final AllocationTargetType targetType;
  final String targetId; // معرف الهدف أو الالتزام أو الفئة
  final AllocationMode mode;
  /// القيمة الرقمية: نسبة مئوية (مثال: 20.0 تعني 20%) أو مبلغ ثابت
  final double? percentage;
  final Money? fixedAmount;
  final int priorityOrder;

  const AllocationPlanItem({
    required this.id,
    required this.title,
    required this.targetType,
    required this.targetId,
    required this.mode,
    this.percentage,
    this.fixedAmount,
    this.priorityOrder = 0,
  });
}

/// خطة توزيع الدخل (Income Allocation Plan)
class AllocationPlan {
  final String id;
  final String title;
  final Money totalIncome;
  final List<AllocationPlanItem> items;
  final bool isConfirmed;
  final DateTime createdAt;

  const AllocationPlan({
    required this.id,
    required this.title,
    required this.totalIncome,
    required this.items,
    this.isConfirmed = false,
    required this.createdAt,
  });

  AllocationPlan copyWith({
    String? id,
    String? title,
    Money? totalIncome,
    List<AllocationPlanItem>? items,
    bool? isConfirmed,
    DateTime? createdAt,
  }) {
    return AllocationPlan(
      id: id ?? this.id,
      title: title ?? this.title,
      totalIncome: totalIncome ?? this.totalIncome,
      items: items ?? this.items,
      isConfirmed: isConfirmed ?? this.isConfirmed,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

