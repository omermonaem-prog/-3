import '../../../../core/finance/money.dart';

/// قيد في السجل المالي والرقابة المحاسبية (Financial Audit Trail Entry)
///
/// يوثق كل تغيير يطرأ على رصيد أي حساب أو كيان مالي مع ذكر الحالة قبل وبعد.
class AuditTrailEntry {
  final String id;
  final String transactionId;
  final String operationType; // 'transfer', 'expense', 'income', 'allocation', 'reversal', 'correction'
  final String entityType;    // 'account', 'emergency_fund', 'goal', 'debt', 'budget'
  final String entityId;
  final Money balanceBefore;
  final Money delta;          // موجب للإيداع، سالب للخصم
  final Money balanceAfter;
  final String? idempotencyKey;
  final String note;
  final DateTime timestamp;

  const AuditTrailEntry({
    required this.id,
    required this.transactionId,
    required this.operationType,
    required this.entityType,
    required this.entityId,
    required this.balanceBefore,
    required this.delta,
    required this.balanceAfter,
    this.idempotencyKey,
    required this.note,
    required this.timestamp,
  });

  /// التحقق من سلامة العملية حسابياً:
  /// balanceBefore + delta == balanceAfter
  bool get isMathValid => (balanceBefore + delta) == balanceAfter;

  @override
  String toString() {
    return 'AuditTrailEntry($operationType on $entityType:$entityId | '
        'Before: ${balanceBefore.formatArabic()}, '
        'Delta: ${delta.formatArabic()}, '
        'After: ${balanceAfter.formatArabic()} | $timestamp)';
  }
}

