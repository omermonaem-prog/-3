import '../../../../core/finance/money.dart';

enum TransactionType {
  expense,
  income,
  internalTransfer,
  goalAllocation,
  goalDeallocation,
  emergencyDeposit,
  emergencyWithdrawal,
  debtPayment,
  reversal,
  correction,
  reconciliation;

  static TransactionType fromString(String val) {
    switch (val.toLowerCase()) {
      case 'expense':
        return TransactionType.expense;
      case 'income':
        return TransactionType.income;
      case 'transfer':
      case 'internal_transfer':
        return TransactionType.internalTransfer;
      case 'goal_allocation':
        return TransactionType.goalAllocation;
      case 'goal_deallocation':
        return TransactionType.goalDeallocation;
      case 'emergency_deposit':
        return TransactionType.emergencyDeposit;
      case 'emergency_withdrawal':
        return TransactionType.emergencyWithdrawal;
      case 'debt_payment':
        return TransactionType.debtPayment;
      case 'reversal':
        return TransactionType.reversal;
      case 'correction':
        return TransactionType.correction;
      case 'reconciliation':
        return TransactionType.reconciliation;
      default:
        return TransactionType.expense;
    }
  }

  String toDbString() {
    switch (this) {
      case TransactionType.expense:
        return 'expense';
      case TransactionType.income:
        return 'income';
      case TransactionType.internalTransfer:
        return 'transfer';
      case TransactionType.goalAllocation:
        return 'goal_allocation';
      case TransactionType.goalDeallocation:
        return 'goal_deallocation';
      case TransactionType.emergencyDeposit:
        return 'emergency_deposit';
      case TransactionType.emergencyWithdrawal:
        return 'emergency_withdrawal';
      case TransactionType.debtPayment:
        return 'debt_payment';
      case TransactionType.reversal:
        return 'reversal';
      case TransactionType.correction:
        return 'correction';
      case TransactionType.reconciliation:
        return 'reconciliation';
    }
  }
}

enum TransactionStatus {
  completed,
  reversed,
  corrected;

  static TransactionStatus fromString(String val) {
    switch (val.toLowerCase()) {
      case 'completed':
        return TransactionStatus.completed;
      case 'reversed':
        return TransactionStatus.reversed;
      case 'corrected':
        return TransactionStatus.corrected;
      default:
        return TransactionStatus.completed;
    }
  }
}

/// كيان المعاملة المالية (Transaction Domain Entity)
class TransactionEntity {
  final String id;
  final String accountId;
  final String? categoryId;
  final String? destinationAccountId;
  final TransactionType type;
  final TransactionStatus status;
  final Money amount;
  final DateTime transactionDate;
  final String? note;
  final String? receiptImagePath;
  final String? idempotencyKey;
  final String? relatedTransactionId; // معرف المعاملة الأصلية في حالة العكس أو التصحيح
  final DateTime createdAt;
  final bool isDeleted;
  final DateTime? deletedAt;

  const TransactionEntity({
    required this.id,
    required this.accountId,
    this.categoryId,
    this.destinationAccountId,
    required this.type,
    this.status = TransactionStatus.completed,
    required this.amount,
    required this.transactionDate,
    this.note,
    this.receiptImagePath,
    this.idempotencyKey,
    this.relatedTransactionId,
    required this.createdAt,
    this.isDeleted = false,
    this.deletedAt,
  });

  TransactionEntity copyWith({
    String? id,
    String? accountId,
    String? categoryId,
    String? destinationAccountId,
    TransactionType? type,
    TransactionStatus? status,
    Money? amount,
    DateTime? transactionDate,
    String? note,
    String? receiptImagePath,
    String? idempotencyKey,
    String? relatedTransactionId,
    DateTime? createdAt,
    bool? isDeleted,
    DateTime? deletedAt,
  }) {
    return TransactionEntity(
      id: id ?? this.id,
      accountId: accountId ?? this.accountId,
      categoryId: categoryId ?? this.categoryId,
      destinationAccountId: destinationAccountId ?? this.destinationAccountId,
      type: type ?? this.type,
      status: status ?? this.status,
      amount: amount ?? this.amount,
      transactionDate: transactionDate ?? this.transactionDate,
      note: note ?? this.note,
      receiptImagePath: receiptImagePath ?? this.receiptImagePath,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
      relatedTransactionId: relatedTransactionId ?? this.relatedTransactionId,
      createdAt: createdAt ?? this.createdAt,
      isDeleted: isDeleted ?? this.isDeleted,
      deletedAt: deletedAt ?? this.deletedAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is TransactionEntity &&
        other.id == id &&
        other.accountId == accountId &&
        other.type == type &&
        other.status == status &&
        other.amount == amount &&
        other.idempotencyKey == idempotencyKey;
  }

  @override
  int get hashCode =>
      id.hashCode ^
      accountId.hashCode ^
      type.hashCode ^
      status.hashCode ^
      amount.hashCode ^
      idempotencyKey.hashCode;

  @override
  String toString() =>
      'TransactionEntity(id: $id, type: ${type.name}, amount: ${amount.formatArabic()}, status: ${status.name})';
}

