import '../../../../core/finance/money.dart';
import '../../domain/entities/account_entity.dart';
import '../../domain/entities/audit_trail_entry.dart';
import '../../domain/entities/idempotency_record.dart';
import '../../domain/entities/transaction_entity.dart';
import '../../domain/repositories/financial_engine_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لاختبارات المحرك المالي الذرية (In-Memory Repository)
///
/// يدعم محاكاة الـ Rollback التلقائي عند حدوث استثناء داخل `runInTransaction`!
class InMemoryFinancialEngineRepository implements FinancialEngineRepository {
  Map<String, AccountEntity> accounts = {};
  Map<String, TransactionEntity> transactions = {};
  Map<String, IdempotencyRecord> idempotencyStore = {};
  List<AuditTrailEntry> auditTrail = [];

  Money emergencyFundBalance = const Money.zero();
  Map<String, Money> goalBalances = {};
  Money lockedObligations = const Money.zero();
  Money dueObligations = const Money.zero();
  Money remainingDebts = const Money.zero();
  Money assetsMarketValue = const Money.zero();

  @override
  Future<T> runInTransaction<T>(Future<T> Function() action) async {
    // التقاط لقطة (Snapshot) للحالة قبل المعاملة الذرية
    final snapshotAccounts = Map<String, AccountEntity>.from(accounts);
    final snapshotTransactions = Map<String, TransactionEntity>.from(transactions);
    final snapshotIdempotency = Map<String, IdempotencyRecord>.from(idempotencyStore);
    final snapshotAudit = List<AuditTrailEntry>.from(auditTrail);
    final snapshotEF = emergencyFundBalance;
    final snapshotGoals = Map<String, Money>.from(goalBalances);

    try {
      return await action();
    } catch (e) {
      // ── ATOMIC ROLLBACK محاكاة التراجع التام ──
      accounts = snapshotAccounts;
      transactions = snapshotTransactions;
      idempotencyStore = snapshotIdempotency;
      auditTrail = snapshotAudit;
      emergencyFundBalance = snapshotEF;
      goalBalances = snapshotGoals;
      rethrow;
    }
  }

  // ── الحسابات ──────────────────────────────────────────────────

  @override
  Future<AccountEntity?> getAccountById(String id) async => accounts[id];

  @override
  Future<List<AccountEntity>> getAllActiveAccounts() async =>
      accounts.values.where((a) => !a.isArchived).toList();

  @override
  Future<void> updateAccountBalance(String id, Money newBalance) async {
    final acc = accounts[id];
    if (acc != null) {
      accounts[id] = acc.copyWith(balance: newBalance, updatedAt: DateTime.now());
    }
  }

  // ── المعاملات ─────────────────────────────────────────────────

  @override
  Future<void> saveTransaction(TransactionEntity transaction) async {
    transactions[transaction.id] = transaction;
  }

  @override
  Future<TransactionEntity?> getTransactionById(String id) async =>
      transactions[id];

  @override
  Future<void> updateTransactionStatus(String id, TransactionStatus status) async {
    final t = transactions[id];
    if (t != null) {
      transactions[id] = t.copyWith(status: status);
    }
  }

  // ── منع التكرار ───────────────────────────────────────────────

  @override
  Future<bool> hasIdempotencyKey(String key) async =>
      idempotencyStore.containsKey(key);

  @override
  Future<IdempotencyRecord?> getIdempotencyRecord(String key) async =>
      idempotencyStore[key];

  @override
  Future<void> saveIdempotencyRecord(IdempotencyRecord record) async {
    idempotencyStore[record.key] = record;
  }

  // ── سجل الرقابة والتدقيق ───────────────────────────────────────

  @override
  Future<void> recordAuditEntry(AuditTrailEntry entry) async {
    auditTrail.add(entry);
  }

  @override
  Future<List<AuditTrailEntry>> getAuditTrailForTransaction(String transactionId) async {
    return auditTrail.where((e) => e.transactionId == transactionId).toList();
  }

  @override
  Future<List<AuditTrailEntry>> getAuditTrailForEntity(String entityType, String entityId) async {
    return auditTrail
        .where((e) => e.entityType == entityType && e.entityId == entityId)
        .toList();
  }

  // ── صندوق الطوارئ ───────────────────────────────────────────

  @override
  Future<Money> getEmergencyFundBalance() async => emergencyFundBalance;

  @override
  Future<void> updateEmergencyFundBalance(Money newBalance) async {
    emergencyFundBalance = newBalance;
  }

  // ── الأهداف ───────────────────────────────────────────────────

  @override
  Future<Money> getGoalSavedAmount(String goalId) async =>
      goalBalances[goalId] ?? const Money.zero();

  @override
  Future<void> updateGoalSavedAmount(String goalId, Money newAmount) async {
    goalBalances[goalId] = newAmount;
  }

  @override
  Future<Money> getTotalActiveGoalsSaved() async {
    return goalBalances.values.fold<Money>(
      const Money.zero(),
      (sum, m) => sum + m,
    );
  }

  // ── الالتزامات ────────────────────────────────────────────────

  @override
  Future<Money> getTotalLockedObligations() async => lockedObligations;

  @override
  Future<Money> getDueObligationsAmount() async => dueObligations;

  // ── الديون والأصول ───────────────────────────────────────────

  @override
  Future<Money> getTotalRemainingDebts() async => remainingDebts;

  @override
  Future<void> applyDebtPayment(String debtId, Money amount) async {
    remainingDebts = remainingDebts - amount;
  }

  @override
  Future<Money> getTotalAssetsMarketValue() async => assetsMarketValue;

  @override
  Future<void> recordExpenseAgainstBudget({
    required String? categoryId,
    required Money amount,
    required DateTime date,
  }) async {}
}

