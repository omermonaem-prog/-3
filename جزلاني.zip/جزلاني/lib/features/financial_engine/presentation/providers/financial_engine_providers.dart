import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/database/providers/database_providers.dart';
import '../../../../core/finance/money.dart';
import '../../application/central_financial_engine.dart';
import '../../data/repositories/financial_engine_repository_impl.dart';
import '../../domain/entities/liquidity_snapshot.dart';
import '../../domain/repositories/financial_engine_repository.dart';

/// موفر مستودع المحرك المالي
final financialEngineRepositoryProvider = Provider<FinancialEngineRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return FinancialEngineRepositoryImpl(db);
});

/// موفر المحرك المالي المركزي الأوحد (Central Financial Engine)
final centralFinancialEngineProvider = Provider<CentralFinancialEngine>((ref) {
  final repository = ref.watch(financialEngineRepositoryProvider);
  return CentralFinancialEngine(repository: repository);
});

/// موفر لقطة السيولة الشاملة وصافي الثروة
final liquiditySnapshotProvider = FutureProvider<LiquiditySnapshot>((ref) async {
  final engine = ref.watch(centralFinancialEngineProvider);
  return await engine.getLiquiditySnapshot();
});

/// موفر السيولة المتاحة للإنفاق الفعلي اللحظي
final availableLiquidityProvider = FutureProvider<Money>((ref) async {
  final engine = ref.watch(centralFinancialEngineProvider);
  return await engine.getAvailableLiquidity();
});

