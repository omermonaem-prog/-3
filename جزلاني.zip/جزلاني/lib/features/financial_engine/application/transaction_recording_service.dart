import '../../../../core/finance/financial_exceptions.dart';
import '../../../../core/finance/money.dart';
import '../domain/entities/audit_trail_entry.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'balance_calculation_service.dart';
import 'idempotency_service.dart';

/// خدمة تسجيل المعاملات المالية (Transaction Recording Service)
///
/// مسؤولة عن تسجيل المصروفات والإيرادات اليومية مع الضمانات المحاسبية:
/// 1. تنفيذ ذري كامل (Atomic DB Transaction)
/// 2. قيد عدم السالبية وكفاية الرصيد
/// 3. توثيق الأثر المالي في سجل التدقيق (Audit Trail)
/// 4. منع تكرار المعاملات (Idempotency Protection)
class TransactionRecordingService {
  final FinancialEngineRepository _repository;
  final BalanceCalculationService _balanceService;
  final IdempotencyService _idempotencyService;

  TransactionRecordingService({
    required FinancialEngineRepository repository,
    required BalanceCalculationService balanceService,
    required IdempotencyService idempotencyService,
  })  : _repository = repository,
        _balanceService = balanceService,
        _idempotencyService = idempotencyService;

  /// تسجيل مصروف مالي وخصمه من الحساب والميزانية
  Future<TransactionEntity> recordExpense({
    required String transactionId,
    required String accountId,
    required String? categoryId,
    required Money amount,
    required DateTime date,
    String? note,
    String? receiptImagePath,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      throw ArgumentError('مبلغ المصروف يجب أن يكون موجباً قطعاً');
    }

    // 1. فحص منع التكرار قبل البدء
    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      // 2. التحقق من الحساب والرصيد
      final account = await _repository.getAccountById(accountId);
      if (account == null) {
        throw EntityNotFoundException(entityType: 'حساب', entityId: accountId);
      }
      _balanceService.assertSufficientBalance(
        account: account,
        amountToDeduct: amount,
      );

      final balanceBefore = account.balance;
      final balanceAfter = balanceBefore - amount;

      // 3. إنشاء كيان المعاملة
      final transaction = TransactionEntity(
        id: transactionId,
        accountId: accountId,
        categoryId: categoryId,
        type: TransactionType.expense,
        amount: amount,
        transactionDate: date,
        note: note,
        receiptImagePath: receiptImagePath,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      // 4. حفظ المعاملة وتحديث رصيد الحساب
      await _repository.saveTransaction(transaction);
      await _repository.updateAccountBalance(accountId, balanceAfter);

      // 5. ربط المصروف بالميزانية إن وجد تصنيف
      if (categoryId != null) {
        await _repository.recordExpenseAgainstBudget(
          categoryId: categoryId,
          amount: amount,
          date: date,
        );
      }

      // 6. تسجيل قيد الرقابة والتدقيق (Audit Trail)
      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_audit',
        transactionId: transactionId,
        operationType: 'expense',
        entityType: 'account',
        entityId: accountId,
        balanceBefore: balanceBefore,
        delta: -amount,
        balanceAfter: balanceAfter,
        idempotencyKey: idempotencyKey,
        note: note ?? 'تسجيل مصروف',
        timestamp: DateTime.now(),
      ));

      // 7. تثبيت منع التكرار
      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: transactionId,
        operationType: 'expense',
        responseSummary: 'خصم ${amount.formatArabic()} من الحساب $accountId',
      );

      return transaction;
    });
  }

  /// تسجيل دخل مالي وإيداعه في الحساب
  Future<TransactionEntity> recordIncome({
    required String transactionId,
    required String accountId,
    required String? categoryId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) async {
    if (!amount.isPositive) {
      throw ArgumentError('مبلغ الدخل يجب أن يكون موجباً قطعاً');
    }

    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      final account = await _repository.getAccountById(accountId);
      if (account == null) {
        throw EntityNotFoundException(entityType: 'حساب', entityId: accountId);
      }
      if (account.isArchived) {
        throw AccountArchivedException(accountId);
      }

      final balanceBefore = account.balance;
      final balanceAfter = balanceBefore + amount;

      final transaction = TransactionEntity(
        id: transactionId,
        accountId: accountId,
        categoryId: categoryId,
        type: TransactionType.income,
        amount: amount,
        transactionDate: date,
        note: note,
        idempotencyKey: idempotencyKey,
        createdAt: DateTime.now(),
      );

      await _repository.saveTransaction(transaction);
      await _repository.updateAccountBalance(accountId, balanceAfter);

      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${transactionId}_audit',
        transactionId: transactionId,
        operationType: 'income',
        entityType: 'account',
        entityId: accountId,
        balanceBefore: balanceBefore,
        delta: amount,
        balanceAfter: balanceAfter,
        idempotencyKey: idempotencyKey,
        note: note ?? 'إيداع دخل مالي',
        timestamp: DateTime.now(),
      ));

      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: transactionId,
        operationType: 'income',
        responseSummary: 'إيداع ${amount.formatArabic()} في الحساب $accountId',
      );

      return transaction;
    });
  }
}

