import '../../../../core/finance/financial_exceptions.dart';
import '../domain/entities/idempotency_record.dart';
import '../domain/repositories/financial_engine_repository.dart';

/// خدمة إدارة ومنع تكرار العمليات المالية (Idempotency Service)
///
/// تضمن ألا يتم تكرار أي قيد مالي أو خصم أو إيداع مرتين عند إعادة المحاولة.
class IdempotencyService {
  final FinancialEngineRepository _repository;

  IdempotencyService(this._repository);

  /// التحقق مما إذا كانت العملية قد نُفذت بالفعل
  Future<bool> isOperationProcessed(String idempotencyKey) async {
    if (idempotencyKey.trim().isEmpty) {
      throw ArgumentError('مفتاح منع التكرار (Idempotency Key) لا يمكن أن يكون فارغاً');
    }
    return await _repository.hasIdempotencyKey(idempotencyKey);
  }

  /// حراسة العملية المالية: ترفض التنفيذ إذا كان المفتاح مسجلاً مسبقاً
  Future<void> assertNotProcessed(String idempotencyKey) async {
    final alreadyProcessed = await isOperationProcessed(idempotencyKey);
    if (alreadyProcessed) {
      throw DuplicateTransactionException(idempotencyKey);
    }
  }

  /// تسجيل إتمام العملية بالمفتاح المخصص
  Future<void> markOperationCompleted({
    required String idempotencyKey,
    required String transactionId,
    required String operationType,
    String? responseSummary,
  }) async {
    final record = IdempotencyRecord(
      key: idempotencyKey,
      transactionId: transactionId,
      operationType: operationType,
      executedAt: DateTime.now(),
      responseSummary: responseSummary,
    );
    await _repository.saveIdempotencyRecord(record);
  }
}

