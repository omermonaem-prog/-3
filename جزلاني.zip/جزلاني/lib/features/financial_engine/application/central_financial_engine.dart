import '../../../../core/finance/money.dart';
import '../domain/entities/account_entity.dart';
import '../domain/entities/allocation_plan.dart';
import '../domain/entities/allocation_result.dart';
import '../domain/entities/liquidity_snapshot.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'balance_calculation_service.dart';
import 'goal_allocation_service.dart';
import 'idempotency_service.dart';
import 'income_allocation_service.dart';
import 'internal_transfer_service.dart';
import 'reversal_correction_service.dart';
import 'transaction_recording_service.dart';

/// المحرك المالي المركزي (Central Financial Engine)
///
/// القلب المالي النابض لتطبيق MyFinance، والمسؤول الأوحد عن ضمان:
/// 1. النزاهة المحاسبية والرياضية لجميع الأرصدة والتحويلات.
/// 2. الفصل الصارم بين إجمالي الأموال والسيولة المتاحة.
/// 3. العمليات الذرية ومنع التكرار (Idempotency).
/// 4. الحفاظ على أثر العمليات دون حذف فيزيائي.
class CentralFinancialEngine {
  final FinancialEngineRepository repository;
  late final IdempotencyService idempotencyService;
  late final BalanceCalculationService balanceService;
  late final TransactionRecordingService transactionService;
  late final InternalTransferService transferService;
  late final GoalAllocationService goalService;
  late final IncomeAllocationService allocationService;
  late final ReversalCorrectionService reversalService;

  CentralFinancialEngine({required this.repository}) {
    idempotencyService = IdempotencyService(repository);
    balanceService = BalanceCalculationService(repository);
    transactionService = TransactionRecordingService(
      repository: repository,
      balanceService: balanceService,
      idempotencyService: idempotencyService,
    );
    transferService = InternalTransferService(
      repository: repository,
      balanceService: balanceService,
      idempotencyService: idempotencyService,
    );
    goalService = GoalAllocationService(
      repository: repository,
      balanceService: balanceService,
      idempotencyService: idempotencyService,
    );
    allocationService = IncomeAllocationService(
      repository: repository,
      idempotencyService: idempotencyService,
    );
    reversalService = ReversalCorrectionService(
      repository: repository,
      idempotencyService: idempotencyService,
    );
  }

  // ── الحسابات والسيولة ─────────────────────────────────────────

  /// الحصول على لقطة شاملة للحالة المالية والسيولة وصافي الثروة
  Future<LiquiditySnapshot> getLiquiditySnapshot() =>
      balanceService.getLiquiditySnapshot();

  /// فحص السيولة المتاحة للإنفاق الحر
  Future<Money> getAvailableLiquidity() =>
      balanceService.getAvailableLiquidity();

  /// إجمالي الأموال عبر كافة الحسابات والخزائن
  Future<Money> getTotalFunds() => balanceService.getTotalFunds();

  // ── تسجيل المعاملات ───────────────────────────────────────────

  /// تسجيل مصروف مالي
  Future<TransactionEntity> recordExpense({
    required String transactionId,
    required String accountId,
    required String? categoryId,
    required Money amount,
    required DateTime date,
    String? note,
    String? receiptImagePath,
    required String idempotencyKey,
  }) =>
      transactionService.recordExpense(
        transactionId: transactionId,
        accountId: accountId,
        categoryId: categoryId,
        amount: amount,
        date: date,
        note: note,
        receiptImagePath: receiptImagePath,
        idempotencyKey: idempotencyKey,
      );

  /// تسجيل دخل مالي
  Future<TransactionEntity> recordIncome({
    required String transactionId,
    required String accountId,
    required String? categoryId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) =>
      transactionService.recordIncome(
        transactionId: transactionId,
        accountId: accountId,
        categoryId: categoryId,
        amount: amount,
        date: date,
        note: note,
        idempotencyKey: idempotencyKey,
      );

  // ── التحويلات الداخلية ─────────────────────────────────────────

  /// إجراء تحويل داخلي ذري
  Future<TransactionEntity> transfer({
    required String transactionId,
    required String fromAccountId,
    required String toAccountId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) =>
      transferService.executeTransfer(
        transactionId: transactionId,
        fromAccountId: fromAccountId,
        toAccountId: toAccountId,
        amount: amount,
        date: date,
        note: note,
        idempotencyKey: idempotencyKey,
      );

  // ── تخصيص الأهداف ────────────────────────────────────────────

  /// تخصيص مبلغ لهدف مالي (لا يُسجل كمصروف)
  Future<TransactionEntity> allocateToGoal({
    required String transactionId,
    required String fromAccountId,
    required String goalId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) =>
      goalService.allocateToGoal(
        transactionId: transactionId,
        fromAccountId: fromAccountId,
        goalId: goalId,
        amount: amount,
        date: date,
        note: note,
        idempotencyKey: idempotencyKey,
      );

  /// سحب/استرداد مخصصات من هدف وإعادتها للسيولة
  Future<TransactionEntity> deallocateFromGoal({
    required String transactionId,
    required String toAccountId,
    required String goalId,
    required Money amount,
    required DateTime date,
    String? note,
    required String idempotencyKey,
  }) =>
      goalService.deallocateFromGoal(
        transactionId: transactionId,
        toAccountId: toAccountId,
        goalId: goalId,
        amount: amount,
        date: date,
        note: note,
        idempotencyKey: idempotencyKey,
      );

  // ── توزيع الدخل والراتب ────────────────────────────────────────

  /// معاينة التوزيع المالي للدخل
  AllocationPlan previewIncomeAllocation({
    required String planId,
    required String title,
    required Money totalIncome,
    required List<AllocationPlanItem> items,
  }) =>
      allocationService.previewAllocationPlan(
        planId: planId,
        title: title,
        totalIncome: totalIncome,
        items: items,
      );

  /// اعتماد وتنفيذ التوزيع المالي المؤكد
  Future<AllocationResult> executeIncomeAllocation({
    required AllocationPlan plan,
    required String depositAccountId,
    required String idempotencyKey,
  }) =>
      allocationService.executeAllocationPlan(
        plan: plan,
        depositAccountId: depositAccountId,
        idempotencyKey: idempotencyKey,
      );

  // ── العكس والتصحيح ───────────────────────────────────────────

  /// عكس معاملة سابقة دون حذف تاريخها
  Future<TransactionEntity> reverseTransaction({
    required String originalTransactionId,
    required String reversalTransactionId,
    required String reason,
    required String idempotencyKey,
  }) =>
      reversalService.reverseTransaction(
        originalTransactionId: originalTransactionId,
        reversalTransactionId: reversalTransactionId,
        reason: reason,
        idempotencyKey: idempotencyKey,
      );

  /// تصحيح معاملة سابقة
  Future<TransactionEntity> correctTransaction({
    required String originalTransactionId,
    required String reversalTransactionId,
    required TransactionEntity correctedTransaction,
    required String reason,
    required String idempotencyKey,
  }) =>
      reversalService.correctTransaction(
        originalTransactionId: originalTransactionId,
        reversalTransactionId: reversalTransactionId,
        correctedTransaction: correctedTransaction,
        reason: reason,
        idempotencyKey: idempotencyKey,
      );
}

