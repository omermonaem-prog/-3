import '../../../../core/finance/financial_exceptions.dart';
import '../../../../core/finance/money.dart';
import '../domain/entities/account_entity.dart';
import '../domain/entities/liquidity_snapshot.dart';
import '../domain/repositories/financial_engine_repository.dart';

/// خدمة حساب الأرصدة والسيولة والنزاهة المحاسبية (Balance Calculation Service)
///
/// تفصل بدقة بين:
/// 1. إجمالي الأموال (Total Funds)
/// 2. السيولة المتاحة للإنفاق (Available-to-Spend Liquidity)
/// 3. صافي الثروة اللحظي (Net Worth)
class BalanceCalculationService {
  final FinancialEngineRepository _repository;

  BalanceCalculationService(this._repository);

  /// توليد لقطة السيولة الشاملة والحسابات المحاسبية الدقيقة
  Future<LiquiditySnapshot> getLiquiditySnapshot() async {
    // 1. حساب إجمالي الأموال في كافة الحسابات النشطة
    final accounts = await _repository.getAllActiveAccounts();
    final totalFunds = accounts.fold<Money>(
      const Money.zero(),
      (sum, acc) => sum + acc.balance,
    );

    // 2. جلب الأرصدة المحجوزة والمعزولة
    final emergencyFundLocked = await _repository.getEmergencyFundBalance();
    final goalsLocked = await _repository.getTotalActiveGoalsSaved();
    final obligationsLocked = await _repository.getTotalLockedObligations();

    // 3. جلب الالتزامات والديون والأصول
    final totalAssetsMarketValue = await _repository.getTotalAssetsMarketValue();
    final totalRemainingDebts = await _repository.getTotalRemainingDebts();
    final dueObligations = await _repository.getDueObligationsAmount();

    return LiquiditySnapshot.calculate(
      totalFunds: totalFunds,
      emergencyFundLocked: emergencyFundLocked,
      goalsLocked: goalsLocked,
      obligationsLocked: obligationsLocked,
      totalAssetsMarketValue: totalAssetsMarketValue,
      totalRemainingDebts: totalRemainingDebts,
      dueObligations: dueObligations,
    );
  }

  /// إجمالي الأموال الإجمالية في جميع الحسابات والخزائن
  Future<Money> getTotalFunds() async {
    final accounts = await _repository.getAllActiveAccounts();
    return accounts.fold<Money>(
      const Money.zero(),
      (sum, acc) => sum + acc.balance,
    );
  }

  /// السيولة الصافية المتاحة للإنفاق الفعلي بعد خصم كافة المحجوزات
  Future<Money> getAvailableLiquidity() async {
    final snapshot = await getLiquiditySnapshot();
    return snapshot.availableLiquidity;
  }

  /// فحص إمكانية الصرف من حساب معين والتأكد من عدم اختراق قيد عدم السالبية
  Future<bool> canSpend({
    required String accountId,
    required Money amount,
  }) async {
    final account = await _repository.getAccountById(accountId);
    if (account == null || account.isArchived) return false;
    return account.balance >= amount;
  }

  /// حراسة الرصيد: تطلق استثناءً إذا كان الرصيد لا يكفي أو سيصبح سالباً
  void assertSufficientBalance({
    required AccountEntity account,
    required Money amountToDeduct,
  }) {
    if (account.isArchived) {
      throw AccountArchivedException(account.id);
    }
    if (account.balance < amountToDeduct) {
      throw InsufficientFundsException(
        availableMinorUnits: account.balance.minorUnits,
        requiredMinorUnits: amountToDeduct.minorUnits,
      );
    }
  }

  /// حراسة قيد عدم السالبية الصارم (Non-Negativity Invariant)
  void assertNonNegativeProjectedBalance({
    required String accountId,
    required Money currentBalance,
    required Money deduction,
  }) {
    final projected = currentBalance - deduction;
    if (projected.isNegative) {
      throw NegativeBalanceForbiddenException(
        accountId: accountId,
        projectedBalanceMinorUnits: projected.minorUnits,
      );
    }
  }
}

