import '../../../../core/finance/financial_exceptions.dart';
import '../../../../core/finance/money.dart';
import '../domain/entities/allocation_plan.dart';
import '../domain/entities/allocation_result.dart';
import '../domain/entities/audit_trail_entry.dart';
import '../domain/entities/transaction_entity.dart';
import '../domain/repositories/financial_engine_repository.dart';
import 'idempotency_service.dart';

/// خدمة التوزيع المالي للدخل والراتب (Income Allocation Service)
///
/// القواعد المحاسبية الصارمة:
/// 1. معادلة التوزيع الصفري (Zero-Based Budgeting):
///    Income = Σ Obligations + Σ Emergency + Σ Goals + Flexible Budget Remainder
/// 2. حظر التوزيع التلقائي: لا يحدث توزيع دخل دون تأكيد صريح من المستخدم (Preview & Confirm).
/// 3. التوزيع العادل للهللات المتبقية (No lost pennies) عبر أكبر كسر عشري.
/// 4. تنفيذ كل عمليات التوزيع ذرياً ضمن DB Transaction واحدة.
class IncomeAllocationService {
  final FinancialEngineRepository _repository;
  final IdempotencyService _idempotencyService;

  IncomeAllocationService({
    required FinancialEngineRepository repository,
    required IdempotencyService idempotencyService,
  })  : _repository = repository,
        _idempotencyService = idempotencyService;

  /// ── المرحلة 1: إنشاء معاينة التوزيع المالي (Preview Allocation) ──
  ///
  /// تحسب المبالغ الموزعة بدقة متناهية دون تطبيقها على الأرصدة
  AllocationPlan previewAllocationPlan({
    required String planId,
    required String title,
    required Money totalIncome,
    required List<AllocationPlanItem> items,
  }) {
    if (!totalIncome.isPositive) {
      throw ArgumentError('مبلغ الدخل المراد توزيعه يجب أن يكون موجباً');
    }

    // فرز البنود حسب الأولوية
    final sortedItems = List<AllocationPlanItem>.from(items)
      ..sort((a, b) => a.priorityOrder.compareTo(b.priorityOrder));

    var allocatedSoFar = const Money.zero();

    // 1. حساب البنود ذات المبالغ الثابتة أولاً
    final fixedItems = sortedItems.where((i) => i.mode == AllocationMode.fixedAmount).toList();
    for (final item in fixedItems) {
      final amount = item.fixedAmount ?? const Money.zero();
      if (amount.isNegative) {
        throw const InvalidAllocationException('المبلغ الثابت لا يمكن أن يكون سالباً');
      }
      allocatedSoFar += amount;
    }

    if (allocatedSoFar > totalIncome) {
      throw InvalidAllocationException(
        'مجموع المبالغ الثابتة المخصصة (${allocatedSoFar.formatArabic()}) '
        'يتجاوز إجمالي الدخل (${totalIncome.formatArabic()})',
      );
    }

    // 2. توزيع النسبة المئوية على المبلغ المتبقي (أو على الإجمالي وفق السياسة المعتمدة)
    final percentageItems = sortedItems.where((i) => i.mode == AllocationMode.percentage).toList();
    if (percentageItems.isNotEmpty) {
      final totalPercentage = percentageItems.fold<double>(
        0.0,
        (sum, item) => sum + (item.percentage ?? 0.0),
      );

      if (totalPercentage > 100.0) {
        throw InvalidAllocationException(
          'مجموع نسب التوزيع ($totalPercentage%) يتجاوز 100%',
        );
      }

      // حساب المبالغ الموزعة بالنسبة المئوية باستخدام Largest Remainder Method
      final percentages = percentageItems.map((i) => i.percentage ?? 0.0).toList();
      final allocatedPercentages = Money.apportionByPercentages(totalIncome, percentages);

      for (var i = 0; i < percentageItems.length; i++) {
        allocatedSoFar += allocatedPercentages[i];
      }
    }

    if (allocatedSoFar > totalIncome) {
      throw InvalidAllocationException(
        'مجموع التخصيصات يتجاوز إجمالي الدخل المتاح',
      );
    }

    // الخطة ترجع غير مؤكدة (isConfirmed: false) إعمالاً للقاعدة الصارمة
    return AllocationPlan(
      id: planId,
      title: title,
      totalIncome: totalIncome,
      items: sortedItems,
      isConfirmed: false,
      createdAt: DateTime.now(),
    );
  }

  /// ── المرحلة 2: اعتماد وتنفيذ خطة التوزيع (Execute Confirmed Allocation) ──
  ///
  /// تنفذ فقط إذا كانت `plan.isConfirmed == true`، وتنفذ كافة التوزيعات ذرياً
  Future<AllocationResult> executeAllocationPlan({
    required AllocationPlan plan,
    required String depositAccountId,
    required String idempotencyKey,
  }) async {
    // 1. القيد الصارم: التحقق من تأكيد المستخدم
    if (!plan.isConfirmed) {
      throw const UnconfirmedAllocationException();
    }

    // 2. حراسة منع التكرار
    await _idempotencyService.assertNotProcessed(idempotencyKey);

    return await _repository.runInTransaction(() async {
      // 3. التحقق من الحساب المستقبل
      final depositAccount = await _repository.getAccountById(depositAccountId);
      if (depositAccount == null) {
        throw EntityNotFoundException(entityType: 'حساب الإيداع', entityId: depositAccountId);
      }
      if (depositAccount.isArchived) {
        throw AccountArchivedException(depositAccountId);
      }

      final totalIncome = plan.totalIncome;

      // أ) إيداع الدخل الأساسي في الحساب
      final initialBalance = depositAccount.balance;
      final balanceAfterDeposit = initialBalance + totalIncome;
      await _repository.updateAccountBalance(depositAccountId, balanceAfterDeposit);

      // تسجيل معاملة إيداع الدخل الكبرى
      final incomeTxnId = '${plan.id}_deposit';
      await _repository.saveTransaction(TransactionEntity(
        id: incomeTxnId,
        accountId: depositAccountId,
        type: TransactionType.income,
        amount: totalIncome,
        transactionDate: plan.createdAt,
        note: 'إيداع ${plan.title}',
        idempotencyKey: '${idempotencyKey}_deposit',
        createdAt: DateTime.now(),
      ));

      // ب) احتساب وتوزيع الحصص بنداً بنداً
      final resultItems = <AllocationResultItem>[];
      var runningBalance = balanceAfterDeposit;
      var totalAllocatedToTargets = const Money.zero();

      // توزيع بنود النسبة المئوية بدقة Largest Remainder
      final percentageItems = plan.items.where((i) => i.mode == AllocationMode.percentage).toList();
      final percentages = percentageItems.map((i) => i.percentage ?? 0.0).toList();
      final percentageShares = percentageItems.isEmpty
          ? <Money>[]
          : Money.apportionByPercentages(totalIncome, percentages);

      var pIndex = 0;
      for (final item in plan.items) {
        Money itemAmount;
        if (item.mode == AllocationMode.fixedAmount) {
          itemAmount = item.fixedAmount ?? const Money.zero();
        } else {
          itemAmount = percentageShares[pIndex++];
        }

        if (itemAmount.isZero) continue;

        // تطبيق الأثر المالي حسب نوع الهدف
        switch (item.targetType) {
          case AllocationTargetType.emergencyFund:
            // تعزيز صندوق الطوارئ المعزول
            final currentEF = await _repository.getEmergencyFundBalance();
            await _repository.updateEmergencyFundBalance(currentEF + itemAmount);
            runningBalance -= itemAmount;
            await _repository.saveTransaction(TransactionEntity(
              id: '${plan.id}_ef_${item.id}',
              accountId: depositAccountId,
              type: TransactionType.emergencyDeposit,
              amount: itemAmount,
              transactionDate: plan.createdAt,
              note: 'تغذية صندوق الطوارئ من الدخل',
              createdAt: DateTime.now(),
            ));
            break;

          case AllocationTargetType.goal:
            // تعزيز مدخرات الهدف المالي
            final currentGoal = await _repository.getGoalSavedAmount(item.targetId);
            await _repository.updateGoalSavedAmount(item.targetId, currentGoal + itemAmount);
            runningBalance -= itemAmount;
            await _repository.saveTransaction(TransactionEntity(
              id: '${plan.id}_goal_${item.id}',
              accountId: depositAccountId,
              type: TransactionType.goalAllocation,
              amount: itemAmount,
              transactionDate: plan.createdAt,
              note: 'تخصيص هدف: ${item.title}',
              createdAt: DateTime.now(),
            ));
            break;

          case AllocationTargetType.obligation:
            // حجز للالتزامات الشهرية
            break;

          case AllocationTargetType.flexibleBudget:
            // الميزانية المرنة تظل في الحساب للصرف اليومي
            break;
        }

        totalAllocatedToTargets += itemAmount;
        resultItems.add(AllocationResultItem(
          planItem: item,
          allocatedAmount: itemAmount,
          destinationNote: 'تم تخصيص ${itemAmount.formatArabic()} لـ ${item.title}',
        ));
      }

      // ج) تحديث رصيد الحساب بالصافي المتبقي للإنفاق
      await _repository.updateAccountBalance(depositAccountId, runningBalance);

      // د) حساب المتبقي للميزانية المرنة: Total Income - Total Allocated
      final flexibleRemainder = totalIncome - totalAllocatedToTargets;

      // تسجيل أثر التدقيق النهائي
      await _repository.recordAuditEntry(AuditTrailEntry(
        id: '${plan.id}_audit',
        transactionId: plan.id,
        operationType: 'income_allocation',
        entityType: 'account',
        entityId: depositAccountId,
        balanceBefore: initialBalance,
        delta: totalIncome - (balanceAfterDeposit - runningBalance),
        balanceAfter: runningBalance,
        idempotencyKey: idempotencyKey,
        note: 'توزيع الدخل المعتمد: مخصصات ${totalAllocatedToTargets.formatArabic()}، ومتبقي مرن ${flexibleRemainder.formatArabic()}',
        timestamp: DateTime.now(),
      ));

      // تثبيت منع التكرار
      await _idempotencyService.markOperationCompleted(
        idempotencyKey: idempotencyKey,
        transactionId: plan.id,
        operationType: 'income_allocation',
        responseSummary: 'توزيع دخل بقيمة ${totalIncome.formatArabic()}',
      );

      final result = AllocationResult(
        planId: plan.id,
        totalIncome: totalIncome,
        items: resultItems,
        flexibleBudgetRemainder: flexibleRemainder,
        executedAt: DateTime.now(),
        depositAccountId: depositAccountId,
      );

      // التأكد من استيفاء شرط الصفرية
      assert(result.isZeroSumValid, 'فشل القيد الصفري: مجموع التوزيعات لا يساوي إجمالي الدخل');

      return result;
    });
  }
}

