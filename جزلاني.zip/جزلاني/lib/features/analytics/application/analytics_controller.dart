import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/database/providers/database_providers.dart';
import '../data/repositories/analytics_repository_impl.dart';
import '../domain/repositories/analytics_repository.dart';
import 'analytics_state.dart';
import 'services/report_export_service.dart';

/// موفر مستودع التحليلات والتقارير
final analyticsRepositoryProvider = Provider<AnalyticsRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return AnalyticsRepositoryImpl(db);
});

/// موفر متحكم التحليلات والتقارير
final analyticsControllerProvider =
    StateNotifierProvider<AnalyticsController, AnalyticsState>((ref) {
  final repo = ref.watch(analyticsRepositoryProvider);
  return AnalyticsController(repository: repo);
});

/// متحكم إدارة لوحة التحليلات والتقارير المالية والتوقعات
class AnalyticsController extends StateNotifier<AnalyticsState> {
  final AnalyticsRepository _repository;

  AnalyticsController({
    required AnalyticsRepository repository,
  })  : _repository = repository,
        super(const AnalyticsState()) {
    loadAll();
  }

  /// تحميل كافة بيانات التحليلات والتقارير
  Future<void> loadAll() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final summaries = await _repository.getMonthlySummaries();
      final categories = await _repository.getCategoryExpenseBreakdown(
        periodYearMonth: state.selectedPeriodYearMonth,
      );
      final buckets = await _repository.getBucketDistributionReport(
        periodYearMonth: state.selectedPeriodYearMonth,
      );
      final events = await _repository.getCalendarEvents();
      final forecast = await _repository.getFinancialForecast();

      state = state.copyWith(
        isLoading: false,
        monthlySummaries: summaries,
        categoryBreakdowns: categories,
        bucketReports: buckets,
        calendarEvents: events,
        forecastModel: forecast,
        selectedPeriodYearMonth: state.selectedPeriodYearMonth ??
            (summaries.isNotEmpty ? summaries.first.periodYearMonth : null),
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تحميل بيانات التحليلات: $e',
      );
    }
  }

  /// تغيير الشهر المختار للتحليل
  Future<void> selectPeriodYearMonth(String periodYearMonth) async {
    state = state.copyWith(
      selectedPeriodYearMonth: periodYearMonth,
      isLoading: true,
    );
    try {
      final categories = await _repository.getCategoryExpenseBreakdown(
        periodYearMonth: periodYearMonth,
      );
      final buckets = await _repository.getBucketDistributionReport(
        periodYearMonth: periodYearMonth,
      );

      state = state.copyWith(
        isLoading: false,
        categoryBreakdowns: categories,
        bucketReports: buckets,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'فشل تصفية التقرير بالشهر: $e',
      );
    }
  }

  /// تصدير ملخصات الأشهر بصيغة CSV
  String exportMonthlySummariesCsv() {
    return ReportExportService.exportMonthlySummariesToCsv(
      state.monthlySummaries,
    );
  }

  /// تصدير تفاصيل التصنيفات بصيغة CSV
  String exportCategoriesCsv() {
    return ReportExportService.exportCategoriesToCsv(
      state.categoryBreakdowns,
    );
  }

  /// تصدير أحداث التقويم المالي بصيغة CSV
  String exportCalendarEventsCsv() {
    return ReportExportService.exportCalendarEventsToCsv(
      state.calendarEvents,
    );
  }
}

