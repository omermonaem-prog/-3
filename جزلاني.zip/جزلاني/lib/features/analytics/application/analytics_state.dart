import '../../../../core/finance/money.dart';
import '../domain/entities/bucket_distribution_report.dart';
import '../domain/entities/category_expense_breakdown.dart';
import '../domain/entities/financial_calendar_event.dart';
import '../domain/entities/financial_forecast_model.dart';
import '../domain/entities/monthly_financial_summary.dart';

/// حالة واجهة التحليلات والتقارير المالية
class AnalyticsState {
  final bool isLoading;
  final List<MonthlyFinancialSummary> monthlySummaries;
  final List<CategoryExpenseBreakdown> categoryBreakdowns;
  final List<BucketDistributionReport> bucketReports;
  final List<FinancialCalendarEvent> calendarEvents;
  final FinancialForecastModel? forecastModel;
  final String? selectedPeriodYearMonth;
  final String? errorMessage;
  final String? successMessage;

  const AnalyticsState({
    this.isLoading = false,
    this.monthlySummaries = const [],
    this.categoryBreakdowns = const [],
    this.bucketReports = const [],
    this.calendarEvents = const [],
    this.forecastModel,
    this.selectedPeriodYearMonth,
    this.errorMessage,
    this.successMessage,
  });

  /// ملخص الشهر المختار أو أحدث شهر متاح
  MonthlyFinancialSummary? get selectedMonthSummary {
    if (monthlySummaries.isEmpty) return null;
    if (selectedPeriodYearMonth == null) return monthlySummaries.first;
    return monthlySummaries.firstWhere(
      (s) => s.periodYearMonth == selectedPeriodYearMonth,
      orElse: () => monthlySummaries.first,
    );
  }

  /// إجمالي الدخل لجميع الأشهر المسجلة
  Money get totalAllTimeIncome => monthlySummaries.fold<Money>(
        const Money.zero(),
        (sum, s) => sum + s.totalIncome,
      );

  /// إجمالي المصروفات لجميع الأشهر المسجلة
  Money get totalAllTimeExpenses => monthlySummaries.fold<Money>(
        const Money.zero(),
        (sum, s) => sum + s.totalExpenses,
      );

  /// إجمالي الوفر التراكمي
  Money get totalCumulativeSavings =>
      totalAllTimeIncome > totalAllTimeExpenses
          ? totalAllTimeIncome - totalAllTimeExpenses
          : const Money.zero();

  AnalyticsState copyWith({
    bool? isLoading,
    List<MonthlyFinancialSummary>? monthlySummaries,
    List<CategoryExpenseBreakdown>? categoryBreakdowns,
    List<BucketDistributionReport>? bucketReports,
    List<FinancialCalendarEvent>? calendarEvents,
    FinancialForecastModel? forecastModel,
    String? selectedPeriodYearMonth,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return AnalyticsState(
      isLoading: isLoading ?? this.isLoading,
      monthlySummaries: monthlySummaries ?? this.monthlySummaries,
      categoryBreakdowns: categoryBreakdowns ?? this.categoryBreakdowns,
      bucketReports: bucketReports ?? this.bucketReports,
      calendarEvents: calendarEvents ?? this.calendarEvents,
      forecastModel: forecastModel ?? this.forecastModel,
      selectedPeriodYearMonth:
          selectedPeriodYearMonth ?? this.selectedPeriodYearMonth,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage: clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

