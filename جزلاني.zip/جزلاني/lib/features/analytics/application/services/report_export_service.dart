import '../../domain/entities/category_expense_breakdown.dart';
import '../../domain/entities/financial_calendar_event.dart';
import '../../domain/entities/monthly_financial_summary.dart';

/// خدمة تصدير التقارير المالية (CSV & Reporting Export Service)
///
/// تولد مخرجات متوافقة مع معايير RFC 4180 وتتضمن UTF-8 BOM لدعم الفتح
/// المباشر في برنامج Microsoft Excel باللغة العربية دون تشوه الترميز.
class ReportExportService {
  static const String _utf8Bom = '\uFEFF';

  /// تصدير ملخصات الدخل والمصروفات والوفر الشهري بصيغة CSV
  static String exportMonthlySummariesToCsv(
    List<MonthlyFinancialSummary> summaries,
  ) {
    final buffer = StringBuffer();
    buffer.write(_utf8Bom); // BOM لدعم العربية في Excel
    buffer.writeln('الفترة,الشهر,إجمالي الدخل (ر.س),الراتب الأساسي (ر.س),الدخل الإضافي (ر.س),إجمالي المصروفات (ر.س),صافي الوفر (ر.س),نسبة الادخار (%)');

    for (final s in summaries) {
      buffer.writeln(
        '"${s.periodYearMonth}",'
        '"${s.monthLabel}",'
        '${s.totalIncome.toMajorUnits().toStringAsFixed(2)},'
        '${s.salaryIncome.toMajorUnits().toStringAsFixed(2)},'
        '${s.additionalIncome.toMajorUnits().toStringAsFixed(2)},'
        '${s.totalExpenses.toMajorUnits().toStringAsFixed(2)},'
        '${s.netSavings.toMajorUnits().toStringAsFixed(2)},'
        '${s.savingsRatePercentage.toStringAsFixed(1)}%',
      );
    }

    return buffer.toString();
  }

  /// تصدير توزيع المصروفات حسب التصنيف بصيغة CSV
  static String exportCategoriesToCsv(
    List<CategoryExpenseBreakdown> categories,
  ) {
    final buffer = StringBuffer();
    buffer.write(_utf8Bom);
    buffer.writeln('التصنيف,المبلغ المصروف (ر.س),النسبة من الإجمالي (%),عدد العمليات');

    for (final c in categories) {
      buffer.writeln(
        '"${c.categoryName}",'
        '${c.totalAmount.toMajorUnits().toStringAsFixed(2)},'
        '${c.percentageOfTotal.toStringAsFixed(1)}%,'
        '${c.transactionCount}',
      );
    }

    return buffer.toString();
  }

  /// تصدير أحداث التقويم المالي
  static String exportCalendarEventsToCsv(
    List<FinancialCalendarEvent> events,
  ) {
    final buffer = StringBuffer();
    buffer.write(_utf8Bom);
    buffer.writeln('التاريخ,الحدث المالي,المبلغ (ر.س),النوع,الحالة');

    for (final e in events) {
      final dateStr = '${e.date.year}/${e.date.month.toString().padLeft(2, '0')}/${e.date.day.toString().padLeft(2, '0')}';
      buffer.writeln(
        '"$dateStr",'
        '"${e.title}",'
        '${e.amount.toMajorUnits().toStringAsFixed(2)},'
        '"${e.type.labelArabic}",'
        '"${e.status.labelArabic}"',
      );
    }

    return buffer.toString();
  }
}

