import '../entities/bucket_distribution_report.dart';
import '../entities/category_expense_breakdown.dart';
import '../entities/financial_calendar_event.dart';
import '../entities/financial_forecast_model.dart';
import '../entities/monthly_financial_summary.dart';

/// العقد التجريدي لمستودع التقارير والتحليلات المالية
abstract class AnalyticsRepository {
  /// ملخصات الدخل والمصروف الشهرية
  Future<List<MonthlyFinancialSummary>> getMonthlySummaries({int limitMonths = 12});

  /// توزيع المصروفات حسب التصنيف لفترة معينة (أو إجمالي)
  Future<List<CategoryExpenseBreakdown>> getCategoryExpenseBreakdown({
    String? periodYearMonth,
  });

  /// تقرير توزيع الدخل على الأقسام الخمسة
  Future<List<BucketDistributionReport>> getBucketDistributionReport({
    String? periodYearMonth,
  });

  /// أحداث التقويم المالي (معاملات، فواتير، أقساط)
  Future<List<FinancialCalendarEvent>> getCalendarEvents({
    DateTime? startDate,
    DateTime? endDate,
  });

  /// نموذج التوقعات المالية المستقبلية
  Future<FinancialForecastModel> getFinancialForecast();
}

