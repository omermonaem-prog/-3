import '../../../../core/finance/money.dart';

/// نموذج التوقعات المالية المستقبلية (Financial Forecast Model)
///
/// هام: هذه أرقام احتمالية تقديرية استرشادية مبنية على السلوك التاريخي السابق
/// وليست ضمانات مالية أو حقائق مؤكدة.
class FinancialForecastModel {
  final Money averageMonthlyIncome;
  final Money averageMonthlyExpenses;
  final Money averageMonthlySavings;
  final Money projectedNetWorthIn3Months;
  final Money projectedNetWorthIn6Months;
  final Money projectedNetWorthIn12Months;
  final Money projectedEmergencyFundIn6Months;
  final int monthsUntilEmergencyTargetReached;
  final String historicalBasis; // مثال: "مبني على متوسط حركات آخر 3 أشهر"
  final String disclaimer;

  const FinancialForecastModel({
    required this.averageMonthlyIncome,
    required this.averageMonthlyExpenses,
    required this.averageMonthlySavings,
    required this.projectedNetWorthIn3Months,
    required this.projectedNetWorthIn6Months,
    required this.projectedNetWorthIn12Months,
    required this.projectedEmergencyFundIn6Months,
    required this.monthsUntilEmergencyTargetReached,
    this.historicalBasis = 'مبني على متوسط بيانات الأشهر السابقة والالتزامات النشطة',
    this.disclaimer = 'تنبيه محاسبي: التوقعات هي تقديرات استرشادية احتمالية تعتمد على ثبات النمط المالي السابق، ولا تمثل التزاماً أو ضماناً مالياً قاطعاً.',
  });
}

