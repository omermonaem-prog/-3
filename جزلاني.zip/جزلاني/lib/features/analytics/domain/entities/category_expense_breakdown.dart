import '../../../../core/finance/money.dart';

/// توزيع المصروفات حسب التصنيف (Category Expense Breakdown)
class CategoryExpenseBreakdown {
  final String categoryId;
  final String categoryName;
  final String? categoryIcon;
  final String colorHex;
  final Money totalAmount;
  final double percentageOfTotal;
  final int transactionCount;

  const CategoryExpenseBreakdown({
    required this.categoryId,
    required this.categoryName,
    this.categoryIcon,
    this.colorHex = '#0E3B2E',
    required this.totalAmount,
    required this.percentageOfTotal,
    required this.transactionCount,
  });
}

