import '../../../../core/finance/money.dart';

/// تقرير توزيع الدخل على الأقسام الخمسة (Bucket Distribution Report)
///
/// الأقسام المعتمدة:
/// 1. المسؤوليات والبيت (40%)
/// 2. الادخار العام (20%)
/// 3. صندوق الطوارئ (20%)
/// 4. تطوير المهارات والعمل (10%)
/// 5. الترفيه والمصروف الشخصي (10%)
class BucketDistributionReport {
  final String bucketName;
  final String description;
  final Money allocatedAmount;
  final double targetPercentage;
  final double actualPercentage;
  final String colorHex;

  const BucketDistributionReport({
    required this.bucketName,
    required this.description,
    required this.allocatedAmount,
    required this.targetPercentage,
    required this.actualPercentage,
    required this.colorHex,
  });
}

