import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../application/analytics_controller.dart';
import '../widgets/category_pie_chart.dart';
import '../widgets/forecast_projection_card.dart';
import '../widgets/monthly_bar_comparison_chart.dart';
import 'financial_calendar_screen.dart';
import 'forecasts_screen.dart';
import 'monthly_report_detail_screen.dart';

/// الشاشة الرئيسية للوحة التحليلات والتقارير المالية (Analytics Dashboard)
class AnalyticsDashboardScreen extends ConsumerWidget {
  const AnalyticsDashboardScreen({super.key});

  void _showExportDialog(BuildContext context, WidgetRef ref) {
    final controller = ref.read(analyticsControllerProvider.notifier);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.file_download_outlined, color: AppColors.forestGreen),
            const SizedBox(width: 8),
            Text('تصدير التقارير المالية', style: AppTypography.headingH3),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'اختر صيغة وتقرير التصدير المالي (متوافق مع Microsoft Excel بصيغة UTF-8 BOM):',
              style: AppTypography.bodySecondary,
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.calendar_month, color: AppColors.forestGreen),
              title: const Text('تقرير الدخل والمصروفات الشهري (CSV)'),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: AppColors.borderSubtleLight),
              ),
              onTap: () {
                final csv = controller.exportMonthlySummariesCsv();
                Navigator.pop(ctx);
                _showExportSuccess(context, 'تم توليد ملف تقرير الدخل والمصروفات بنجاح (${csv.length} بايت)');
              },
            ),
            const SizedBox(height: 10),
            ListTile(
              leading: const Icon(Icons.pie_chart_outline, color: AppColors.champagneGold),
              title: const Text('تقرير توزيع المصروفات حسب التصنيف (CSV)'),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: AppColors.borderSubtleLight),
              ),
              onTap: () {
                final csv = controller.exportCategoriesCsv();
                Navigator.pop(ctx);
                _showExportSuccess(context, 'تم توليد ملف توزيع التصنيفات بنجاح (${csv.length} بايت)');
              },
            ),
            const SizedBox(height: 10),
            ListTile(
              leading: const Icon(Icons.event_note, color: AppColors.cashIn),
              title: const Text('تقرير أحداث التقويم المالي (CSV)'),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(color: AppColors.borderSubtleLight),
              ),
              onTap: () {
                final csv = controller.exportCalendarEventsCsv();
                Navigator.pop(ctx);
                _showExportSuccess(context, 'تم توليد ملف أحداث التقويم بنجاح (${csv.length} بايت)');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
  }

  void _showExportSuccess(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.forestGreen,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(analyticsControllerProvider);
    final controller = ref.read(analyticsControllerProvider.notifier);
    final currentSummary = state.selectedMonthSummary;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('التقارير والتحليلات المالية'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today_outlined, color: AppColors.forestGreen),
            tooltip: 'التقويم المالي',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const FinancialCalendarScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.file_download_outlined, color: AppColors.forestGreen),
            tooltip: 'تصدير التقارير',
            onPressed: () => _showExportDialog(context, ref),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Current Month Highlight Card
              if (currentSummary != null)
                LuxuryCard(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(currentSummary.monthLabel, style: AppTypography.headingH3),
                          StatusBadge(
                            text: 'نسبة الوفر: ${currentSummary.savingsRatePercentage.toStringAsFixed(1)}%',
                            color: currentSummary.hasSurplus
                                ? AppColors.cashIn.withValues(alpha: 0.12)
                                : AppColors.criticalRed.withValues(alpha: 0.12),
                            textColor: currentSummary.hasSurplus ? AppColors.cashIn : AppColors.criticalRed,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('إجمالي الدخل', style: AppTypography.bodySecondary),
                              const SizedBox(height: 2),
                              Text(
                                currentSummary.totalIncome.formatArabic(),
                                style: AppTypography.bodyPrimary.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.cashIn,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text('إجمالي المصروفات', style: AppTypography.bodySecondary),
                              const SizedBox(height: 2),
                              Text(
                                currentSummary.totalExpenses.formatArabic(),
                                style: AppTypography.bodyPrimary.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.cashOut,
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('صافي الوفر', style: AppTypography.bodySecondary),
                              const SizedBox(height: 2),
                              Text(
                                currentSummary.netSavings.formatArabic(),
                                style: AppTypography.bodyPrimary.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: currentSummary.hasSurplus ? AppColors.forestGreen : AppColors.criticalRed,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 20),

              // 2. Chart Section: Monthly Comparison
              LuxuryCard(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('مقارنة الدخل بالمصروفات شهرياً', style: AppTypography.headingH3),
                    const SizedBox(height: 14),
                    MonthlyBarComparisonChart(summaries: state.monthlySummaries),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 3. Category Breakdown Card
              LuxuryCard(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('تحليل المصروفات حسب التصنيف', style: AppTypography.headingH3),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const MonthlyReportDetailScreen()),
                            );
                          },
                          child: const Text('تقرير الأقسام 40/20'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    CategoryPieChart(categories: state.categoryBreakdowns),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // 4. Forecasts Section Card
              if (state.forecastModel != null)
                ForecastProjectionCard(
                  forecast: state.forecastModel!,
                  onTapDetails: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ForecastsScreen()),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

