import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/financial_forecast_model.dart';

/// بطاقة عرض التوقعات والتقديرات المالية المستقبلية
class ForecastProjectionCard extends StatelessWidget {
  final FinancialForecastModel forecast;
  final VoidCallback? onTapDetails;

  const ForecastProjectionCard({
    super.key,
    required this.forecast,
    this.onTapDetails,
  });

  @override
  Widget build(BuildContext context) {
    return LuxuryCard(
      onTap: onTapDetails,
      backgroundColor: const Color(0xFF132B23),
      borderColor: AppColors.champagneGold.withValues(alpha: 0.3),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.champagneGold.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.auto_graph_rounded,
                  color: AppColors.champagneGold,
                  size: 22,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'التوقعات المالية الاسترشادية',
                      style: AppTypography.headingH3.copyWith(color: Colors.white),
                    ),
                    Text(
                      'تقديرات مستقبلية مبنية على الأداء السابق',
                      style: AppTypography.bodySecondary.copyWith(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              if (onTapDetails != null)
                const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.white60),
            ],
          ),
          const SizedBox(height: 18),

          // 3 Projected metrics: 3 months, 6 months, 12 months net worth
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildMetricColumn('خلال 3 أشهر', forecast.projectedNetWorthIn3Months.formatArabic()),
              Container(width: 1, height: 32, color: Colors.white24),
              _buildMetricColumn('خلال 6 أشهر', forecast.projectedNetWorthIn6Months.formatArabic()),
              Container(width: 1, height: 32, color: Colors.white24),
              _buildMetricColumn('خلال 12 شهراً', forecast.projectedNetWorthIn12Months.formatArabic()),
            ],
          ),
          const SizedBox(height: 16),

          // Prominent Disclaimer Alert Box
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline, color: AppColors.champagneGold, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    forecast.disclaimer,
                    style: AppTypography.bodySecondary.copyWith(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricColumn(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: AppTypography.bodySecondary.copyWith(
            color: Colors.white70,
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: AppTypography.bodyPrimary.copyWith(
            color: AppColors.champagneGoldBright,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
      ],
    );
  }
}

