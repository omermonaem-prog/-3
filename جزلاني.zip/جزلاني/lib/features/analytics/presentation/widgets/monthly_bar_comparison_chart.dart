import 'dart:math';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../domain/entities/monthly_financial_summary.dart';

/// مخطط بياني شريطي لمقارنة الدخل بالمصروفات شهرياً
class MonthlyBarComparisonChart extends StatelessWidget {
  final List<MonthlyFinancialSummary> summaries;

  const MonthlyBarComparisonChart({
    super.key,
    required this.summaries,
  });

  @override
  Widget build(BuildContext context) {
    if (summaries.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'لا توجد بيانات كافية لعرض المقارنة الشهرية',
            style: AppTypography.bodySecondary,
          ),
        ),
      );
    }

    // إيجاد أعلى قيمة لحساب النسبة المئوية لارتفاع الأعمدة
    int maxMinor = 1;
    for (final s in summaries) {
      maxMinor = max(maxMinor, max(s.totalIncome.minorUnits, s.totalExpenses.minorUnits));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Legend
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildLegendItem('إجمالي الدخل', AppColors.cashIn),
            const SizedBox(width: 24),
            _buildLegendItem('إجمالي المصروفات', AppColors.cashOut),
          ],
        ),
        const SizedBox(height: 16),

        // Bars Container
        SizedBox(
          height: 170,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: summaries.reversed.map((s) {
              final incomeHeight = ((s.totalIncome.minorUnits / maxMinor) * 120.0).clamp(6.0, 120.0);
              final expenseHeight = ((s.totalExpenses.minorUnits / maxMinor) * 120.0).clamp(6.0, 120.0);

              return Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // Income Bar
                      Container(
                        width: 14,
                        height: incomeHeight,
                        decoration: BoxDecoration(
                          color: AppColors.cashIn,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      ),
                      const SizedBox(width: 4),
                      // Expense Bar
                      Container(
                        width: 14,
                        height: expenseHeight,
                        decoration: BoxDecoration(
                          color: AppColors.cashOut,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    s.periodYearMonth.split('-').last, // الشهر رقمياً
                    style: AppTypography.bodySecondary.copyWith(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildLegendItem(String title, Color color) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        const SizedBox(width: 6),
        Text(title, style: AppTypography.bodySecondary.copyWith(fontSize: 12)),
      ],
    );
  }
}

