import '../../../../core/finance/money.dart';
import '../domain/entities/bucket_distribution_report.dart';
import '../domain/entities/category_expense_breakdown.dart';
import '../domain/entities/financial_calendar_event.dart';
import '../domain/entities/financial_forecast_model.dart';
import '../domain/entities/monthly_financial_summary.dart';
import '../domain/repositories/analytics_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع التحليلات والتقارير
class InMemoryAnalyticsRepository implements AnalyticsRepository {
  final List<MonthlyFinancialSummary> monthlySummaries = [];
  final List<CategoryExpenseBreakdown> categoryBreakdowns = [];
  final List<BucketDistributionReport> bucketReports = [];
  final List<FinancialCalendarEvent> calendarEvents = [];
  FinancialForecastModel? forecastModel;

  @override
  Future<List<MonthlyFinancialSummary>> getMonthlySummaries({
    int limitMonths = 12,
  }) async {
    final list = List<MonthlyFinancialSummary>.from(monthlySummaries);
    list.sort((a, b) => b.periodYearMonth.compareTo(a.periodYearMonth));
    return list.take(limitMonths).toList();
  }

  @override
  Future<List<CategoryExpenseBreakdown>> getCategoryExpenseBreakdown({
    String? periodYearMonth,
  }) async {
    final list = List<CategoryExpenseBreakdown>.from(categoryBreakdowns);
    list.sort((a, b) => b.totalAmount.compareTo(a.totalAmount));
    return list;
  }

  @override
  Future<List<BucketDistributionReport>> getBucketDistributionReport({
    String? periodYearMonth,
  }) async {
    if (bucketReports.isNotEmpty) return bucketReports;

    // أقسام الميزانية الخمسة الافتراضية
    return const [
      BucketDistributionReport(
        bucketName: 'المسؤوليات والبيت',
        description: 'الفواتير والإيجار والمصاريف الأساسية',
        allocatedAmount: Money.fromMinorUnits(400000),
        targetPercentage: 40.0,
        actualPercentage: 40.0,
        colorHex: '#0E3B2E',
      ),
      BucketDistributionReport(
        bucketName: 'الادخار العام',
        description: 'الاستثمار والادخار بعيد المدى',
        allocatedAmount: Money.fromMinorUnits(200000),
        targetPercentage: 20.0,
        actualPercentage: 20.0,
        colorHex: '#C5A059',
      ),
      BucketDistributionReport(
        bucketName: 'صندوق الطوارئ',
        description: 'الأمان المالي والظروف القاهرة',
        allocatedAmount: Money.fromMinorUnits(200000),
        targetPercentage: 20.0,
        actualPercentage: 20.0,
        colorHex: '#C93B2B',
      ),
      BucketDistributionReport(
        bucketName: 'تطوير المهارات والعمل',
        description: 'الدورات والكتب وأدوات التطوير',
        allocatedAmount: Money.fromMinorUnits(100000),
        targetPercentage: 10.0,
        actualPercentage: 10.0,
        colorHex: '#1B6B54',
      ),
      BucketDistributionReport(
        bucketName: 'الترفيه والمصروف الشخصي',
        description: 'المطاعم والرحلات والهوايات',
        allocatedAmount: Money.fromMinorUnits(100000),
        targetPercentage: 10.0,
        actualPercentage: 10.0,
        colorHex: '#D4AF37',
      ),
    ];
  }

  @override
  Future<List<FinancialCalendarEvent>> getCalendarEvents({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final list = List<FinancialCalendarEvent>.from(calendarEvents);
    list.sort((a, b) => a.date.compareTo(b.date));
    return list;
  }

  @override
  Future<FinancialForecastModel> getFinancialForecast() async {
    if (forecastModel != null) return forecastModel!;

    // حساب نموذج التوقعات التقديرية بناءً على الملخصات
    Money avgIncome = const Money.zero();
    Money avgExpenses = const Money.zero();

    if (monthlySummaries.isNotEmpty) {
      int totalIncomeMinor = 0;
      int totalExpensesMinor = 0;
      for (final m in monthlySummaries) {
        totalIncomeMinor += m.totalIncome.minorUnits;
        totalExpensesMinor += m.totalExpenses.minorUnits;
      }
      final count = monthlySummaries.length;
      avgIncome = Money.fromMinorUnits(totalIncomeMinor ~/ count);
      avgExpenses = Money.fromMinorUnits(totalExpensesMinor ~/ count);
    } else {
      avgIncome = Money.fromMajorUnits(15000.00);
      avgExpenses = Money.fromMajorUnits(10000.00);
    }

    final avgSavings = avgIncome > avgExpenses
        ? avgIncome - avgExpenses
        : const Money.zero();

    return FinancialForecastModel(
      averageMonthlyIncome: avgIncome,
      averageMonthlyExpenses: avgExpenses,
      averageMonthlySavings: avgSavings,
      projectedNetWorthIn3Months: avgSavings * 3,
      projectedNetWorthIn6Months: avgSavings * 6,
      projectedNetWorthIn12Months: avgSavings * 12,
      projectedEmergencyFundIn6Months: avgSavings * 2,
      monthsUntilEmergencyTargetReached: 6,
    );
  }
}

