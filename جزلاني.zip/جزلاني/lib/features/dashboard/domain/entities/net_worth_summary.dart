/// الكيان المالي لملخص الثروة الصافية (Domain Entity)
class NetWorthSummary {
  final double netWorth;
  final double totalAssets;
  final double totalDebts;
  final double availableToSpend;
  final double lockedObligations;
  final double monthlyChangePercentage;

  const NetWorthSummary({
    required this.netWorth,
    required this.totalAssets,
    required this.totalDebts,
    required this.availableToSpend,
    required this.lockedObligations,
    required this.monthlyChangePercentage,
  });
}

