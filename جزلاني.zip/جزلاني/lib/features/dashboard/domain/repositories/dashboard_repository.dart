import '../entities/net_worth_summary.dart';

/// العقد المجرد لمستودع لوحة التحكم (Domain Interface)
abstract class DashboardRepository {
  Future<NetWorthSummary> getNetWorthSummary();
}

