import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/obligation_entity.dart';

/// بطاقة عرض الالتزام المالي أو الفاتورة
class ObligationCard extends StatelessWidget {
  final ObligationEntity obligation;
  final VoidCallback? onPay;
  final VoidCallback? onDeactivate;

  const ObligationCard({
    super.key,
    required this.obligation,
    this.onPay,
    this.onDeactivate,
  });

  @override
  Widget build(BuildContext context) {
    final isOverdue = obligation.isOverdue;

    return LuxuryCard(
      borderColor: isOverdue ? AppColors.criticalRed.withValues(alpha: 0.3) : null,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isOverdue
                      ? AppColors.criticalRed.withValues(alpha: 0.12)
                      : AppColors.forestGreen.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.receipt_long_rounded,
                  color: isOverdue ? AppColors.criticalRed : AppColors.forestGreen,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      obligation.title,
                      style: AppTypography.headingH3,
                    ),
                    if (obligation.billerName != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        obligation.billerName!,
                        style: AppTypography.bodySecondary,
                      ),
                    ],
                  ],
                ),
              ),
              StatusBadge(
                text: isOverdue ? 'متأخر للسداد' : obligation.recurrenceType.labelArabic,
                color: isOverdue
                    ? AppColors.criticalRed.withValues(alpha: 0.15)
                    : AppColors.surfaceSubtleLight,
                textColor: isOverdue ? AppColors.criticalRed : AppColors.forestGreen,
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Amounts & Due Date row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('القيمة المستحقة', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    obligation.amount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isOverdue ? AppColors.criticalRed : AppColors.forestGreen,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('يوم الاستحقاق', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    'يوم ${obligation.dueDayOfMonth} من الشهر',
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Pay button
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onPay,
                  icon: const Icon(Icons.check_circle_outline, size: 18),
                  label: const Text('تسجيل السداد'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isOverdue ? AppColors.criticalRed : AppColors.forestGreen,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
              if (onDeactivate != null) ...[
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: AppColors.slateMuted, size: 20),
                  tooltip: 'تعطيل الالتزام',
                  onPressed: onDeactivate,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

