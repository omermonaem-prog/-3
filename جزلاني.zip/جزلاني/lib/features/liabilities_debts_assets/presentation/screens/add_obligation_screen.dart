import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../domain/entities/obligation_entity.dart';
import '../application/liabilities_debts_assets_controller.dart';

/// شاشة إضافة التزام مالي جديد
class AddObligationScreen extends ConsumerStatefulWidget {
  const AddObligationScreen({super.key});

  @override
  ConsumerState<AddObligationScreen> createState() => _AddObligationScreenState();
}

class _AddObligationScreenState extends ConsumerState<AddObligationScreen> {
  final _titleController = TextEditingController();
  final _billerController = TextEditingController();
  final _amountController = TextEditingController();
  final _dayController = TextEditingController(text: '1');
  ObligationRecurrence _recurrence = ObligationRecurrence.monthly;
  bool _isLockedFromSalary = true;
  String? _error;

  @override
  void dispose() {
    _titleController.dispose();
    _billerController.dispose();
    _amountController.dispose();
    _dayController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _error = null);

    final title = _titleController.text.trim();
    if (title.isEmpty) {
      setState(() => _error = 'اسم الالتزام مطلوب');
      return;
    }

    Money amount;
    try {
      amount = Money.parse(_amountController.text.trim());
      if (!amount.isPositive) {
        setState(() => _error = 'مبلغ الالتزام يجب أن يكون أكبر من صفر');
        return;
      }
    } catch (_) {
      setState(() => _error = 'يرجى إدخال مبلغ صحيح');
      return;
    }

    final day = int.tryParse(_dayController.text.trim()) ?? 1;

    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final success = await controller.createObligation(
      title: title,
      billerName: _billerController.text.trim(),
      amount: amount,
      recurrenceType: _recurrence,
      dueDayOfMonth: day.clamp(1, 31),
      isLockedFromSalary: _isLockedFromSalary,
    );

    if (success && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('إضافة التزام مالي جديد'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(
                labelText: 'اسم الالتزام / الفاتورة *',
                hintText: 'مثال: إيجار الشقة، فاتورة الكهرباء، اشتراك نت...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.receipt_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _billerController,
              decoration: InputDecoration(
                labelText: 'الجهة المصدرة / المفَوْتِر (اختياري)',
                hintText: 'مثال: شركة الكهرباء، المالك، STC...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.business_rounded),
              ),
            ),
            const SizedBox(height: 16),

            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ المستحق (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 16),

            // Recurrence Type Dropdown
            DropdownButtonFormField<ObligationRecurrence>(
              value: _recurrence,
              decoration: InputDecoration(
                labelText: 'نوع التكرار الدوري *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.repeat_rounded),
              ),
              items: ObligationRecurrence.values.map((r) {
                return DropdownMenuItem(value: r, child: Text(r.labelArabic));
              }).toList(),
              onChanged: (val) {
                if (val != null) setState(() => _recurrence = val);
              },
            ),
            const SizedBox(height: 16),

            // Due day of month
            TextField(
              controller: _dayController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'يوم الاستحقاق من الشهر (1 - 31) *',
                hintText: '1',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.calendar_today_rounded),
              ),
            ),
            const SizedBox(height: 16),

            // Is locked from salary switch
            SwitchListTile(
              value: _isLockedFromSalary,
              onChanged: (val) => setState(() => _isLockedFromSalary = val),
              title: const Text('حجز المخصص تلقائياً من الراتب'),
              subtitle: const Text('لحماية المبلغ من الصرف العشوائي قبل موعد الاستحقاق'),
              activeColor: AppColors.forestGreen,
            ),
            const SizedBox(height: 20),

            if (_error != null) ...[
              Text(
                _error!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
            ],

            LuxuryButton(
              label: 'حفظ الالتزام',
              icon: Icons.check_circle_outline,
              onPressed: _submit,
            ),
          ],
        ),
      ),
    );
  }
}

