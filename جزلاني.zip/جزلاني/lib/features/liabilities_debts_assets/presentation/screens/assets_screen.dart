import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/asset_entity.dart';
import '../application/liabilities_debts_assets_controller.dart';
import '../widgets/asset_card.dart';
import 'add_asset_screen.dart';

/// شاشة الأصول الرأسمالية والممتلكات
class AssetsScreen extends ConsumerWidget {
  const AssetsScreen({super.key});

  void _showRevaluationDialog(BuildContext context, WidgetRef ref, AssetEntity asset) {
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final valueController = TextEditingController(text: asset.currentMarketValue.toMajorUnits().toStringAsFixed(2));
    final reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('إعادة تقييم الأصل', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('الأصل: ${asset.title}', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
            Text('التقييم الحالي: ${asset.currentMarketValue.formatArabic()}', style: AppTypography.bodySecondary),
            const SizedBox(height: 12),
            TextField(
              controller: valueController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'القيمة السوقية الجديدة (ر.س) *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reasonController,
              decoration: InputDecoration(
                labelText: 'سبب إعادة التقييم (اختياري)',
                hintText: 'مثال: تقييم عقاري، ارتفاع سعر السوق...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final newAmount = Money.parse(valueController.text.trim());
                await controller.revaluateAsset(
                  assetId: asset.id,
                  newMarketValue: newAmount,
                  reason: reasonController.text.trim().isEmpty ? null : reasonController.text.trim(),
                );
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: const Text('حفظ التقييم'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الأصول الرأسمالية'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddAssetScreen()),
          );
        },
        backgroundColor: AppColors.forestGreen,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'إضافة أصل',
          style: AppTypography.bodyPrimary.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Total Assets Header Card
              LuxuryCard(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text('إجمالي القيمة السوقية للأصول', style: AppTypography.bodySecondary),
                    const SizedBox(height: 6),
                    Text(
                      state.totalCapitalAssets.formatArabic(),
                      style: AppTypography.displayLarge.copyWith(
                        color: AppColors.forestGreen,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${state.assets.length} أصول مسجلة ومعتمدة',
                      style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (state.assets.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(32),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.real_estate_agent_outlined,
                          size: 40,
                          color: AppColors.slateMuted.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لم يتم تسجيل أي أصول رأسمالية حتى الآن',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.assets.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = state.assets[index];
                    return AssetCard(
                      asset: item,
                      onRevaluate: () => _showRevaluationDialog(context, ref, item),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

