import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/debt_entity.dart';
import '../application/liabilities_debts_assets_controller.dart';
import '../widgets/debt_card.dart';
import 'add_debt_screen.dart';
import 'debt_detail_screen.dart';

/// شاشة إدارة الديون والأقساط
class DebtsScreen extends ConsumerStatefulWidget {
  const DebtsScreen({super.key});

  @override
  ConsumerState<DebtsScreen> createState() => _DebtsScreenState();
}

class _DebtsScreenState extends ConsumerState<DebtsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showInstallmentDialog(BuildContext context, DebtEntity debt) {
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);
    final defaultAmount = debt.monthlyInstallmentAmount ?? debt.remainingAmount;
    final amountController = TextEditingController(text: defaultAmount.toMajorUnits().toStringAsFixed(2));
    final noteController = TextEditingController();

    final isPayable = debt.type == DebtType.payable;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(isPayable ? 'سداد دفعة دين' : 'تحصيل دفعة دين', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('الدين: ${debt.title}', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
            Text('الطرف: ${debt.counterpartyName}', style: AppTypography.bodySecondary),
            Text('المتبقي: ${debt.remainingAmount.formatArabic()}', style: AppTypography.bodySecondary),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'مبلغ الدفعة (ر.س) *',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: isPayable ? AppColors.forestGreen : AppColors.cashIn,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final amt = Money.parse(amountController.text.trim());
                final idpKey = 'debt_pay_${DateTime.now().millisecondsSinceEpoch}';
                await controller.payDebtInstallment(
                  debtId: debt.id,
                  accountId: 'acc_main',
                  amount: amt,
                  paymentDate: DateTime.now(),
                  note: noteController.text.trim().isEmpty ? null : noteController.text.trim(),
                  idempotencyKey: idpKey,
                );
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: Text(isPayable ? 'تأكيد السداد' : 'تأكيد التحصيل'),
          ),
        ],
      ),
    );
  }

  List<DebtEntity> _filterDebts(List<DebtEntity> debts, int tabIndex) {
    switch (tabIndex) {
      case 0: // ديون عليّ
        return debts.where((d) => d.type == DebtType.payable && d.status == DebtStatus.active).toList();
      case 1: // ديون لي
        return debts.where((d) => d.type == DebtType.receivable && d.status == DebtStatus.active).toList();
      case 2: // المسددة
        return debts.where((d) => d.status == DebtStatus.settled).toList();
      default:
        return debts;
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final controller = ref.read(liabilitiesDebtsAssetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الديون والأقساط'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.forestGreen,
          unselectedLabelColor: AppColors.slateMuted,
          indicatorColor: AppColors.forestGreen,
          onTap: (_) => setState(() {}),
          tabs: const [
            Tab(text: 'ديون عليّ (التزام)'),
            Tab(text: 'ديون لي (مستحق)'),
            Tab(text: 'المسددة'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddDebtScreen()),
          );
        },
        backgroundColor: AppColors.forestGreen,
        icon: const Icon(Icons.add, color: Colors.white),
        label: Text(
          'تسجيل دين',
          style: AppTypography.bodyPrimary.copyWith(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Summary cards
              Row(
                children: [
                  Expanded(
                    child: LuxuryCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('مستحق عليّ (خصوم)', style: AppTypography.bodySecondary.copyWith(fontSize: 11)),
                          const SizedBox(height: 4),
                          Text(
                            state.totalPayableDebtsRemaining.formatArabic(),
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: AppColors.cashOut,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: LuxuryCard(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('مستحق لي (أصول)', style: AppTypography.bodySecondary.copyWith(fontSize: 11)),
                          const SizedBox(height: 4),
                          Text(
                            state.totalReceivableDebtsRemaining.formatArabic(),
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: AppColors.cashIn,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              Builder(
                builder: (context) {
                  final filtered = _filterDebts(state.debts, _tabController.index);

                  if (filtered.isEmpty) {
                    return LuxuryCard(
                      padding: const EdgeInsets.all(32),
                      child: Center(
                        child: Text(
                          'لا توجد ديون في هذا القسم حالياً',
                          style: AppTypography.bodySecondary,
                        ),
                      ),
                    );
                  }

                  return ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final item = filtered[index];
                      return DebtCard(
                        debt: item,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DebtDetailScreen(debtId: item.id),
                            ),
                          );
                        },
                        onPayInstallment: () => _showInstallmentDialog(context, item),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

