import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/debt_entity.dart';
import '../application/liabilities_debts_assets_controller.dart';

/// شاشة تفاصيل الدين وسجل الأقساط والمدفوعات
class DebtDetailScreen extends ConsumerWidget {
  final String debtId;

  const DebtDetailScreen({super.key, required this.debtId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(liabilitiesDebtsAssetsControllerProvider);
    final debt = state.debts.where((d) => d.id == debtId).firstOrNull;

    if (debt == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('تفاصيل الدين')),
        body: const Center(child: Text('الدين غير موجود')),
      );
    }

    final isPayable = debt.type == DebtType.payable;
    final isSettled = debt.status == DebtStatus.settled;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: Text(debt.title),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LuxuryCard(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('الطرف: ${debt.counterpartyName}', style: AppTypography.headingH3),
                      StatusBadge(
                        text: isSettled ? 'تم السداد' : debt.type.labelArabic,
                        color: isPayable
                            ? AppColors.cashOut.withValues(alpha: 0.12)
                            : AppColors.cashIn.withValues(alpha: 0.12),
                        textColor: isPayable ? AppColors.cashOut : AppColors.cashIn,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('المتبقي للسداد', style: AppTypography.bodySecondary),
                          const SizedBox(height: 4),
                          Text(
                            debt.remainingAmount.formatArabic(),
                            style: AppTypography.displayLarge.copyWith(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: isSettled ? AppColors.forestGreen : AppColors.cashOut,
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('المبلغ الإجمالي', style: AppTypography.bodySecondary),
                          const SizedBox(height: 4),
                          Text(
                            debt.totalAmount.formatArabic(),
                            style: AppTypography.headingH2.copyWith(fontSize: 20),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: (debt.progressPercentage / 100.0).clamp(0.0, 1.0),
                      minHeight: 10,
                      backgroundColor: AppColors.surfaceSubtleLight,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        isSettled ? AppColors.forestGreen : AppColors.champagneGold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'نسبة المسدد: ${debt.progressPercentage.toStringAsFixed(1)}%',
                        style: AppTypography.bodySecondary.copyWith(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'المسدد فعلياً: ${debt.paidAmount.formatArabic()}',
                        style: AppTypography.bodySecondary.copyWith(color: AppColors.cashIn),
                      ),
                    ],
                  ),
                  if (debt.monthlyInstallmentAmount != null) ...[
                    const Divider(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('القسط الشهري المتفق عليه:', style: AppTypography.bodySecondary),
                        Text(
                          debt.monthlyInstallmentAmount!.formatArabic(),
                          style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

