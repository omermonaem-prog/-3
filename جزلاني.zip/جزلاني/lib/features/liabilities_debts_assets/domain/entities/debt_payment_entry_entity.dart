import '../../../../core/finance/money.dart';

/// سجل دفعة قسط دين مالي (Debt Payment Entry Entity)
class DebtPaymentEntryEntity {
  final String id;
  final String debtId;
  final String accountId;
  final String? accountName;
  final Money amount;
  final DateTime paymentDate;
  final String? note;
  final String idempotencyKey;

  const DebtPaymentEntryEntity({
    required this.id,
    required this.debtId,
    required this.accountId,
    this.accountName,
    required this.amount,
    required this.paymentDate,
    this.note,
    required this.idempotencyKey,
  });
}

