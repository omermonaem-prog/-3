import '../../../../core/finance/money.dart';

enum ObligationRecurrence {
  monthly,
  quarterly,
  yearly,
  weekly,
  oneTime;

  String get labelArabic {
    switch (this) {
      case ObligationRecurrence.monthly:
        return 'شهري';
      case ObligationRecurrence.quarterly:
        return 'ربع سنوي';
      case ObligationRecurrence.yearly:
        return 'سنوي';
      case ObligationRecurrence.weekly:
        return 'أسبوعي';
      case ObligationRecurrence.oneTime:
        return 'دفعة واحدة';
    }
  }

  static ObligationRecurrence fromString(String val) {
    switch (val.toLowerCase()) {
      case 'monthly':
        return ObligationRecurrence.monthly;
      case 'quarterly':
        return ObligationRecurrence.quarterly;
      case 'yearly':
        return ObligationRecurrence.yearly;
      case 'weekly':
        return ObligationRecurrence.weekly;
      case 'onetime':
      case 'one_time':
        return ObligationRecurrence.oneTime;
      default:
        return ObligationRecurrence.monthly;
    }
  }
}

/// كيان الالتزام المالي / الفاتورة / الاشتراك (Financial Obligation / Recurring Commitment)
class ObligationEntity {
  final String id;
  final String title;
  final String? billerName;
  final Money amount;
  final ObligationRecurrence recurrenceType;
  final int dueDayOfMonth;
  final DateTime? dueDate;
  final String? linkedAccountId;
  final bool isLockedFromSalary;
  final bool isActive;
  final DateTime createdAt;

  const ObligationEntity({
    required this.id,
    required this.title,
    this.billerName,
    required this.amount,
    this.recurrenceType = ObligationRecurrence.monthly,
    this.dueDayOfMonth = 1,
    this.dueDate,
    this.linkedAccountId,
    this.isLockedFromSalary = true,
    this.isActive = true,
    required this.createdAt,
  });

  /// فحص ما إذا كان الالتزام متأخراً عن السداد لهذا الشهر
  bool get isOverdue {
    if (!isActive) return false;
    final now = DateTime.now();
    if (dueDate != null) {
      return now.isAfter(dueDate!);
    }
    return now.day > dueDayOfMonth;
  }

  /// تاريخ الاستحقاق القادم
  DateTime get nextDueDate {
    final now = DateTime.now();
    if (dueDate != null) return dueDate!;
    if (now.day <= dueDayOfMonth) {
      return DateTime(now.year, now.month, dueDayOfMonth);
    } else {
      final nextMonth = now.month == 12 ? 1 : now.month + 1;
      final nextYear = now.month == 12 ? now.year + 1 : now.year;
      return DateTime(nextYear, nextMonth, dueDayOfMonth);
    }
  }

  ObligationEntity copyWith({
    String? id,
    String? title,
    String? billerName,
    Money? amount,
    ObligationRecurrence? recurrenceType,
    int? dueDayOfMonth,
    DateTime? dueDate,
    String? linkedAccountId,
    bool? isLockedFromSalary,
    bool? isActive,
    DateTime? createdAt,
  }) {
    return ObligationEntity(
      id: id ?? this.id,
      title: title ?? this.title,
      billerName: billerName ?? this.billerName,
      amount: amount ?? this.amount,
      recurrenceType: recurrenceType ?? this.recurrenceType,
      dueDayOfMonth: dueDayOfMonth ?? this.dueDayOfMonth,
      dueDate: dueDate ?? this.dueDate,
      linkedAccountId: linkedAccountId ?? this.linkedAccountId,
      isLockedFromSalary: isLockedFromSalary ?? this.isLockedFromSalary,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

