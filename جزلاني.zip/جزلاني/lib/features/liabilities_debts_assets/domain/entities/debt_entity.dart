import '../../../../core/finance/money.dart';

enum DebtType {
  payable, // دين عليّ (مستحق على المستخدم للغير)
  receivable; // دين لي (مستحق للمستخدم على الغير)

  String get labelArabic {
    switch (this) {
      case DebtType.payable:
        return 'دين عليّ (التزام)';
      case DebtType.receivable:
        return 'دين لي (مستحق)';
    }
  }

  static DebtType fromString(String val) {
    switch (val.toLowerCase()) {
      case 'payable':
        return DebtType.payable;
      case 'receivable':
        return DebtType.receivable;
      default:
        return DebtType.payable;
    }
  }
}

enum DebtStatus {
  active,
  settled;

  String get labelArabic {
    switch (this) {
      case DebtStatus.active:
        return 'قيد السداد';
      case DebtStatus.settled:
        return 'تم السداد بالكامل';
    }
  }

  static DebtStatus fromString(String val) {
    switch (val.toLowerCase()) {
      case 'active':
        return DebtStatus.active;
      case 'settled':
        return DebtStatus.settled;
      default:
        return DebtStatus.active;
    }
  }
}

/// كيان الدين / القسط المالي (Debt & Loan Entity)
class DebtEntity {
  final String id;
  final String title;
  final String counterpartyName; // اسم الدائن أو المدين
  final DebtType type;
  final Money totalAmount;
  final Money remainingAmount;
  final Money? monthlyInstallmentAmount;
  final DateTime startDate;
  final DateTime? dueDate;
  final DebtStatus status;

  const DebtEntity({
    required this.id,
    required this.title,
    required this.counterpartyName,
    required this.type,
    required this.totalAmount,
    required this.remainingAmount,
    this.monthlyInstallmentAmount,
    required this.startDate,
    this.dueDate,
    this.status = DebtStatus.active,
  });

  /// المبلغ المسدد حتى الآن: Total - Remaining
  Money get paidAmount {
    if (remainingAmount >= totalAmount) return const Money.zero();
    return totalAmount - remainingAmount;
  }

  /// نسبة السداد المئوية
  double get progressPercentage {
    if (totalAmount.minorUnits <= 0) return 100.0;
    final paid = paidAmount.minorUnits;
    final p = (paid / totalAmount.minorUnits) * 100.0;
    return p.clamp(0.0, 100.0);
  }

  /// هل تم السداد بالكامل
  bool get isFullyPaid => remainingAmount.isZero || remainingAmount.minorUnits <= 0;

  DebtEntity copyWith({
    String? id,
    String? title,
    String? counterpartyName,
    DebtType? type,
    Money? totalAmount,
    Money? remainingAmount,
    Money? monthlyInstallmentAmount,
    DateTime? startDate,
    DateTime? dueDate,
    DebtStatus? status,
  }) {
    return DebtEntity(
      id: id ?? this.id,
      title: title ?? this.title,
      counterpartyName: counterpartyName ?? this.counterpartyName,
      type: type ?? this.type,
      totalAmount: totalAmount ?? this.totalAmount,
      remainingAmount: remainingAmount ?? this.remainingAmount,
      monthlyInstallmentAmount: monthlyInstallmentAmount ?? this.monthlyInstallmentAmount,
      startDate: startDate ?? this.startDate,
      dueDate: dueDate ?? this.dueDate,
      status: status ?? this.status,
    );
  }
}

