import '../../../../core/finance/money.dart';

/// سجل تاريخ تقييمات الأصل الرأسمالي (Asset Valuation History)
class AssetValuationHistory {
  final String id;
  final String assetId;
  final DateTime valuationDate;
  final Money marketValue;
  final Money previousMarketValue;
  final String? reason;

  const AssetValuationHistory({
    required this.id,
    required this.assetId,
    required this.valuationDate,
    required this.marketValue,
    required this.previousMarketValue,
    this.reason,
  });

  Money get difference => marketValue - previousMarketValue;
}

