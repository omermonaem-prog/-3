import 'package:drift/drift.dart';
import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import '../domain/entities/asset_entity.dart';
import '../domain/entities/asset_valuation_history.dart';
import '../domain/entities/debt_entity.dart';
import '../domain/entities/debt_payment_entry_entity.dart';
import '../domain/entities/net_worth_snapshot.dart';
import '../domain/entities/obligation_entity.dart';
import '../domain/entities/obligation_payment_entity.dart';
import '../domain/repositories/liabilities_debts_assets_repository.dart';

/// تطبيق مستودع الالتزامات والديون والأصول بالاعتماد على قاعدة البيانات المحلية
class LiabilitiesDebtsAssetsRepositoryImpl
    implements LiabilitiesDebtsAssetsRepository {
  final AppDatabase _db;

  // ذاكرة تخزين مؤقتة للمدفوعات وسجل التقييمات وصافي الثروة
  final Map<String, ObligationEntity> _cachedObligations = {};
  final List<ObligationPaymentEntity> _cachedObligationPayments = [];
  final Map<String, DebtEntity> _cachedDebts = {};
  final List<DebtPaymentEntryEntity> _cachedDebtPayments = [];
  final Map<String, AssetEntity> _cachedAssets = {};
  final List<AssetValuationHistory> _cachedValuations = [];
  final List<NetWorthSnapshot> _cachedNetWorth = [];

  LiabilitiesDebtsAssetsRepositoryImpl(this._db);

  // ── الالتزامات ───────────────────────────────────────────────

  @override
  Future<List<ObligationEntity>> getAllObligations() async {
    final list = _cachedObligations.values.toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<ObligationEntity?> getObligationById(String id) async =>
      _cachedObligations[id];

  @override
  Future<void> saveObligation(ObligationEntity obligation) async {
    _cachedObligations[obligation.id] = obligation;
    await _db.obligationsDao.insertObligation(ObligationsCompanion.insert(
      id: obligation.id,
      title: obligation.title,
      billerName: Value(obligation.billerName),
      amountMinorUnits: obligation.amount.minorUnits,
      recurrenceType: obligation.recurrenceType.name,
      dueDayOfMonth: obligation.dueDayOfMonth,
      linkedAccountId: Value(obligation.linkedAccountId),
      isLockedFromSalary: Value(obligation.isLockedFromSalary),
      isActive: Value(obligation.isActive),
      createdAt: obligation.createdAt,
    ));
  }

  @override
  Future<void> updateObligation(ObligationEntity obligation) async {
    _cachedObligations[obligation.id] = obligation;
  }

  @override
  Future<void> deactivateObligation(String id) async {
    final o = _cachedObligations[id];
    if (o != null) {
      _cachedObligations[id] = o.copyWith(isActive: false);
    }
    await _db.obligationsDao.deactivateObligation(id);
  }

  @override
  Future<void> recordObligationPayment(ObligationPaymentEntity payment) async {
    _cachedObligationPayments.add(payment);
  }

  @override
  Future<List<ObligationPaymentEntity>> getPaymentsForObligation(
      String obligationId) async {
    final list = _cachedObligationPayments
        .where((p) => p.obligationId == obligationId)
        .toList();
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  @override
  Future<List<ObligationPaymentEntity>> getAllObligationPayments() async {
    final list = List<ObligationPaymentEntity>.from(_cachedObligationPayments);
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  // ── الديون ───────────────────────────────────────────────────

  @override
  Future<List<DebtEntity>> getAllDebts() async {
    final list = _cachedDebts.values.toList();
    list.sort((a, b) => b.startDate.compareTo(a.startDate));
    return list;
  }

  @override
  Future<DebtEntity?> getDebtById(String id) async => _cachedDebts[id];

  @override
  Future<void> saveDebt(DebtEntity debt) async {
    _cachedDebts[debt.id] = debt;
    await _db.debtsDao.insertDebt(DebtsCompanion.insert(
      id: debt.id,
      title: debt.title,
      counterpartyName: debt.counterpartyName,
      type: debt.type.name,
      totalMinorUnits: debt.totalAmount.minorUnits,
      remainingMinorUnits: debt.remainingAmount.minorUnits,
      monthlyInstallmentMinorUnits:
          Value(debt.monthlyInstallmentAmount?.minorUnits),
      startDate: debt.startDate,
      dueDate: Value(debt.dueDate),
      status: Value(debt.status.name),
    ));
  }

  @override
  Future<void> updateDebt(DebtEntity debt) async {
    _cachedDebts[debt.id] = debt;
  }

  @override
  Future<void> recordDebtPayment(DebtPaymentEntryEntity payment) async {
    _cachedDebtPayments.add(payment);
    final debt = _cachedDebts[payment.debtId];
    if (debt != null) {
      final newRemaining = (debt.remainingAmount - payment.amount).minorUnits <= 0
          ? debt.remainingAmount - debt.remainingAmount
          : debt.remainingAmount - payment.amount;
      final isSettled = newRemaining.isZero;
      _cachedDebts[payment.debtId] = debt.copyWith(
        remainingAmount: newRemaining,
        status: isSettled ? DebtStatus.settled : DebtStatus.active,
      );
    }

    await _db.debtsDao.applyPayment(payment.debtId, payment.amount.minorUnits);
    await _db.debtsDao.insertDebtPayment(DebtPaymentsCompanion.insert(
      id: payment.id,
      debtId: payment.debtId,
      accountId: payment.accountId,
      amountMinorUnits: payment.amount.minorUnits,
      paymentDate: payment.paymentDate,
      note: Value(payment.note),
    ));
  }

  @override
  Future<List<DebtPaymentEntryEntity>> getPaymentsForDebt(String debtId) async {
    final list =
        _cachedDebtPayments.where((p) => p.debtId == debtId).toList();
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  // ── الأصول ───────────────────────────────────────────────────

  @override
  Future<List<AssetEntity>> getAllAssets() async {
    final list = _cachedAssets.values.toList();
    list.sort((a, b) => b.purchaseDate.compareTo(a.purchaseDate));
    return list;
  }

  @override
  Future<AssetEntity?> getAssetById(String id) async => _cachedAssets[id];

  @override
  Future<void> saveAsset(AssetEntity asset) async {
    _cachedAssets[asset.id] = asset;
    await _db.assetsDao.insertAsset(AssetsCompanion.insert(
      id: asset.id,
      title: asset.title,
      category: asset.category.name,
      purchaseCostMinorUnits: asset.purchaseCost.minorUnits,
      currentMarketValueMinorUnits: asset.currentMarketValue.minorUnits,
      purchaseDate: asset.purchaseDate,
      lastValuationDate: asset.lastValuationDate,
      notes: Value(asset.notes),
    ));
  }

  @override
  Future<void> updateAsset(AssetEntity asset) async {
    _cachedAssets[asset.id] = asset;
    await _db.assetsDao.revaluateAsset(
      asset.id,
      asset.currentMarketValue.minorUnits,
    );
  }

  @override
  Future<void> recordValuationHistory(AssetValuationHistory history) async {
    _cachedValuations.add(history);
  }

  @override
  Future<List<AssetValuationHistory>> getValuationHistoryForAsset(
      String assetId) async {
    final list = _cachedValuations.where((v) => v.assetId == assetId).toList();
    list.sort((a, b) => b.valuationDate.compareTo(a.valuationDate));
    return list;
  }

  // ── صافي الثروة ───────────────────────────────────────────────

  @override
  Future<void> saveNetWorthSnapshot(NetWorthSnapshot snapshot) async {
    _cachedNetWorth.add(snapshot);
  }

  @override
  Future<List<NetWorthSnapshot>> getNetWorthHistory() async {
    final list = List<NetWorthSnapshot>.from(_cachedNetWorth);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }
}

