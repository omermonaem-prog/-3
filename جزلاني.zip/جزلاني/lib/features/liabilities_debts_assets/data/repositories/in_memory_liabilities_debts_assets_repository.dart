import '../domain/entities/asset_entity.dart';
import '../domain/entities/asset_valuation_history.dart';
import '../domain/entities/debt_entity.dart';
import '../domain/entities/debt_payment_entry_entity.dart';
import '../domain/entities/net_worth_snapshot.dart';
import '../domain/entities/obligation_entity.dart';
import '../domain/entities/obligation_payment_entity.dart';
import '../domain/repositories/liabilities_debts_assets_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع الالتزامات والديون والأصول
class InMemoryLiabilitiesDebtsAssetsRepository
    implements LiabilitiesDebtsAssetsRepository {
  final Map<String, ObligationEntity> obligations = {};
  final List<ObligationPaymentEntity> obligationPayments = [];

  final Map<String, DebtEntity> debts = {};
  final List<DebtPaymentEntryEntity> debtPayments = [];

  final Map<String, AssetEntity> assets = {};
  final List<AssetValuationHistory> valuationHistories = [];

  final List<NetWorthSnapshot> netWorthSnapshots = [];

  // ── الالتزامات ───────────────────────────────────────────────

  @override
  Future<List<ObligationEntity>> getAllObligations() async {
    final list = obligations.values.toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  @override
  Future<ObligationEntity?> getObligationById(String id) async =>
      obligations[id];

  @override
  Future<void> saveObligation(ObligationEntity obligation) async {
    obligations[obligation.id] = obligation;
  }

  @override
  Future<void> updateObligation(ObligationEntity obligation) async {
    obligations[obligation.id] = obligation;
  }

  @override
  Future<void> deactivateObligation(String id) async {
    final o = obligations[id];
    if (o != null) {
      obligations[id] = o.copyWith(isActive: false);
    }
  }

  @override
  Future<void> recordObligationPayment(ObligationPaymentEntity payment) async {
    obligationPayments.add(payment);
  }

  @override
  Future<List<ObligationPaymentEntity>> getPaymentsForObligation(
      String obligationId) async {
    final list =
        obligationPayments.where((p) => p.obligationId == obligationId).toList();
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  @override
  Future<List<ObligationPaymentEntity>> getAllObligationPayments() async {
    final list = List<ObligationPaymentEntity>.from(obligationPayments);
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  // ── الديون ───────────────────────────────────────────────────

  @override
  Future<List<DebtEntity>> getAllDebts() async {
    final list = debts.values.toList();
    list.sort((a, b) => b.startDate.compareTo(a.startDate));
    return list;
  }

  @override
  Future<DebtEntity?> getDebtById(String id) async => debts[id];

  @override
  Future<void> saveDebt(DebtEntity debt) async {
    debts[debt.id] = debt;
  }

  @override
  Future<void> updateDebt(DebtEntity debt) async {
    debts[debt.id] = debt;
  }

  @override
  Future<void> recordDebtPayment(DebtPaymentEntryEntity payment) async {
    debtPayments.add(payment);
    final debt = debts[payment.debtId];
    if (debt != null) {
      final newRemaining = (debt.remainingAmount - payment.amount).minorUnits <= 0
          ? debt.remainingAmount - debt.remainingAmount
          : debt.remainingAmount - payment.amount;
      final isSettled = newRemaining.isZero;
      debts[payment.debtId] = debt.copyWith(
        remainingAmount: newRemaining,
        status: isSettled ? DebtStatus.settled : DebtStatus.active,
      );
    }
  }

  @override
  Future<List<DebtPaymentEntryEntity>> getPaymentsForDebt(String debtId) async {
    final list = debtPayments.where((p) => p.debtId == debtId).toList();
    list.sort((a, b) => b.paymentDate.compareTo(a.paymentDate));
    return list;
  }

  // ── الأصول ───────────────────────────────────────────────────

  @override
  Future<List<AssetEntity>> getAllAssets() async {
    final list = assets.values.toList();
    list.sort((a, b) => b.purchaseDate.compareTo(a.purchaseDate));
    return list;
  }

  @override
  Future<AssetEntity?> getAssetById(String id) async => assets[id];

  @override
  Future<void> saveAsset(AssetEntity asset) async {
    assets[asset.id] = asset;
  }

  @override
  Future<void> updateAsset(AssetEntity asset) async {
    assets[asset.id] = asset;
  }

  @override
  Future<void> recordValuationHistory(AssetValuationHistory history) async {
    valuationHistories.add(history);
  }

  @override
  Future<List<AssetValuationHistory>> getValuationHistoryForAsset(
      String assetId) async {
    final list =
        valuationHistories.where((h) => h.assetId == assetId).toList();
    list.sort((a, b) => b.valuationDate.compareTo(a.valuationDate));
    return list;
  }

  // ── صافي الثروة ───────────────────────────────────────────────

  @override
  Future<void> saveNetWorthSnapshot(NetWorthSnapshot snapshot) async {
    netWorthSnapshots.add(snapshot);
  }

  @override
  Future<List<NetWorthSnapshot>> getNetWorthHistory() async {
    final list = List<NetWorthSnapshot>.from(netWorthSnapshots);
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }
}

