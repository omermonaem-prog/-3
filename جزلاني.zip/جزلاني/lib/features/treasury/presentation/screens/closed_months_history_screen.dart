import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/treasury_controller.dart';
import '../domain/entities/closed_month_record.dart';

/// شاشة سجل الأشهر المغلقة وتفاصيل قرارات الفائض السابقة
class ClosedMonthsHistoryScreen extends ConsumerWidget {
  const ClosedMonthsHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(treasuryControllerProvider);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('أرشيف الأشهر المغلقة'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: state.closedMonths.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.archive_outlined, size: 48, color: AppColors.slateMuted),
                  const SizedBox(height: 12),
                  Text('لا توجد أشهر مغلقة حتى الآن', style: AppTypography.headingH3),
                  const SizedBox(height: 4),
                  Text(
                    'تظهر هنا السجلات المحاسبية والقرارات التي تم اتخاذها عند إغلاق نهاية كل شهر',
                    style: AppTypography.bodySecondary,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: state.closedMonths.length,
              separatorBuilder: (context, index) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final record = state.closedMonths[index];
                return _buildClosedMonthCard(context, record);
              },
            ),
    );
  }

  Widget _buildClosedMonthCard(BuildContext context, ClosedMonthRecord record) {
    final closedDateStr =
        '${record.closedAt.year}/${record.closedAt.month}/${record.closedAt.day}';

    return LuxuryCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.lock, color: AppColors.forestGreen, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'شهر ${record.periodYearMonth}',
                    style: AppTypography.headingH2.copyWith(fontSize: 18),
                  ),
                ],
              ),
              Text(
                'أغلق في: $closedDateStr',
                style: AppTypography.bodySecondary.copyWith(fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'الدخل: +${record.totalIncome.formatArabic()}',
                style: const TextStyle(color: AppColors.cashIn, fontWeight: FontWeight.w600),
              ),
              Text(
                'المصروف: -${record.totalExpenses.formatArabic()}',
                style: const TextStyle(color: AppColors.cashOut, fontWeight: FontWeight.w600),
              ),
              Text(
                'الفائض: ${record.totalSurplus.formatArabic()}',
                style: const TextStyle(color: AppColors.forestGreen, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(),
          const SizedBox(height: 8),
          Text('القرارات المتخذة للفائض:', style: AppTypography.bodySecondary.copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          ...record.decisions.map((d) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    const Icon(Icons.check, size: 14, color: AppColors.forestGreen),
                    const SizedBox(width: 6),
                    Text('${d.categoryName} (${d.surplusAmount.formatArabic()}): ',
                        style: AppTypography.bodySecondary.copyWith(fontWeight: FontWeight.w600)),
                    Text(d.action.labelArabic,
                        style: AppTypography.bodySecondary.copyWith(color: AppColors.forestGreen)),
                  ],
                ),
              )),
          if (record.notes != null) ...[
            const SizedBox(height: 8),
            Text('ملاحظات: ${record.notes}', style: AppTypography.bodySecondary.copyWith(fontSize: 12)),
          ],
        ],
      ),
    );
  }
}

