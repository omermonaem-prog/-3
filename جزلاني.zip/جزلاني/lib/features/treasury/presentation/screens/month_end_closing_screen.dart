import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/treasury_controller.dart';
import '../presentation/widgets/surplus_decision_card.dart';

/// شاشة إغلاق الشهر المالي وتحديد مصير الفائض (Month-End Closing Screen)
class MonthEndClosingScreen extends ConsumerStatefulWidget {
  final String periodYearMonth;

  const MonthEndClosingScreen({
    super.key,
    required this.periodYearMonth,
  });

  @override
  ConsumerState<MonthEndClosingScreen> createState() =>
      _MonthEndClosingScreenState();
}

class _MonthEndClosingScreenState extends ConsumerState<MonthEndClosingScreen> {
  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref
          .read(treasuryControllerProvider.notifier)
          .loadMonthEndSummary(widget.periodYearMonth);
    });
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  void _onConfirmClosing() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.lock_outline, color: AppColors.forestGreen),
            const SizedBox(width: 8),
            Text('تأكيد إغلاق شهر ${widget.periodYearMonth}', style: AppTypography.headingH3),
          ],
        ),
        content: Text(
          'سيتم أرشفة الشهر المالي رسمياً وتنفيذ كافة قرارات الفائض التي حددتها (ترحيل، ادخار، طوارئ، أهداف). لا يمكن التراجع عن الإغلاق تلقائياً.',
          style: AppTypography.bodyPrimary,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('مراجعة'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.forestGreen),
            onPressed: () async {
              Navigator.pop(ctx);
              final key = 'close_${widget.periodYearMonth}_${DateTime.now().millisecondsSinceEpoch}';
              final success = await ref
                  .read(treasuryControllerProvider.notifier)
                  .confirmAndExecuteMonthEndClosing(
                    periodYearMonth: widget.periodYearMonth,
                    notes: _notesController.text.trim().isEmpty
                        ? null
                        : _notesController.text.trim(),
                    idempotencyKey: key,
                  );

              if (mounted && success) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('تم إغلاق شهر ${widget.periodYearMonth} بنجاح'),
                    backgroundColor: AppColors.forestGreen,
                  ),
                );
                Navigator.pop(context);
              }
            },
            child: const Text('تأكيد الإغلاق النهائي'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(treasuryControllerProvider);
    final controller = ref.read(treasuryControllerProvider.notifier);
    final summary = state.activeMonthSummary;

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: Text('إغلاق شهر ${widget.periodYearMonth}'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: state.isLoading || summary == null
        ? const Center(child: CircularProgressIndicator(color: AppColors.forestGreen))
        : SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. بطاقة ملخص الشهر
                LuxuryCard(
                  backgroundColor: AppColors.forestGreen,
                  borderColor: AppColors.champagneGold,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'صافي الفائض التشغيلي للشهر',
                        style: AppTypography.bodySecondary.copyWith(
                          color: AppColors.canvasLight.withValues(alpha: 0.8),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        summary.totalSurplus.formatArabic(),
                        style: AppTypography.displayLarge.copyWith(
                          color: AppColors.champagneGoldBright,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 14),
                      const Divider(color: AppColors.champagneGold, height: 1),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'الدخل: +${summary.totalIncome.formatArabic()}',
                            style: const TextStyle(color: Colors.white, fontSize: 13),
                          ),
                          Text(
                            'المصروف: -${summary.totalExpenses.formatArabic()}',
                            style: const TextStyle(color: AppColors.champagneGoldBright, fontSize: 13),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // 2. قائمة الميزانيات ذات الفائض لاتخاذ القرار اليدوي
                Text('تحديد مصير الفائض لكل ميزانية', style: AppTypography.headingH2),
                const SizedBox(height: 4),
                Text(
                  'حدد يدوياً أين تريد توجيه المبلغ المتبقي لكل قسم. لن يتم أي إجراء تلقائياً.',
                  style: AppTypography.bodySecondary,
                ),
                const SizedBox(height: 14),

                if (summary.budgetSurpluses.isEmpty)
                  LuxuryCard(
                    padding: const EdgeInsets.all(20),
                    child: Center(
                      child: Text(
                        'لا توجد فوائض في ميزانيات هذا الشهر (تم استهلاكها بالكامل أو لم تُنشأ)',
                        style: AppTypography.bodySecondary,
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                else
                  ...summary.budgetSurpluses.map((s) {
                    final currentDecision = state.userDecisions[s.categoryId] ?? s;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: SurplusDecisionCard(
                        decision: currentDecision,
                        onDecisionChanged: (newDec) => controller.updateSurplusDecision(newDec),
                      ),
                    );
                  }),

                const SizedBox(height: 14),

                // حقل ملاحظات إغلاق الشهر
                TextField(
                  controller: _notesController,
                  decoration: InputDecoration(
                    labelText: 'ملاحظات الإغلاق السنوي/الشهري (اختياري)',
                    filled: true,
                    fillColor: AppColors.surfaceLight,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: AppColors.borderSubtleLight),
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // أزرار الإجراءات (إلغاء، تأكيد)
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: state.isClosingMonth ? null : () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                        child: Text('إلغاء دون إغلاق', style: AppTypography.bodyPrimary),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: LuxuryButton(
                        label: 'تأكيد واعتماد الإغلاق',
                        icon: Icons.check_circle_outline,
                        isLoading: state.isClosingMonth,
                        onPressed: summary.isClosed ? null : _onConfirmClosing,
                        type: LuxuryButtonType.primary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
    );
  }
}

