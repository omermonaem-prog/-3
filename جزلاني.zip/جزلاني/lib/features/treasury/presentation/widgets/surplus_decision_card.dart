import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../domain/entities/surplus_action.dart';
import '../domain/entities/surplus_decision.dart';

/// بطاقة اتخاذ القرار لمصير فائض ميزانية محددة عند إغلاق الشهر
class SurplusDecisionCard extends StatelessWidget {
  final SurplusDecision decision;
  final ValueChanged<SurplusDecision> onDecisionChanged;

  const SurplusDecisionCard({
    super.key,
    required this.decision,
    required this.onDecisionChanged,
  });

  @override
  Widget build(BuildContext context) {
    return LuxuryCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // رأس البطاقة: اسم التصنيف ومبلغ الفائض
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                decision.categoryName,
                style: AppTypography.headingH3.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.cashIn.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'فائض: ${decision.surplusAmount.formatArabic()}',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.cashIn,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // قائمة الخيارات الخمسة لمصير الفائض
          Text(
            'اختر مصير هذا الفائض:',
            style: AppTypography.bodySecondary.copyWith(
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 8),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppColors.surfaceSubtleLight,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.borderSubtleLight),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<SurplusAction>(
                value: decision.action,
                isExpanded: true,
                items: SurplusAction.values.map((action) {
                  return DropdownMenuItem(
                    value: action,
                    child: Row(
                      children: [
                        Icon(action.icon, size: 18, color: AppColors.forestGreen),
                        const SizedBox(width: 10),
                        Text(
                          action.labelArabic,
                          style: AppTypography.bodyPrimary.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) {
                    onDecisionChanged(decision.copyWith(action: val));
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 8),

          // شرح تفصيلي للأثر المالي للخيار المختار
          Text(
            decision.action.descriptionArabic,
            style: AppTypography.bodySecondary.copyWith(
              fontSize: 11,
              color: AppColors.slateMuted,
            ),
          ),
        ],
      ),
    );
  }
}

