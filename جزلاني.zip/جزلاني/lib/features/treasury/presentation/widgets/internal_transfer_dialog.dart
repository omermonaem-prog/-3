import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../financial_engine/domain/entities/account_entity.dart';

/// حوار إجراء تحويل داخلي ذري بين الحسابات
class InternalTransferDialog extends StatefulWidget {
  final List<AccountEntity> accounts;
  final Future<bool> Function({
    required String fromAccountId,
    required String toAccountId,
    required Money amount,
    String? note,
    required String idempotencyKey,
  }) onTransfer;

  const InternalTransferDialog({
    super.key,
    required this.accounts,
    required this.onTransfer,
  });

  @override
  State<InternalTransferDialog> createState() => _InternalTransferDialogState();
}

class _InternalTransferDialogState extends State<InternalTransferDialog> {
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();

  String? _fromAccountId;
  String? _toAccountId;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    if (widget.accounts.length >= 2) {
      _fromAccountId = widget.accounts[0].id;
      _toAccountId = widget.accounts[1].id;
    } else if (widget.accounts.isNotEmpty) {
      _fromAccountId = widget.accounts[0].id;
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_fromAccountId == null || _toAccountId == null) return;
    if (_fromAccountId == _toAccountId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يمكن التحويل من الحساب وإلى نفسه')),
      );
      return;
    }

    final text = _amountController.text.trim();
    if (text.isEmpty) return;

    try {
      final amount = Money.parse(text);
      if (!amount.isPositive) return;

      setState(() => _isSubmitting = true);

      final key = 'trx_${DateTime.now().millisecondsSinceEpoch}';
      final success = await widget.onTransfer(
        fromAccountId: _fromAccountId!,
        toAccountId: _toAccountId!,
        amount: amount,
        note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
        idempotencyKey: key,
      );

      if (mounted) {
        setState(() => _isSubmitting = false);
        if (success) {
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ في التحويل: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      backgroundColor: AppColors.surfaceLight,
      title: Row(
        children: [
          const Icon(Icons.swap_horiz, color: AppColors.forestGreen, size: 28),
          const SizedBox(width: 10),
          Text('تحويل داخلي بين الحسابات', style: AppTypography.headingH3),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // تذكير بالقاعدة المحاسبية
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.forestGreen.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                'التحويل الداخلي لا يغير إجمالي أموالك، ولا يُسجل كمصروف أو دخل.',
                style: AppTypography.bodySecondary.copyWith(
                  fontSize: 11,
                  color: AppColors.forestGreen,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 14),

            // من حساب
            DropdownButtonFormField<String>(
              value: _fromAccountId,
              decoration: const InputDecoration(
                labelText: 'من حساب (المصدر)',
                border: OutlineInputBorder(),
              ),
              items: widget.accounts
                  .map((a) => DropdownMenuItem(
                        value: a.id,
                        child: Text('${a.name} (${a.balance.formatArabic()})'),
                      ))
                  .toList(),
              onChanged: (val) => setState(() => _fromAccountId = val),
            ),
            const SizedBox(height: 12),

            // إلى حساب
            DropdownButtonFormField<String>(
              value: _toAccountId,
              decoration: const InputDecoration(
                labelText: 'إلى حساب (الوجهة)',
                border: OutlineInputBorder(),
              ),
              items: widget.accounts
                  .map((a) => DropdownMenuItem(
                        value: a.id,
                        child: Text('${a.name} (${a.balance.formatArabic()})'),
                      ))
                  .toList(),
              onChanged: (val) => setState(() => _toAccountId = val),
            ),
            const SizedBox(height: 12),

            // المبلغ
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'مبلغ التحويل (ر.س)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),

            // ملاحظات
            TextField(
              controller: _noteController,
              decoration: const InputDecoration(
                labelText: 'ملاحظة (اختياري)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isSubmitting ? null : () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.forestGreen),
          onPressed: _isSubmitting ? null : _submit,
          child: _isSubmitting
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
              : const Text('تنفيذ التحويل'),
        ),
      ],
    );
  }
}

