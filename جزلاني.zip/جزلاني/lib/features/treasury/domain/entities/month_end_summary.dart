import '../../../../core/finance/money.dart';
import 'surplus_decision.dart';

/// ملخص إغلاق الشهر المالي الشامل
class MonthEndSummary {
  final String periodYearMonth;
  final Money totalIncome;
  final Money totalExpenses;
  final Money totalBudgetAllocated;
  final Money totalSurplus;
  final List<SurplusDecision> budgetSurpluses;
  final bool isClosed;
  final DateTime? closedAt;

  const MonthEndSummary({
    required this.periodYearMonth,
    required this.totalIncome,
    required this.totalExpenses,
    required this.totalBudgetAllocated,
    required this.totalSurplus,
    required this.budgetSurpluses,
    this.isClosed = false,
    this.closedAt,
  });

  /// هل يوجد أي فائض قابل للتوجيه في أي من الميزانيات
  bool get hasSurplus => totalSurplus.isPositive;

  /// صافي التدفق الشهري: الدخل - المصروف
  Money get netMonthlyCashFlow => totalIncome - totalExpenses;
}

