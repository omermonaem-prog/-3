import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/account_entity.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';

/// لقطة الخزينة الموحدة الشاملة (Treasury Snapshot)
///
/// تفصل فصلاً محاسبياً قاطعاً بين:
/// 1. إجمالي الأموال (Total Funds) في كافة الحسابات والخزائن.
/// 2. السيولة المتاحة للإنفاق الفعلي (Available Liquidity).
/// 3. محفظة الادخار العام الاستثماري (General Savings).
/// 4. صندوق الطوارئ المعزول (Emergency Fund).
/// 5. الأموال المحجوزة للأهداف المالية (Goals Locked).
/// 6. الأموال المقيدة للالتزامات الشهرية (Obligations Locked).
/// 7. سجل التحويلات الداخلية بين الأقسام دون احتسابها كمصروف أو دخل.
class TreasurySnapshot {
  /// إجمالي الأموال النقدية والبنكية في كافة الحسابات
  final Money totalFunds;

  /// السيولة الصافية الحرة المتاحة للصرف اليومي
  final Money availableLiquidity;

  /// رصيد محفظة الادخار العام
  final Money generalSavings;

  /// رصيد صندوق الطوارئ المعزول
  final Money emergencyFund;

  /// إجمالي المبالغ المحجوزة للأهداف
  final Money goalsLocked;

  /// إجمالي المبالغ المحجوزة للالتزامات
  final Money obligationsLocked;

  /// قائمة الحسابات والمحافظ المفصلة
  final List<AccountEntity> accounts;

  /// سجل التحويلات الداخلية بين الحسابات
  final List<TransactionEntity> internalTransfers;

  /// الطابع الزمني للقطة
  final DateTime updatedAt;

  const TreasurySnapshot({
    required this.totalFunds,
    required this.availableLiquidity,
    required this.generalSavings,
    required this.emergencyFund,
    required this.goalsLocked,
    required this.obligationsLocked,
    required this.accounts,
    required this.internalTransfers,
    required this.updatedAt,
  });

  /// إجمالي كافة الأموال المحجوزة والمعزولة
  Money get totalLockedFunds => emergencyFund + goalsLocked + obligationsLocked;

  @override
  String toString() {
    return 'TreasurySnapshot('
        'إجمالي الأموال: ${totalFunds.formatArabic()}, '
        'السيولة المتاحة: ${availableLiquidity.formatArabic()}, '
        'طوارئ: ${emergencyFund.formatArabic()}, '
        'أهداف: ${goalsLocked.formatArabic()})';
  }
}

