import '../../../../core/finance/money.dart';
import 'surplus_decision.dart';

/// سجل محاسبي لعملية إغلاق شهر مالي سابقة
class ClosedMonthRecord {
  final String id;
  final String periodYearMonth;
  final DateTime closedAt;
  final Money totalIncome;
  final Money totalExpenses;
  final Money totalSurplus;
  final List<SurplusDecision> decisions;
  final String? notes;
  final String idempotencyKey;

  const ClosedMonthRecord({
    required this.id,
    required this.periodYearMonth,
    required this.closedAt,
    required this.totalIncome,
    required this.totalExpenses,
    required this.totalSurplus,
    required this.decisions,
    this.notes,
    required this.idempotencyKey,
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ClosedMonthRecord &&
        other.id == id &&
        other.periodYearMonth == periodYearMonth;
  }

  @override
  int get hashCode => id.hashCode ^ periodYearMonth.hashCode;
}

