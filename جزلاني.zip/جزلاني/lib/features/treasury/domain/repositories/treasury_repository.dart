import '../../../../core/finance/money.dart';
import '../domain/entities/closed_month_record.dart';
import '../domain/entities/month_end_summary.dart';
import '../domain/entities/treasury_snapshot.dart';

/// العقد المجرد لمستودع الخزينة الموحدة وإغلاق الشهر
abstract class TreasuryRepository {
  Future<TreasurySnapshot> getTreasurySnapshot();
  Future<MonthEndSummary> getMonthEndSummary(String periodYearMonth);
  Future<bool> isMonthClosed(String periodYearMonth);
  Future<void> saveClosedMonthRecord(ClosedMonthRecord record);
  Future<List<ClosedMonthRecord>> getAllClosedMonthRecords();
  Future<ClosedMonthRecord?> getClosedMonthRecord(String periodYearMonth);
  Future<Money> getGeneralSavingsBalance();
  Future<void> updateGeneralSavingsBalance(Money newBalance);
}

