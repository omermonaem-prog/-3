import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import '../../financial_engine/data/repositories/financial_engine_repository_impl.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../domain/entities/closed_month_record.dart';
import '../domain/entities/month_end_summary.dart';
import '../domain/entities/surplus_action.dart';
import '../domain/entities/surplus_decision.dart';
import '../domain/entities/treasury_snapshot.dart';
import '../domain/repositories/treasury_repository.dart';

/// تطبيق مستودع الخزينة وإغلاق الشهر بالاعتماد على قاعدة البيانات المحلية
class TreasuryRepositoryImpl implements TreasuryRepository {
  final AppDatabase _db;
  final FinancialEngineRepositoryImpl _engineRepo;
  final Map<String, ClosedMonthRecord> _closedMonthsCache = {};
  Money _generalSavings = const Money.zero();
  final List<TransactionEntity> _internalTransfersCache = [];

  TreasuryRepositoryImpl(this._db)
      : _engineRepo = FinancialEngineRepositoryImpl(_db);

  @override
  Future<TreasurySnapshot> getTreasurySnapshot() async {
    final accounts = await _engineRepo.getAllActiveAccounts();
    final totalFunds = accounts.fold<Money>(
      const Money.zero(),
      (sum, acc) => sum + acc.balance,
    );

    final emergencyFund = await _engineRepo.getEmergencyFundBalance();
    final goalsLocked = await _engineRepo.getTotalActiveGoalsSaved();
    final obligationsLocked = await _engineRepo.getTotalLockedObligations();

    final totalLocked = emergencyFund + goalsLocked + obligationsLocked + _generalSavings;
    final available = totalFunds > totalLocked ? totalFunds - totalLocked : const Money.zero();

    return TreasurySnapshot(
      totalFunds: totalFunds,
      availableLiquidity: available,
      generalSavings: _generalSavings,
      emergencyFund: emergencyFund,
      goalsLocked: goalsLocked,
      obligationsLocked: obligationsLocked,
      accounts: accounts,
      internalTransfers: _internalTransfersCache,
      updatedAt: DateTime.now(),
    );
  }

  @override
  Future<MonthEndSummary> getMonthEndSummary(String periodYearMonth) async {
    final isClosed = _closedMonthsCache.containsKey(periodYearMonth);
    final closedRecord = _closedMonthsCache[periodYearMonth];

    return MonthEndSummary(
      periodYearMonth: periodYearMonth,
      totalIncome: closedRecord?.totalIncome ?? const Money.zero(),
      totalExpenses: closedRecord?.totalExpenses ?? const Money.zero(),
      totalBudgetAllocated: const Money.zero(),
      totalSurplus: closedRecord?.totalSurplus ?? const Money.zero(),
      budgetSurpluses: closedRecord?.decisions ?? [],
      isClosed: isClosed,
      closedAt: closedRecord?.closedAt,
    );
  }

  @override
  Future<bool> isMonthClosed(String periodYearMonth) async =>
      _closedMonthsCache.containsKey(periodYearMonth);

  @override
  Future<void> saveClosedMonthRecord(ClosedMonthRecord record) async {
    _closedMonthsCache[record.periodYearMonth] = record;
  }

  @override
  Future<List<ClosedMonthRecord>> getAllClosedMonthRecords() async {
    final list = _closedMonthsCache.values.toList();
    list.sort((a, b) => b.closedAt.compareTo(a.closedAt));
    return list;
  }

  @override
  Future<ClosedMonthRecord?> getClosedMonthRecord(String periodYearMonth) async =>
      _closedMonthsCache[periodYearMonth];

  @override
  Future<Money> getGeneralSavingsBalance() async => _generalSavings;

  @override
  Future<void> updateGeneralSavingsBalance(Money newBalance) async {
    _generalSavings = newBalance;
  }
}

