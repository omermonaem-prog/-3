import '../../../../core/finance/money.dart';
import '../../financial_engine/data/repositories/in_memory_financial_engine_repository.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../../expenses_budgets/data/repositories/in_memory_expenses_budgets_repository.dart';
import '../../income/data/repositories/in_memory_income_repository.dart';
import '../domain/entities/closed_month_record.dart';
import '../domain/entities/month_end_summary.dart';
import '../domain/entities/surplus_action.dart';
import '../domain/entities/surplus_decision.dart';
import '../domain/entities/treasury_snapshot.dart';
import '../domain/repositories/treasury_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع الخزينة وإغلاق الشهر
class InMemoryTreasuryRepository implements TreasuryRepository {
  final InMemoryFinancialEngineRepository engineRepo;
  final InMemoryExpensesBudgetsRepository expensesBudgetsRepo;
  final InMemoryIncomeRepository incomeRepo;

  final Map<String, ClosedMonthRecord> _closedMonths = {};
  Money generalSavingsBalance = const Money.zero();
  final List<TransactionEntity> internalTransfers = [];

  InMemoryTreasuryRepository({
    required this.engineRepo,
    required this.expensesBudgetsRepo,
    required this.incomeRepo,
  });

  @override
  Future<TreasurySnapshot> getTreasurySnapshot() async {
    final accounts = await engineRepo.getAllActiveAccounts();
    final totalFunds = accounts.fold<Money>(
      const Money.zero(),
      (sum, acc) => sum + acc.balance,
    );

    final emergencyFund = await engineRepo.getEmergencyFundBalance();
    final goalsLocked = await engineRepo.getTotalActiveGoalsSaved();
    final obligationsLocked = await engineRepo.getTotalLockedObligations();

    // السيولة المتاحة = إجمالي الأموال - المحجوزات
    final totalLocked = emergencyFund + goalsLocked + obligationsLocked + generalSavingsBalance;
    final available = totalFunds > totalLocked ? totalFunds - totalLocked : const Money.zero();

    return TreasurySnapshot(
      totalFunds: totalFunds,
      availableLiquidity: available,
      generalSavings: generalSavingsBalance,
      emergencyFund: emergencyFund,
      goalsLocked: goalsLocked,
      obligationsLocked: obligationsLocked,
      accounts: accounts,
      internalTransfers: internalTransfers,
      updatedAt: DateTime.now(),
    );
  }

  @override
  Future<MonthEndSummary> getMonthEndSummary(String periodYearMonth) async {
    final budgets = await expensesBudgetsRepo.getBudgetsByMonth(periodYearMonth);
    final allIncomes = await incomeRepo.getAllIncomes();
    final allExpenses = expensesBudgetsRepo.expenses.values.toList();

    // حساب إجمالي الدخل لهذا الشهر
    final monthIncomes = allIncomes.where((i) =>
        '${i.date.year}-${i.date.month.toString().padLeft(2, '0')}' ==
        periodYearMonth);
    final totalIncome = monthIncomes.fold<Money>(
      const Money.zero(),
      (sum, i) => sum + i.amount,
    );

    // حساب إجمالي المصروفات لهذا الشهر
    final monthExpenses = allExpenses.where((e) =>
        '${e.date.year}-${e.date.month.toString().padLeft(2, '0')}' ==
        periodYearMonth);
    final totalExpenses = monthExpenses.fold<Money>(
      const Money.zero(),
      (sum, e) => sum + e.amount,
    );

    // حساب إجمالي الميزانيات المخصصة
    final totalAllocated = budgets.fold<Money>(
      const Money.zero(),
      (sum, b) => sum + b.allocatedAmount,
    );

    // حساب فوائض كل ميزانية
    final surplusDecisions = <SurplusDecision>[];
    var totalSurplus = const Money.zero();

    for (final b in budgets) {
      if (b.remainingAmount.isPositive) {
        surplusDecisions.add(SurplusDecision(
          categoryId: b.categoryId,
          categoryName: b.categoryName,
          surplusAmount: b.remainingAmount,
          action: SurplusAction.rollover,
        ));
        totalSurplus += b.remainingAmount;
      }
    }

    final isClosed = _closedMonths.containsKey(periodYearMonth);
    final closedRecord = _closedMonths[periodYearMonth];

    return MonthEndSummary(
      periodYearMonth: periodYearMonth,
      totalIncome: totalIncome,
      totalExpenses: totalExpenses,
      totalBudgetAllocated: totalAllocated,
      totalSurplus: totalSurplus,
      budgetSurpluses: surplusDecisions,
      isClosed: isClosed,
      closedAt: closedRecord?.closedAt,
    );
  }

  @override
  Future<bool> isMonthClosed(String periodYearMonth) async =>
      _closedMonths.containsKey(periodYearMonth);

  @override
  Future<void> saveClosedMonthRecord(ClosedMonthRecord record) async {
    _closedMonths[record.periodYearMonth] = record;
  }

  @override
  Future<List<ClosedMonthRecord>> getAllClosedMonthRecords() async {
    final list = _closedMonths.values.toList();
    list.sort((a, b) => b.closedAt.compareTo(a.closedAt));
    return list;
  }

  @override
  Future<ClosedMonthRecord?> getClosedMonthRecord(String periodYearMonth) async =>
      _closedMonths[periodYearMonth];

  @override
  Future<Money> getGeneralSavingsBalance() async => generalSavingsBalance;

  @override
  Future<void> updateGeneralSavingsBalance(Money newBalance) async {
    generalSavingsBalance = newBalance;
  }
}

