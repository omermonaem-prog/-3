import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../domain/entities/budget_entity.dart';
import '../domain/entities/category_entity.dart';
import '../domain/entities/expense_entry.dart';
import '../domain/entities/transaction_filter.dart';
import '../domain/repositories/expenses_budgets_repository.dart';

/// تطبيق محاكي لذاكرة الوصول العشوائي لمستودع المصروفات والميزانيات
class InMemoryExpensesBudgetsRepository implements ExpensesBudgetsRepository {
  final Map<String, CategoryEntity> categories = {};
  final Map<String, BudgetEntity> budgets = {};
  final Map<String, ExpenseEntry> expenses = {};

  InMemoryExpensesBudgetsRepository() {
    _seedDefaultCategories();
  }

  void _seedDefaultCategories() {
    final defaultCats = [
      CategoryEntity(
        id: 'cat_groceries',
        name: 'البقالة والمؤونة',
        iconName: 'shopping-cart',
        colorHex: '#0E3B2E',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_dining',
        name: 'المطاعم والمقاهي',
        iconName: 'coffee',
        colorHex: '#DFBC75',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_transport',
        name: 'المواصلات والوقود',
        iconName: 'car',
        colorHex: '#165342',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_health',
        name: 'الصحة والعناية',
        iconName: 'heart-pulse',
        colorHex: '#8C1D1D',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_bills',
        name: 'فواتير واشتراكات',
        iconName: 'receipt',
        colorHex: '#5E6D67',
        createdAt: DateTime.now(),
      ),
    ];

    for (final c in defaultCats) {
      categories[c.id] = c;
    }
  }

  // ── التصنيفات ────────────────────────────────────────────────

  @override
  Future<List<CategoryEntity>> getExpenseCategories() async {
    return categories.values.where((c) => !c.isIncome).toList();
  }

  @override
  Future<CategoryEntity?> getCategoryById(String id) async => categories[id];

  @override
  Future<void> saveCategory(CategoryEntity category) async {
    categories[category.id] = category;
  }

  // ── الميزانيات ────────────────────────────────────────────────

  String _budgetKey(String catId, String ym) => '${catId}_$ym';

  @override
  Future<List<BudgetEntity>> getBudgetsByMonth(String periodYearMonth) async {
    return budgets.values
        .where((b) => b.periodYearMonth == periodYearMonth)
        .toList();
  }

  @override
  Future<BudgetEntity?> getBudgetByCategoryAndMonth(
      String categoryId, String periodYearMonth) async {
    return budgets[_budgetKey(categoryId, periodYearMonth)];
  }

  @override
  Future<void> saveBudget(BudgetEntity budget) async {
    budgets[_budgetKey(budget.categoryId, budget.periodYearMonth)] = budget;
  }

  @override
  Future<void> applyExpenseToBudget({
    required String categoryId,
    required String periodYearMonth,
    required Money amountDelta,
  }) async {
    final key = _budgetKey(categoryId, periodYearMonth);
    final b = budgets[key];
    if (b != null) {
      budgets[key] = b.copyWith(
        spentAmount: b.spentAmount + amountDelta,
      );
    }
  }

  @override
  Future<Money> getTotalRemainingBudgetLiquidity(String periodYearMonth) async {
    final monthBudgets = await getBudgetsByMonth(periodYearMonth);
    return monthBudgets.fold<Money>(
      const Money.zero(),
      (sum, b) {
        // إذا كان المتبقي سالباً (تجاوز)، لا يضاف للسيولة المتاحة
        final rem = b.remainingAmount;
        return rem.isPositive ? sum + rem : sum;
      },
    );
  }

  // ── المصروفات وسجل المعاملات ───────────────────────────────────

  @override
  Future<void> saveExpense(ExpenseEntry expense) async {
    expenses[expense.id] = expense;
  }

  @override
  Future<ExpenseEntry?> getExpenseById(String id) async => expenses[id];

  @override
  Future<List<ExpenseEntry>> getFilteredExpenses(TransactionFilter filter) async {
    var list = expenses.values.toList();

    // 1. فلترة البحث النصي
    if (filter.searchQuery != null && filter.searchQuery!.trim().isNotEmpty) {
      final q = filter.searchQuery!.trim().toLowerCase();
      list = list.where((e) {
        final descMatch = e.description.toLowerCase().contains(q);
        final notesMatch = e.notes?.toLowerCase().contains(q) ?? false;
        final catMatch = e.categoryName?.toLowerCase().contains(q) ?? false;
        return descMatch || notesMatch || catMatch;
      }).toList();
    }

    // 2. فلترة التاريخ
    if (filter.startDate != null) {
      list = list.where((e) => !e.date.isBefore(filter.startDate!)).toList();
    }
    if (filter.endDate != null) {
      list = list.where((e) => !e.date.isAfter(filter.endDate!)).toList();
    }

    // 3. فلترة التصنيف
    if (filter.categoryId != null) {
      list = list.where((e) => e.categoryId == filter.categoryId).toList();
    }

    // 4. فلترة الحساب
    if (filter.accountId != null) {
      list = list.where((e) => e.accountId == filter.accountId).toList();
    }

    // 5. فلترة المبالغ
    if (filter.minAmount != null) {
      list = list.where((e) => e.amount >= filter.minAmount!).toList();
    }
    if (filter.maxAmount != null) {
      list = list.where((e) => e.amount <= filter.maxAmount!).toList();
    }

    // الفرز من الأحدث للأقدم
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> updateExpenseStatus(String id, TransactionStatus status) async {
    final e = expenses[id];
    if (e != null) {
      expenses[id] = e.copyWith(status: status);
    }
  }
}

