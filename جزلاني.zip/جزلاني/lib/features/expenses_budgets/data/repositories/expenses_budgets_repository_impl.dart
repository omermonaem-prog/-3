import 'package:drift/drift.dart';
import '../../../../core/database/app_database.dart';
import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';
import '../domain/entities/budget_entity.dart';
import '../domain/entities/category_entity.dart';
import '../domain/entities/expense_entry.dart';
import '../domain/entities/transaction_filter.dart';
import '../domain/repositories/expenses_budgets_repository.dart';

/// تطبيق مستودع المصروفات والميزانيات بالاعتماد على قاعدة البيانات المحلية
class ExpensesBudgetsRepositoryImpl implements ExpensesBudgetsRepository {
  final AppDatabase _db;
  final Map<String, ExpenseEntry> _cachedExpenses = {};
  final Map<String, BudgetEntity> _cachedBudgets = {};

  ExpensesBudgetsRepositoryImpl(this._db);

  // ── التصنيفات ────────────────────────────────────────────────

  @override
  Future<List<CategoryEntity>> getExpenseCategories() async {
    return [
      CategoryEntity(
        id: 'cat_groceries',
        name: 'البقالة والمؤونة',
        iconName: 'shopping-cart',
        colorHex: '#0E3B2E',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_dining',
        name: 'المطاعم والمقاهي',
        iconName: 'coffee',
        colorHex: '#DFBC75',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_transport',
        name: 'المواصلات والوقود',
        iconName: 'car',
        colorHex: '#165342',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_health',
        name: 'الصحة والعناية',
        iconName: 'heart-pulse',
        colorHex: '#8C1D1D',
        createdAt: DateTime.now(),
      ),
      CategoryEntity(
        id: 'cat_bills',
        name: 'فواتير واشتراكات',
        iconName: 'receipt',
        colorHex: '#5E6D67',
        createdAt: DateTime.now(),
      ),
    ];
  }

  @override
  Future<CategoryEntity?> getCategoryById(String id) async {
    final list = await getExpenseCategories();
    try {
      return list.firstWhere((c) => c.id == id);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> saveCategory(CategoryEntity category) async {}

  // ── الميزانيات ────────────────────────────────────────────────

  String _budgetKey(String catId, String ym) => '${catId}_$ym';

  @override
  Future<List<BudgetEntity>> getBudgetsByMonth(String periodYearMonth) async {
    return _cachedBudgets.values
        .where((b) => b.periodYearMonth == periodYearMonth)
        .toList();
  }

  @override
  Future<BudgetEntity?> getBudgetByCategoryAndMonth(
      String categoryId, String periodYearMonth) async {
    return _cachedBudgets[_budgetKey(categoryId, periodYearMonth)];
  }

  @override
  Future<void> saveBudget(BudgetEntity budget) async {
    _cachedBudgets[_budgetKey(budget.categoryId, budget.periodYearMonth)] = budget;
    // حفظ في قاعدة البيانات عبر DAO
    await _db.budgetsDao.upsertBudget(BudgetsCompanion.insert(
      id: budget.id,
      categoryId: budget.categoryId,
      periodYearMonth: budget.periodYearMonth,
      allocatedMinorUnits: budget.allocatedAmount.minorUnits,
      warningThresholdPercent: Value(budget.warningThresholdPercent),
      createdAt: budget.createdAt,
    ));
  }

  @override
  Future<void> applyExpenseToBudget({
    required String categoryId,
    required String periodYearMonth,
    required Money amountDelta,
  }) async {
    final key = _budgetKey(categoryId, periodYearMonth);
    final b = _cachedBudgets[key];
    if (b != null) {
      _cachedBudgets[key] = b.copyWith(
        spentAmount: b.spentAmount + amountDelta,
      );
    }
  }

  @override
  Future<Money> getTotalRemainingBudgetLiquidity(String periodYearMonth) async {
    final list = await getBudgetsByMonth(periodYearMonth);
    return list.fold<Money>(
      const Money.zero(),
      (sum, b) {
        final rem = b.remainingAmount;
        return rem.isPositive ? sum + rem : sum;
      },
    );
  }

  // ── المصروفات وسجل المعاملات ───────────────────────────────────

  @override
  Future<void> saveExpense(ExpenseEntry expense) async {
    _cachedExpenses[expense.id] = expense;
    // تسجيل في جدول المعاملات
    await _db.transactionsDao.insertTransaction(TransactionsCompanion.insert(
      id: expense.id,
      accountId: expense.accountId,
      categoryId: Value(expense.categoryId),
      type: 'expense',
      amountMinorUnits: expense.amount.minorUnits,
      transactionDate: expense.date,
      note: Value(expense.description),
      receiptImagePath: Value(expense.receiptImagePath),
      createdAt: expense.createdAt,
    ));
  }

  @override
  Future<ExpenseEntry?> getExpenseById(String id) async => _cachedExpenses[id];

  @override
  Future<List<ExpenseEntry>> getFilteredExpenses(TransactionFilter filter) async {
    var list = _cachedExpenses.values.toList();

    if (filter.searchQuery != null && filter.searchQuery!.trim().isNotEmpty) {
      final q = filter.searchQuery!.trim().toLowerCase();
      list = list.where((e) {
        return e.description.toLowerCase().contains(q) ||
            (e.notes?.toLowerCase().contains(q) ?? false);
      }).toList();
    }

    if (filter.categoryId != null) {
      list = list.where((e) => e.categoryId == filter.categoryId).toList();
    }

    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  @override
  Future<void> updateExpenseStatus(String id, TransactionStatus status) async {
    final e = _cachedExpenses[id];
    if (e != null) {
      _cachedExpenses[id] = e.copyWith(status: status);
    }
  }
}

