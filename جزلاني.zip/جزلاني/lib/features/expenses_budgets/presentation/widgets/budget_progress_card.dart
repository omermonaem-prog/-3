import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../domain/entities/budget_entity.dart';
import '../domain/entities/budget_warning_level.dart';

/// بطاقة عرض تقدم ميزانية التصنيف والمتبقي ومستوى التحذير
class BudgetProgressCard extends StatelessWidget {
  final BudgetEntity budget;
  final VoidCallback? onAdjust;

  const BudgetProgressCard({
    super.key,
    required this.budget,
    this.onAdjust,
  });

  @override
  Widget build(BuildContext context) {
    final warning = budget.warningLevel;
    final color = warning.color;
    final progress = (budget.usagePercentage / 100.0).clamp(0.0, 1.0);

    return LuxuryCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // الصف العلوي: الأيقونة، الاسم، وشارة التحذير
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.category_outlined,
                  color: color,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      budget.categoryName,
                      style: AppTypography.headingH3.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'المخصص: ${budget.allocatedAmount.formatArabic()}',
                      style: AppTypography.bodySecondary,
                    ),
                  ],
                ),
              ),
              _buildWarningBadge(warning),
            ],
          ),
          const SizedBox(height: 16),

          // شريط التقدم المرئي
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: AppColors.surfaceSubtleLight,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
          const SizedBox(height: 12),

          // تفاصيل المصروف والمتبقي
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'المنفق حتى الآن',
                    style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                  ),
                  Text(
                    budget.spentAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.w700,
                      color: AppColors.textMain,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    budget.isExceeded ? 'العجز المتجاوز' : 'المتبقي الصافي',
                    style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                  ),
                  Text(
                    budget.remainingAmount.formatArabic(),
                    style: AppTypography.headingH3.copyWith(
                      color: budget.isExceeded ? AppColors.criticalRed : AppColors.cashIn,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),

          if (budget.isExceeded) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.criticalRed.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.criticalRed),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'تنبيه: تم استهلاك كامل الميزانية وتجاوزها.',
                      style: AppTypography.bodySecondary.copyWith(
                        fontSize: 11,
                        color: AppColors.criticalRed,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildWarningBadge(BudgetWarningLevel level) {
    switch (level) {
      case BudgetWarningLevel.safe:
        return const StatusBadge(label: 'آمن', type: StatusBadgeType.success);
      case BudgetWarningLevel.cautionary:
        return const StatusBadge(label: '70%+', type: StatusBadgeType.warning);
      case BudgetWarningLevel.warning:
        return const StatusBadge(label: '90%+', type: StatusBadgeType.warning);
      case BudgetWarningLevel.exceeded:
        return const StatusBadge(label: 'تجاوز', type: StatusBadgeType.danger);
    }
  }
}

