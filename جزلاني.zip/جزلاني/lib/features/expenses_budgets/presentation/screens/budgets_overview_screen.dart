import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/expenses_budgets_controller.dart';
import '../domain/entities/category_entity.dart';
import '../widgets/budget_progress_card.dart';
import 'add_expense_screen.dart';

/// شاشة الميزانيات ونظام المظاريف الشهرية (Budgets & Envelopes Overview Screen)
class BudgetsOverviewScreen extends ConsumerWidget {
  const BudgetsOverviewScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(expensesBudgetsControllerProvider);
    final controller = ref.read(expensesBudgetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('الميزانيات والمظاريف'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.add_chart_outlined, color: AppColors.forestGreen),
            tooltip: 'ضبط ميزانية جديدة',
            onPressed: () => _showAddBudgetDialog(context, ref, state.categories),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadData(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. بطاقة ملخص الميزانيات والسيولة المتاحة
              _buildSummaryCard(state),
              const SizedBox(height: 16),

              // 2. تنبيهات الميزانيات الحرجة (إن وجدت)
              if (state.alertBudgets.isNotEmpty) ...[
                _buildAlertBanner(state),
                const SizedBox(height: 16),
              ],

              // 3. شريط العنوان وزر إضافة مصروف سريع
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('مظاريف الإنفاق الشهرية', style: AppTypography.headingH2),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.forestGreen,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AddExpenseScreen(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.add, size: 18),
                    label: const Text('مصروف'),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // 4. قائمة بطاقات الميزانيات
              if (state.isLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(40),
                    child: CircularProgressIndicator(color: AppColors.forestGreen),
                  ),
                )
              else if (state.budgets.isEmpty)
                _buildEmptyBudgets(context, ref, state.categories)
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.budgets.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final budget = state.budgets[index];
                    return BudgetProgressCard(
                      budget: budget,
                      onAdjust: () => _showEditBudgetDialog(context, ref, budget),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryCard(dynamic state) {
    return LuxuryCard(
      backgroundColor: AppColors.forestGreen,
      borderColor: AppColors.champagneGold,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'السيولة المتاحة للإنفاق الحر',
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.canvasLight.withValues(alpha: 0.8),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.champagneGold.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  state.selectedYearMonth,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.champagneGoldBright,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            state.availableBudgetLiquidity.formatArabic(),
            style: AppTypography.displayLarge.copyWith(
              color: AppColors.champagneGoldBright,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          const Divider(color: AppColors.champagneGold, height: 1),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'المخصص الإجمالي',
                      style: AppTypography.bodySecondary.copyWith(
                        color: AppColors.canvasLight.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      state.totalAllocatedBudget.formatArabic(),
                      style: AppTypography.headingH3.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(width: 1, height: 36, color: Colors.white24),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'المصروف الإجمالي',
                      style: AppTypography.bodySecondary.copyWith(
                        color: AppColors.canvasLight.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      state.totalSpentBudget.formatArabic(),
                      style: AppTypography.headingH3.copyWith(
                        color: AppColors.cashOut,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAlertBanner(dynamic state) {
    final count = state.alertBudgets.length;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.warningAmber.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.warningAmber),
      ),
      child: Row(
        children: [
          const Icon(Icons.notifications_active, color: AppColors.warningAmber),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'تنبيه مالي: يوجد $count مظروف اقترب من النفاد أو تجاوز الحد المخصص.',
              style: AppTypography.bodySecondary.copyWith(
                color: AppColors.textMain,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyBudgets(BuildContext context, WidgetRef ref, List<CategoryEntity> categories) {
    return LuxuryCard(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      child: Center(
        child: Column(
          children: [
            const Icon(Icons.pie_chart_outline, size: 48, color: AppColors.slateMuted),
            const SizedBox(height: 12),
            Text('لم يتم ضبط ميزانيات لهذا الشهر', style: AppTypography.headingH3),
            const SizedBox(height: 4),
            Text(
              'خصص مبالغ للأقسام (بقاليات، مطاعم، فواتير...) للتحكم في الإنفاق',
              style: AppTypography.bodySecondary,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            LuxuryButton(
              label: '+ تخصيص أول ميزانية',
              onPressed: () => _showAddBudgetDialog(context, ref, categories),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddBudgetDialog(BuildContext context, WidgetRef ref, List<CategoryEntity> categories) {
    String? selectedCatId = categories.isNotEmpty ? categories.first.id : null;
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('تخصيص ميزانية جديدة', style: AppTypography.headingH3),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: selectedCatId,
                decoration: const InputDecoration(labelText: 'اختر التصنيف'),
                items: categories
                    .map((c) => DropdownMenuItem(value: c.id, child: Text(c.name)))
                    .toList(),
                onChanged: (val) => setDialogState(() => selectedCatId = val),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'المبلغ المخصص للشهر (ر.س)',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.forestGreen),
              onPressed: () async {
                if (selectedCatId == null || amountController.text.trim().isEmpty) return;
                final amount = Money.parse(amountController.text.trim());
                await ref.read(expensesBudgetsControllerProvider.notifier).createOrUpdateBudget(
                      categoryId: selectedCatId!,
                      allocatedAmount: amount,
                    );
                if (context.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ الميزانية'),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditBudgetDialog(BuildContext context, WidgetRef ref, dynamic budget) {
    final amountController =
        TextEditingController(text: budget.allocatedAmount.toMajorUnits().toString());

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('تعديل ميزانية ${budget.categoryName}', style: AppTypography.headingH3),
        content: TextField(
          controller: amountController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'المبلغ المخصص الجديد (ر.س)',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.forestGreen),
            onPressed: () async {
              final amount = Money.parse(amountController.text.trim());
              await ref.read(expensesBudgetsControllerProvider.notifier).createOrUpdateBudget(
                    categoryId: budget.categoryId,
                    allocatedAmount: amount,
                  );
              if (context.mounted) Navigator.pop(ctx);
            },
            child: const Text('تحديث'),
          ),
        ],
      ),
    );
  }
}

