import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../application/expenses_budgets_controller.dart';
import '../domain/entities/expense_entry.dart';
import '../widgets/expense_tile.dart';
import '../widgets/transaction_filter_sheet.dart';

/// شاشة سجل المعاملات والمصروفات الكامل مع البحث والتصفية (Transaction History Screen)
class TransactionHistoryScreen extends ConsumerWidget {
  const TransactionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(expensesBudgetsControllerProvider);
    final controller = ref.read(expensesBudgetsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('سجل المعاملات والمصروفات'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(
              state.filter.isEmpty ? Icons.tune : Icons.filter_alt,
              color: state.filter.isEmpty ? AppColors.forestGreen : AppColors.champagneGold,
            ),
            tooltip: 'تصفية وبحث',
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (ctx) => TransactionFilterSheet(
                  initialFilter: state.filter,
                  categories: state.categories,
                  onApply: (newFilter) => controller.applyFilter(newFilter),
                  onReset: () => controller.resetFilter(),
                ),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadData(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. شريط البحث السريع
              TextField(
                decoration: InputDecoration(
                  hintText: 'ابحث في الوصف أو الملاحظات...',
                  prefixIcon: const Icon(Icons.search, color: AppColors.forestGreen),
                  filled: true,
                  fillColor: AppColors.surfaceLight,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: AppColors.borderSubtleLight),
                  ),
                ),
                onChanged: (val) {
                  controller.applyFilter(state.filter.copyWith(searchQuery: val));
                },
              ),
              const SizedBox(height: 12),

              // 2. شارات الفلاتر النشطة (إن وجدت)
              if (!state.filter.isEmpty) _buildActiveFilterChips(context, controller, state),
              const SizedBox(height: 12),

              // 3. قائمة المعاملات
              if (state.isLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(40),
                    child: CircularProgressIndicator(color: AppColors.forestGreen),
                  ),
                )
              else if (state.expenses.isEmpty)
                _buildEmptyHistory()
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.expenses.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final expense = state.expenses[index];
                    return ExpenseTile(
                      expense: expense,
                      onCorrect: () => _showCorrectionDialog(context, ref, expense, state.categories),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActiveFilterChips(BuildContext context, ExpensesBudgetsController controller, dynamic state) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Chip(
            label: const Text('إلغاء كافة الفلاتر'),
            deleteIcon: const Icon(Icons.close, size: 16),
            onDeleted: () => controller.resetFilter(),
            backgroundColor: AppColors.surfaceSubtleLight,
          ),
          const SizedBox(width: 8),
          if (state.filter.searchQuery != null)
            Chip(
              label: Text('بحث: ${state.filter.searchQuery}'),
              backgroundColor: AppColors.forestGreen.withValues(alpha: 0.1),
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyHistory() {
    return LuxuryCard(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      child: Center(
        child: Column(
          children: [
            const Icon(Icons.receipt_long_outlined, size: 48, color: AppColors.slateMuted),
            const SizedBox(height: 12),
            Text('لا توجد معاملات مسجلة تطابق البحث', style: AppTypography.headingH3),
            const SizedBox(height: 4),
            Text(
              'أضف أول مصروف لمشاهدة سجل الحركات المالية هنا',
              style: AppTypography.bodySecondary,
            ),
          ],
        ),
      ),
    );
  }

  void _showCorrectionDialog(BuildContext context, WidgetRef ref, ExpenseEntry expense, dynamic categories) {
    final amountController =
        TextEditingController(text: expense.amount.toMajorUnits().toString());
    final descController = TextEditingController(text: expense.description);
    final reasonController = TextEditingController();
    String selectedCatId = expense.categoryId;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('تصحيح المعاملة', style: AppTypography.headingH3),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'سيتم عكس المصروف السابق (${expense.amount.formatArabic()}) وإثبات القيد المصحح مع حفظ تاريخ المعاملة الأصلي.',
                style: AppTypography.bodySecondary,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'المبلغ المصحح (ر.س)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: descController,
                decoration: const InputDecoration(
                  labelText: 'الوصف الجديد',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: reasonController,
                decoration: const InputDecoration(
                  labelText: 'سبب التصحيح المحاسبي (إلزامي)',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.forestGreen),
              onPressed: () async {
                final reason = reasonController.text.trim();
                if (reason.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('يجب توثيق سبب التصحيح')),
                  );
                  return;
                }
                final newAmount = Money.parse(amountController.text.trim());
                final key = 'corr_${DateTime.now().millisecondsSinceEpoch}';

                final success = await ref
                    .read(expensesBudgetsControllerProvider.notifier)
                    .correctExpense(
                      originalExpenseId: expense.id,
                      newAmount: newAmount,
                      newCategoryId: selectedCatId,
                      newDescription: descController.text.trim(),
                      reason: reason,
                      idempotencyKey: key,
                    );

                if (context.mounted && success) {
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم تصحيح المعاملة وتحديث الميزانية بنجاح')),
                  );
                }
              },
              child: const Text('اعتماد التصحيح'),
            ),
          ],
        ),
      ),
    );
  }
}

