import '../../../../core/finance/money.dart';
import '../domain/entities/budget_entity.dart';
import '../domain/entities/budget_warning_level.dart';
import '../domain/entities/category_entity.dart';
import '../domain/entities/expense_entry.dart';
import '../domain/entities/transaction_filter.dart';

/// حالة نظام المصروفات والميزانيات والتصنيفات
class ExpensesBudgetsState {
  final bool isLoading;
  final String selectedYearMonth; // مثال: '2026-10'
  final List<CategoryEntity> categories;
  final List<BudgetEntity> budgets;
  final List<ExpenseEntry> expenses;
  final TransactionFilter filter;
  final Money totalAllocatedBudget;
  final Money totalSpentBudget;
  /// السيولة المتاحة = مجموع المتبقي الإيجابي في ميزانيات الإنفاق الحالية
  final Money availableBudgetLiquidity;
  final String? errorMessage;
  final String? successMessage;

  const ExpensesBudgetsState({
    this.isLoading = false,
    this.selectedYearMonth = '2026-10',
    this.categories = const [],
    this.budgets = const [],
    this.expenses = const [],
    this.filter = const TransactionFilter(),
    this.totalAllocatedBudget = const Money.zero(),
    this.totalSpentBudget = const Money.zero(),
    this.availableBudgetLiquidity = const Money.zero(),
    this.errorMessage,
    this.successMessage,
  });

  /// الميزانيات التي اقتربت من الحد أو تجاوزته (70% فما فوق)
  List<BudgetEntity> get alertBudgets =>
      budgets.where((b) => b.warningLevel != BudgetWarningLevel.safe).toList();

  ExpensesBudgetsState copyWith({
    bool? isLoading,
    String? selectedYearMonth,
    List<CategoryEntity>? categories,
    List<BudgetEntity>? budgets,
    List<ExpenseEntry>? expenses,
    TransactionFilter? filter,
    Money? totalAllocatedBudget,
    Money? totalSpentBudget,
    Money? availableBudgetLiquidity,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return ExpensesBudgetsState(
      isLoading: isLoading ?? this.isLoading,
      selectedYearMonth: selectedYearMonth ?? this.selectedYearMonth,
      categories: categories ?? this.categories,
      budgets: budgets ?? this.budgets,
      expenses: expenses ?? this.expenses,
      filter: filter ?? this.filter,
      totalAllocatedBudget: totalAllocatedBudget ?? this.totalAllocatedBudget,
      totalSpentBudget: totalSpentBudget ?? this.totalSpentBudget,
      availableBudgetLiquidity:
          availableBudgetLiquidity ?? this.availableBudgetLiquidity,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage:
          clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

