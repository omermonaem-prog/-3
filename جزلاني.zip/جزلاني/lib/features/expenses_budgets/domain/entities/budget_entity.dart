import '../../../../core/finance/money.dart';
import 'budget_warning_level.dart';

/// كيان ميزانية التصنيف الشهرية (Monthly Budget Entity)
class BudgetEntity {
  final String id;
  final String categoryId;
  final String categoryName;
  final String categoryIcon;
  final String categoryColorHex;
  final String periodYearMonth; // مثال: '2026-10'
  final Money allocatedAmount;
  final Money spentAmount;
  final int warningThresholdPercent;
  final DateTime createdAt;

  const BudgetEntity({
    required this.id,
    required this.categoryId,
    required this.categoryName,
    required this.categoryIcon,
    required this.categoryColorHex,
    required this.periodYearMonth,
    required this.allocatedAmount,
    this.spentAmount = const Money.zero(),
    this.warningThresholdPercent = 80,
    required this.createdAt,
  });

  /// المتبقي الصافي في ميزانية هذا التصنيف: المخصص - المصروف
  Money get remainingAmount => allocatedAmount - spentAmount;

  /// نسبة الاستهلاك الحالية
  double get usagePercentage {
    if (allocatedAmount.minorUnits <= 0) return 0.0;
    return (spentAmount.minorUnits / allocatedAmount.minorUnits) * 100.0;
  }

  /// مستوى التحذير المالي الذكي
  BudgetWarningLevel get warningLevel =>
      BudgetWarningLevel.fromPercentage(usagePercentage);

  /// هل تم تجاوز حد الميزانية
  bool get isExceeded => spentAmount > allocatedAmount;

  /// هل استنفذت الميزانية تماماً
  bool get isDepleted => remainingAmount.minorUnits <= 0;

  /// هل الميزانية غير مستخدمة حتى الآن (0% استهلاك)
  bool get isUnused => spentAmount.isZero;

  BudgetEntity copyWith({
    String? id,
    String? categoryId,
    String? categoryName,
    String? categoryIcon,
    String? categoryColorHex,
    String? periodYearMonth,
    Money? allocatedAmount,
    Money? spentAmount,
    int? warningThresholdPercent,
    DateTime? createdAt,
  }) {
    return BudgetEntity(
      id: id ?? this.id,
      categoryId: categoryId ?? this.categoryId,
      categoryName: categoryName ?? this.categoryName,
      categoryIcon: categoryIcon ?? this.categoryIcon,
      categoryColorHex: categoryColorHex ?? this.categoryColorHex,
      periodYearMonth: periodYearMonth ?? this.periodYearMonth,
      allocatedAmount: allocatedAmount ?? this.allocatedAmount,
      spentAmount: spentAmount ?? this.spentAmount,
      warningThresholdPercent:
          warningThresholdPercent ?? this.warningThresholdPercent,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is BudgetEntity &&
        other.id == id &&
        other.categoryId == categoryId &&
        other.periodYearMonth == periodYearMonth &&
        other.allocatedAmount == allocatedAmount &&
        other.spentAmount == spentAmount;
  }

  @override
  int get hashCode =>
      id.hashCode ^
      categoryId.hashCode ^
      periodYearMonth.hashCode ^
      allocatedAmount.hashCode ^
      spentAmount.hashCode;
}

