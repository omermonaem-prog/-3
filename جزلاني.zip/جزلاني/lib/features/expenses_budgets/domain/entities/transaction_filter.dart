import '../../../../core/finance/money.dart';
import '../../financial_engine/domain/entities/transaction_entity.dart';

/// معايير تصفية والبحث في سجل المعاملات المالية
class TransactionFilter {
  final String? searchQuery;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? categoryId;
  final String? accountId;
  final Money? minAmount;
  final Money? maxAmount;
  final TransactionType? type;

  const TransactionFilter({
    this.searchQuery,
    this.startDate,
    this.endDate,
    this.categoryId,
    this.accountId,
    this.minAmount,
    this.maxAmount,
    this.type,
  });

  bool get isEmpty =>
      (searchQuery == null || searchQuery!.trim().isEmpty) &&
      startDate == null &&
      endDate == null &&
      categoryId == null &&
      accountId == null &&
      minAmount == null &&
      maxAmount == null &&
      type == null;

  TransactionFilter copyWith({
    String? searchQuery,
    DateTime? startDate,
    DateTime? endDate,
    String? categoryId,
    String? accountId,
    Money? minAmount,
    Money? maxAmount,
    TransactionType? type,
    bool clearSearch = false,
    bool clearDates = false,
    bool clearCategory = false,
    bool clearAccount = false,
    bool clearAmounts = false,
    bool clearType = false,
  }) {
    return TransactionFilter(
      searchQuery: clearSearch ? null : (searchQuery ?? this.searchQuery),
      startDate: clearDates ? null : (startDate ?? this.startDate),
      endDate: clearDates ? null : (endDate ?? this.endDate),
      categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
      accountId: clearAccount ? null : (accountId ?? this.accountId),
      minAmount: clearAmounts ? null : (minAmount ?? this.minAmount),
      maxAmount: clearAmounts ? null : (maxAmount ?? this.maxAmount),
      type: clearType ? null : (type ?? this.type),
    );
  }
}

