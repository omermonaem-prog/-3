import '../../../../core/finance/money.dart';

enum GoalFundingSource {
  account,
  generalSavings;

  String get labelArabic {
    switch (this) {
      case GoalFundingSource.account:
        return 'حساب بنكي / محفظة';
      case GoalFundingSource.generalSavings:
        return 'الادخار العام';
    }
  }
}

/// سجل تمويل أو سحب مخصص لهدف مالي
class GoalFundingEntry {
  final String id;
  final String goalId;
  final GoalFundingSource sourceType;
  final String sourceId;
  final String sourceName;
  final Money amount;
  final DateTime date;
  final String? notes;
  final bool isAllocation; // true = تخصيص, false = سحب

  const GoalFundingEntry({
    required this.id,
    required this.goalId,
    required this.sourceType,
    required this.sourceId,
    required this.sourceName,
    required this.amount,
    required this.date,
    this.notes,
    this.isAllocation = true,
  });
}

