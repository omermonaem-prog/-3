import '../../../../core/finance/money.dart';

enum GoalStatus {
  active,
  paused,
  achieved,
  purchased;

  String get labelArabic {
    switch (this) {
      case GoalStatus.active:
        return 'نشط';
      case GoalStatus.paused:
        return 'موقوف مؤقتاً';
      case GoalStatus.achieved:
        return 'مكتمل الادخار';
      case GoalStatus.purchased:
        return 'تم الشراء بنجاح';
    }
  }

  static GoalStatus fromString(String val) {
    switch (val.toLowerCase()) {
      case 'active':
        return GoalStatus.active;
      case 'paused':
        return GoalStatus.paused;
      case 'achieved':
        return GoalStatus.achieved;
      case 'purchased':
        return GoalStatus.purchased;
      default:
        return GoalStatus.active;
    }
  }
}

/// كيان الهدف المالي (Financial Goal Entity)
class GoalEntity {
  final String id;
  final String title;
  final String description;
  final Money targetAmount;
  final Money savedAmount;
  final DateTime? targetDate;
  final GoalStatus status;
  final String iconName;
  final String colorHex;
  final DateTime createdAt;

  const GoalEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.targetAmount,
    this.savedAmount = const Money.zero(),
    this.targetDate,
    this.status = GoalStatus.active,
    this.iconName = 'flag',
    this.colorHex = '#C5A059',
    required this.createdAt,
  });

  /// المبلغ المتبقي لتحقيق الهدف: Target - Saved
  Money get remainingAmount {
    if (savedAmount >= targetAmount) return const Money.zero();
    return targetAmount - savedAmount;
  }

  /// نسبة الإنجاز المئوية (0% إلى 100%)
  double get progressPercentage {
    if (targetAmount.minorUnits <= 0) return 0.0;
    final p = (savedAmount.minorUnits / targetAmount.minorUnits) * 100.0;
    return p.clamp(0.0, 100.0);
  }

  /// هل اكتمل المبلغ المطلوب وجاهز للشراء
  bool get isReadyForPurchase => savedAmount >= targetAmount;

  GoalEntity copyWith({
    String? id,
    String? title,
    String? description,
    Money? targetAmount,
    Money? savedAmount,
    DateTime? targetDate,
    GoalStatus? status,
    String? iconName,
    String? colorHex,
    DateTime? createdAt,
  }) {
    return GoalEntity(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      targetAmount: targetAmount ?? this.targetAmount,
      savedAmount: savedAmount ?? this.savedAmount,
      targetDate: targetDate ?? this.targetDate,
      status: status ?? this.status,
      iconName: iconName ?? this.iconName,
      colorHex: colorHex ?? this.colorHex,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is GoalEntity &&
        other.id == id &&
        other.title == title &&
        other.targetAmount == targetAmount &&
        other.savedAmount == savedAmount &&
        other.status == status;
  }

  @override
  int get hashCode =>
      id.hashCode ^
      title.hashCode ^
      targetAmount.hashCode ^
      savedAmount.hashCode ^
      status.hashCode;
}

