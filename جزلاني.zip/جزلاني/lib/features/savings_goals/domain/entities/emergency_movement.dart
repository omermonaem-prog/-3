import '../../../../core/finance/money.dart';

enum EmergencyMovementType {
  deposit,
  withdrawal;

  String get labelArabic {
    switch (this) {
      case EmergencyMovementType.deposit:
        return 'تغذية صندوق الطوارئ';
      case EmergencyMovementType.withdrawal:
        return 'سحب طارئ استثنائي';
    }
  }
}

/// حركة في سجل صندوق الطوارئ
class EmergencyMovement {
  final String id;
  final EmergencyMovementType type;
  final Money amount;
  final String reason;
  final String? compensationPlan;
  final DateTime date;
  final String idempotencyKey;

  const EmergencyMovement({
    required this.id,
    required this.type,
    required this.amount,
    required this.reason,
    this.compensationPlan,
    required this.date,
    required this.idempotencyKey,
  });
}

