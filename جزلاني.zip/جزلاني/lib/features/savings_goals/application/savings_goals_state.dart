import '../../../../core/finance/money.dart';
import '../domain/entities/emergency_movement.dart';
import '../domain/entities/goal_entity.dart';
import '../domain/entities/goal_funding_entry.dart';
import '../domain/entities/savings_movement.dart';

/// حالة نظام الادخار العام وصندوق الطوارئ والأهداف
class SavingsGoalsState {
  final bool isLoading;
  final Money generalSavings;
  final List<SavingsMovement> savingsMovements;

  final Money emergencyFund;
  final List<EmergencyMovement> emergencyMovements;

  final List<GoalEntity> goals;
  final List<GoalFundingEntry> selectedGoalFundingHistory;

  final String? errorMessage;
  final String? successMessage;

  const SavingsGoalsState({
    this.isLoading = false,
    this.generalSavings = const Money.zero(),
    this.savingsMovements = const [],
    this.emergencyFund = const Money.zero(),
    this.emergencyMovements = const [],
    this.goals = const [],
    this.selectedGoalFundingHistory = const [],
    this.errorMessage,
    this.successMessage,
  });

  /// إجمالي الأموال المحجوزة في الأهداف النشطة والمكتملة
  Money get totalGoalsSaved => goals
      .where((g) => g.status != GoalStatus.purchased)
      .fold<Money>(const Money.zero(), (sum, g) => sum + g.savedAmount);

  SavingsGoalsState copyWith({
    bool? isLoading,
    Money? generalSavings,
    List<SavingsMovement>? savingsMovements,
    Money? emergencyFund,
    List<EmergencyMovement>? emergencyMovements,
    List<GoalEntity>? goals,
    List<GoalFundingEntry>? selectedGoalFundingHistory,
    String? errorMessage,
    bool clearError = false,
    String? successMessage,
    bool clearSuccess = false,
  }) {
    return SavingsGoalsState(
      isLoading: isLoading ?? this.isLoading,
      generalSavings: generalSavings ?? this.generalSavings,
      savingsMovements: savingsMovements ?? this.savingsMovements,
      emergencyFund: emergencyFund ?? this.emergencyFund,
      emergencyMovements: emergencyMovements ?? this.emergencyMovements,
      goals: goals ?? this.goals,
      selectedGoalFundingHistory: selectedGoalFundingHistory ?? this.selectedGoalFundingHistory,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
      successMessage: clearSuccess ? null : (successMessage ?? this.successMessage),
    );
  }
}

