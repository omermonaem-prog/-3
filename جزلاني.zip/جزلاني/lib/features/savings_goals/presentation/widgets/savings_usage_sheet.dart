import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/goal_entity.dart';
import '../../domain/entities/savings_movement.dart';

/// ورقة استخدام أو تحويل مبالغ من الادخار العام
class SavingsUsageSheet extends StatefulWidget {
  final Money currentSavings;
  final List<GoalEntity> activeGoals;
  final Function({
    required Money amount,
    required SavingsMovementType destinationType,
    required String destinationDescription,
    String? targetGoalId,
    String? notes,
  }) onConfirm;

  const SavingsUsageSheet({
    super.key,
    required this.currentSavings,
    required this.activeGoals,
    required this.onConfirm,
  });

  @override
  State<SavingsUsageSheet> createState() => _SavingsUsageSheetState();
}

class _SavingsUsageSheetState extends State<SavingsUsageSheet> {
  final _amountController = TextEditingController();
  final _notesController = TextEditingController();
  SavingsMovementType _selectedType = SavingsMovementType.withdrawalToLiquidity;
  String? _selectedGoalId;
  String? _validationError;

  @override
  void initState() {
    super.initState();
    if (widget.activeGoals.isNotEmpty) {
      _selectedGoalId = widget.activeGoals.first.id;
    }
  }

  @override
  void dispose() {
    _amountController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Money? get _parsedAmount {
    try {
      final text = _amountController.text.trim();
      if (text.isEmpty) return null;
      return Money.parse(text);
    } catch (_) {
      return null;
    }
  }

  void _submit() {
    setState(() => _validationError = null);
    final amt = _parsedAmount;
    if (amt == null || !amt.isPositive) {
      setState(() => _validationError = 'يرجى إدخال مبلغ صحيح وموجب');
      return;
    }
    if (amt > widget.currentSavings) {
      setState(() => _validationError = 'رصيد الادخار العام لا يكفي لتغطية هذا المبلغ');
      return;
    }

    String destinationDesc;
    String? goalId;

    switch (_selectedType) {
      case SavingsMovementType.withdrawalToLiquidity:
        destinationDesc = 'سحب إلى السيولة المتاحة';
        break;
      case SavingsMovementType.transferToEmergency:
        destinationDesc = 'تحويل لصندوق الطوارئ';
        break;
      case SavingsMovementType.transferToGoal:
        if (_selectedGoalId == null) {
          setState(() => _validationError = 'يرجى اختيار الهدف المالي المراد التحويل إليه');
          return;
        }
        goalId = _selectedGoalId;
        final goal = widget.activeGoals.firstWhere((g) => g.id == goalId);
        destinationDesc = 'تخصيص للهدف: ${goal.title}';
        break;
      default:
        destinationDesc = 'استخدام من الادخار';
    }

    widget.onConfirm(
      amount: amt,
      destinationType: _selectedType,
      destinationDescription: destinationDesc,
      targetGoalId: goalId,
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.slateMuted.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.forestGreen.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.savings_outlined,
                    color: AppColors.forestGreen,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'استخدام من الادخار العام',
                        style: AppTypography.headingH3,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'الرصيد المتاح: ${widget.currentSavings.formatArabic()}',
                        style: AppTypography.bodySecondary.copyWith(
                          color: AppColors.forestGreen,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Destination Type Selection
            Text('اختر وجهة المبلغ *', style: AppTypography.bodyPrimary.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('السيولة المتاحة'),
                  selected: _selectedType == SavingsMovementType.withdrawalToLiquidity,
                  selectedColor: AppColors.forestGreen.withValues(alpha: 0.15),
                  labelStyle: TextStyle(
                    color: _selectedType == SavingsMovementType.withdrawalToLiquidity
                        ? AppColors.forestGreen
                        : AppColors.textMain,
                    fontWeight: FontWeight.w600,
                  ),
                  onSelected: (_) => setState(() => _selectedType = SavingsMovementType.withdrawalToLiquidity),
                ),
                ChoiceChip(
                  label: const Text('هدف مالي'),
                  selected: _selectedType == SavingsMovementType.transferToGoal,
                  selectedColor: AppColors.champagneGold.withValues(alpha: 0.25),
                  labelStyle: TextStyle(
                    color: _selectedType == SavingsMovementType.transferToGoal
                        ? AppColors.forestGreen
                        : AppColors.textMain,
                    fontWeight: FontWeight.w600,
                  ),
                  onSelected: (_) => setState(() => _selectedType = SavingsMovementType.transferToGoal),
                ),
                ChoiceChip(
                  label: const Text('صندوق الطوارئ'),
                  selected: _selectedType == SavingsMovementType.transferToEmergency,
                  selectedColor: AppColors.criticalRed.withValues(alpha: 0.15),
                  labelStyle: TextStyle(
                    color: _selectedType == SavingsMovementType.transferToEmergency
                        ? AppColors.criticalRed
                        : AppColors.textMain,
                    fontWeight: FontWeight.w600,
                  ),
                  onSelected: (_) => setState(() => _selectedType = SavingsMovementType.transferToEmergency),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // If destination is a Goal, choose which goal
            if (_selectedType == SavingsMovementType.transferToGoal) ...[
              if (widget.activeGoals.isEmpty)
                Text(
                  'لا توجد أهداف مالية نشطة حالياً. قم بإنشاء هدف أولاً.',
                  style: AppTypography.bodySecondary.copyWith(color: AppColors.warningAmber),
                )
              else
                DropdownButtonFormField<String>(
                  value: _selectedGoalId,
                  decoration: InputDecoration(
                    labelText: 'اختر الهدف المالي المستهدف *',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    prefixIcon: const Icon(Icons.flag_outlined),
                  ),
                  items: widget.activeGoals.map((g) {
                    return DropdownMenuItem<String>(
                      value: g.id,
                      child: Text('${g.title} (متبقي: ${g.remainingAmount.formatArabic()})'),
                    );
                  }).toList(),
                  onChanged: (val) => setState(() => _selectedGoalId = val),
                ),
              const SizedBox(height: 16),
            ],

            // Amount Input
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),

            // Notes
            TextField(
              controller: _notesController,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                hintText: 'سبب التحويل أو تفاصيل إضافية...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.edit_note_outlined),
              ),
            ),
            const SizedBox(height: 16),

            if (_validationError != null) ...[
              Text(
                _validationError!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
            ],

            // Submit Button
            LuxuryButton(
              label: 'تأكيد العملية',
              icon: Icons.check,
              onPressed: _submit,
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'إلغاء',
                style: AppTypography.bodyPrimary.copyWith(color: AppColors.slateMuted),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

