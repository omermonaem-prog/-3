import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/goal_entity.dart';

/// بطاقة عرض الهدف المالي ونسبة التقدم
class GoalProgressCard extends StatelessWidget {
  final GoalEntity goal;
  final VoidCallback? onTap;
  final VoidCallback? onAllocate;
  final VoidCallback? onPurchase;

  const GoalProgressCard({
    super.key,
    required this.goal,
    this.onTap,
    this.onAllocate,
    this.onPurchase,
  });

  @override
  Widget build(BuildContext context) {
    final progress = goal.progressPercentage / 100.0;

    Color badgeColor;
    Color badgeTextColor;
    switch (goal.status) {
      case GoalStatus.active:
        badgeColor = AppColors.forestGreen.withValues(alpha: 0.1);
        badgeTextColor = AppColors.forestGreen;
        break;
      case GoalStatus.paused:
        badgeColor = AppColors.slateMuted.withValues(alpha: 0.15);
        badgeTextColor = AppColors.slateMuted;
        break;
      case GoalStatus.achieved:
        badgeColor = AppColors.champagneGold.withValues(alpha: 0.2);
        badgeTextColor = AppColors.champagneGold;
        break;
      case GoalStatus.purchased:
        badgeColor = AppColors.cashIn.withValues(alpha: 0.15);
        badgeTextColor = AppColors.cashIn;
        break;
    }

    return LuxuryCard(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Header: Icon + Title + Status Badge
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppColors.champagneGold.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppColors.champagneGold.withValues(alpha: 0.4),
                  ),
                ),
                child: const Icon(
                  Icons.flag_rounded,
                  color: AppColors.champagneGold,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      goal.title,
                      style: AppTypography.headingH3,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (goal.description.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        goal.description,
                        style: AppTypography.bodySecondary,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
              StatusBadge(
                text: goal.status.labelArabic,
                color: badgeColor,
                textColor: badgeTextColor,
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Amounts row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('المدخر حالياً', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    goal.savedAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                      color: AppColors.forestGreen,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('المستهدف', style: AppTypography.bodySecondary),
                  const SizedBox(height: 2),
                  Text(
                    goal.targetAmount.formatArabic(),
                    style: AppTypography.bodyPrimary.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Progress Bar
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress.clamp(0.0, 1.0),
              minHeight: 10,
              backgroundColor: AppColors.surfaceSubtleLight,
              valueColor: AlwaysStoppedAnimation<Color>(
                goal.isReadyForPurchase
                    ? AppColors.champagneGold
                    : AppColors.forestGreen,
              ),
            ),
          ),
          const SizedBox(height: 6),

          // Progress Percentage and remaining
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${goal.progressPercentage.toStringAsFixed(1)}%',
                style: AppTypography.bodySecondary.copyWith(
                  fontWeight: FontWeight.w600,
                  color: goal.isReadyForPurchase
                      ? AppColors.champagneGold
                      : AppColors.forestGreen,
                ),
              ),
              if (!goal.isReadyForPurchase && goal.status != GoalStatus.purchased)
                Text(
                  'متبقي ${goal.remainingAmount.formatArabic()}',
                  style: AppTypography.bodySecondary,
                )
              else if (goal.status == GoalStatus.purchased)
                Text(
                  'تم الشراء بنجاح',
                  style: AppTypography.bodySecondary.copyWith(
                    color: AppColors.cashIn,
                    fontWeight: FontWeight.w600,
                  ),
                )
              else
                Text(
                  'جاهز للشراء! 🎯',
                  style: AppTypography.bodySecondary.copyWith(
                    color: AppColors.champagneGold,
                    fontWeight: FontWeight.bold,
                  ),
                ),
            ],
          ),

          // Action Buttons
          if (goal.status != GoalStatus.purchased) ...[
            const SizedBox(height: 14),
            Row(
              children: [
                if (!goal.isReadyForPurchase)
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: onAllocate,
                      icon: const Icon(Icons.add_circle_outline, size: 18),
                      label: const Text('تخصيص مبلغ'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.forestGreen,
                        side: const BorderSide(color: AppColors.forestGreen),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                if (goal.isReadyForPurchase)
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: onPurchase,
                      icon: const Icon(Icons.shopping_bag_outlined, size: 18),
                      label: const Text('تسجيل شراء الهدف'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.champagneGold,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

