import 'package:flutter/material.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';

/// ورقة تأكيد ومعاينة السحب الاستثنائي من صندوق الطوارئ
class EmergencyWithdrawalPreviewSheet extends StatefulWidget {
  final Money currentBalance;
  final Function(Money amount, String reason, String? compensationPlan) onConfirm;

  const EmergencyWithdrawalPreviewSheet({
    super.key,
    required this.currentBalance,
    required this.onConfirm,
  });

  @override
  State<EmergencyWithdrawalPreviewSheet> createState() =>
      _EmergencyWithdrawalPreviewSheetState();
}

class _EmergencyWithdrawalPreviewSheetState
    extends State<EmergencyWithdrawalPreviewSheet> {
  final _amountController = TextEditingController();
  final _reasonController = TextEditingController();
  final _planController = TextEditingController();
  bool _isConfirmedExplicitly = false;
  String? _validationError;

  Money? get _parsedAmount {
    try {
      final text = _amountController.text.trim();
      if (text.isEmpty) return null;
      return Money.parse(text);
    } catch (_) {
      return null;
    }
  }

  Money get _projectedRemaining {
    final amt = _parsedAmount;
    if (amt == null) return widget.currentBalance;
    if (amt > widget.currentBalance) return const Money.zero();
    return widget.currentBalance - amt;
  }

  @override
  void dispose() {
    _amountController.dispose();
    _reasonController.dispose();
    _planController.dispose();
    super.dispose();
  }

  void _validateAndSubmit() {
    setState(() => _validationError = null);

    final amt = _parsedAmount;
    if (amt == null || !amt.isPositive) {
      setState(() => _validationError = 'يرجى إدخال مبلغ سحب صحيح وموجب');
      return;
    }
    if (amt > widget.currentBalance) {
      setState(() => _validationError = 'المبلغ المطلوب أكبر من رصيد صندوق الطوارئ المتاح');
      return;
    }
    final reason = _reasonController.text.trim();
    if (reason.isEmpty) {
      setState(() => _validationError = 'يجب تقديم سبب واضح ومحدد للسحب الطارئ');
      return;
    }
    if (!_isConfirmedExplicitly) {
      setState(() => _validationError = 'يرجى تفعيل خيار التأكيد الصريح على العملية');
      return;
    }

    widget.onConfirm(
      amt,
      reason,
      _planController.text.trim().isEmpty ? null : _planController.text.trim(),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final amt = _parsedAmount;
    final projected = _projectedRemaining;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Sheet Handle
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.slateMuted.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Header with Alert Icon
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.criticalRed.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.warning_amber_rounded,
                    color: AppColors.criticalRed,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'سحب استثنائي من صندوق الطوارئ',
                        style: AppTypography.headingH3.copyWith(
                          color: AppColors.criticalRed,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'صندوق الطوارئ مخصص للظروف القاهرة فقط',
                        style: AppTypography.bodySecondary,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Amount Input
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              textAlign: TextAlign.start,
              decoration: InputDecoration(
                labelText: 'المبلغ المطلوب سحبه (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),

            // Reason Input (Mandatory)
            TextField(
              controller: _reasonController,
              maxLines: 2,
              decoration: InputDecoration(
                labelText: 'سبب السحب الطارئ بالتفصيل *',
                hintText: 'مثال: ظرف صحي عاجل، إصلاح سيارة مفاجئ...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.description_outlined),
              ),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 14),

            // Compensation Plan (Optional)
            TextField(
              controller: _planController,
              decoration: InputDecoration(
                labelText: 'خطة تعويض المبلغ مستقبلاً (اختياري)',
                hintText: 'مثال: اقتطاع 500 ريال من دخل الشهر القادم',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                prefixIcon: const Icon(Icons.replay_rounded),
              ),
            ),
            const SizedBox(height: 18),

            // Live Preview Card
            LuxuryCard(
              backgroundColor: AppColors.surfaceSubtleLight,
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('الرصيد الحالي:', style: AppTypography.bodySecondary),
                      Text(
                        widget.currentBalance.formatArabic(),
                        style: AppTypography.bodyPrimary.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('مبلغ السحب:', style: AppTypography.bodySecondary),
                      Text(
                        amt != null ? amt.formatArabic() : '0.00 ر.س',
                        style: AppTypography.bodyPrimary.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppColors.criticalRed,
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'الرصيد المتبقي بعد السحب:',
                        style: AppTypography.bodySecondary.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        projected.formatArabic(),
                        style: AppTypography.bodyPrimary.copyWith(
                          fontWeight: FontWeight.bold,
                          color: projected.isZero
                              ? AppColors.criticalRed
                              : AppColors.forestGreen,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Explicit Confirmation Checkbox
            CheckboxListTile(
              value: _isConfirmedExplicitly,
              onChanged: (val) =>
                  setState(() => _isConfirmedExplicitly = val ?? false),
              title: Text(
                'أقر بأن هذا السحب لظرف طارئ حقيقي ومدروس',
                style: AppTypography.bodySecondary.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              controlAffinity: ListTileControlAffinity.leading,
              contentPadding: EdgeInsets.zero,
              activeColor: AppColors.criticalRed,
            ),

            if (_validationError != null) ...[
              const SizedBox(height: 8),
              Text(
                _validationError!,
                style: AppTypography.bodySecondary.copyWith(
                  color: AppColors.criticalRed,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ],
            const SizedBox(height: 18),

            // Action Buttons
            LuxuryButton(
              label: 'تأكيد وتنفيذ السحب الطارئ',
              type: LuxuryButtonType.danger,
              icon: Icons.check_circle_outline,
              onPressed: _validateAndSubmit,
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'إلغاء العملية',
                style: AppTypography.bodyPrimary.copyWith(
                  color: AppColors.slateMuted,
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

