import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../../../core/widgets/status_badge.dart';
import '../../domain/entities/goal_entity.dart';
import '../../domain/entities/goal_funding_entry.dart';
import '../application/savings_goals_controller.dart';

/// شاشة تفاصيل الهدف المالي وسجل التمويل والشراء
class GoalDetailScreen extends ConsumerStatefulWidget {
  final String goalId;

  const GoalDetailScreen({super.key, required this.goalId});

  @override
  ConsumerState<GoalDetailScreen> createState() => _GoalDetailScreenState();
}

class _GoalDetailScreenState extends ConsumerState<GoalDetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(savingsGoalsControllerProvider.notifier).loadGoalFundingHistory(widget.goalId);
    });
  }

  void _showAllocationDialog(BuildContext context, GoalEntity goal) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    final state = ref.read(savingsGoalsControllerProvider);

    GoalFundingSource selectedSource = GoalFundingSource.account;
    final amountController = TextEditingController();
    final notesController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text('تخصيص مبلغ للهدف', style: AppTypography.headingH3),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('اختر مصدر التمويل:', style: AppTypography.bodySecondary),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: ChoiceChip(
                      label: const Text('حساب بنكي'),
                      selected: selectedSource == GoalFundingSource.account,
                      onSelected: (_) => setDialogState(() => selectedSource = GoalFundingSource.account),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ChoiceChip(
                      label: Text('الادخار (${state.generalSavings.formatArabic()})'),
                      selected: selectedSource == GoalFundingSource.generalSavings,
                      onSelected: (_) => setDialogState(() => selectedSource = GoalFundingSource.generalSavings),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              TextField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: 'المبلغ المخصص (ر.س) *',
                  hintText: '0.00',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.attach_money_rounded),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: notesController,
                decoration: InputDecoration(
                  labelText: 'ملاحظات (اختياري)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.forestGreen,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                try {
                  final amt = Money.parse(amountController.text.trim());
                  final idpKey = 'alloc_${DateTime.now().millisecondsSinceEpoch}';
                  await controller.allocateToGoal(
                    goalId: goal.id,
                    sourceType: selectedSource,
                    amount: amt,
                    sourceAccountId: selectedSource == GoalFundingSource.account ? 'acc_primary' : null,
                    notes: notesController.text.trim().isEmpty ? null : notesController.text.trim(),
                    idempotencyKey: idpKey,
                  );
                  await controller.loadGoalFundingHistory(goal.id);
                  if (context.mounted) Navigator.pop(ctx);
                } catch (_) {}
              },
              child: const Text('تأكيد التخصيص'),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeallocationDialog(BuildContext context, GoalEntity goal) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    final amountController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('استرداد مخصصات من الهدف', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'الرصيد المخصص للهدف حالياً: ${goal.savedAmount.formatArabic()}',
              style: AppTypography.bodySecondary,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'مبلغ الاسترداد (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.criticalRed,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final amt = Money.parse(amountController.text.trim());
                final idpKey = 'dealloc_${DateTime.now().millisecondsSinceEpoch}';
                await controller.deallocateFromGoal(
                  goalId: goal.id,
                  toAccountId: 'acc_primary',
                  amount: amt,
                  idempotencyKey: idpKey,
                );
                await controller.loadGoalFundingHistory(goal.id);
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: const Text('استرداد للحساب'),
          ),
        ],
      ),
    );
  }

  void _showPurchaseConfirmationDialog(BuildContext context, GoalEntity goal) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.shopping_bag_rounded, color: AppColors.champagneGold),
            const SizedBox(width: 8),
            Text('تأكيد شراء الهدف', style: AppTypography.headingH3),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'هل أنت متأكد من تنفيذ شراء الهدف "${goal.title}"؟',
              style: AppTypography.bodyPrimary,
            ),
            const SizedBox(height: 10),
            Text(
              'سيتم استخدام المبلغ المدخر بالكامل (${goal.savedAmount.formatArabic()}) وتسجيل حالة الهدف كـ "تم الشراء بنجاح".',
              style: AppTypography.bodySecondary,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.champagneGold,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              final idpKey = 'purchase_${DateTime.now().millisecondsSinceEpoch}';
              final success = await controller.purchaseGoal(
                goalId: goal.id,
                idempotencyKey: idpKey,
              );
              if (context.mounted) {
                Navigator.pop(ctx);
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('مبارك! تم تسجيل شراء الهدف المالي بنجاح 🎯'),
                      backgroundColor: AppColors.forestGreen,
                    ),
                  );
                }
              }
            },
            child: const Text('تأكيد الشراء'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(savingsGoalsControllerProvider);
    final controller = ref.read(savingsGoalsControllerProvider.notifier);

    final goal = state.goals.where((g) => g.id == widget.goalId).firstOrNull;

    if (goal == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('تفاصيل الهدف')),
        body: const Center(child: Text('الهدف غير موجود أو تم حذفه')),
      );
    }

    final progress = (goal.progressPercentage / 100.0).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: Text(goal.title),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
        actions: [
          if (goal.status == GoalStatus.active)
            IconButton(
              icon: const Icon(Icons.pause_circle_outline, color: AppColors.slateMuted),
              tooltip: 'إيقاف الهدف مؤقتاً',
              onPressed: () => controller.pauseGoal(goal.id),
            )
          else if (goal.status == GoalStatus.paused)
            IconButton(
              icon: const Icon(Icons.play_circle_outline, color: AppColors.forestGreen),
              tooltip: 'استئناف الهدف',
              onPressed: () => controller.resumeGoal(goal.id),
            ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await controller.loadAll();
          await controller.loadGoalFundingHistory(goal.id);
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero Summary Card
              LuxuryCard(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('حالة الهدف', style: AppTypography.bodySecondary),
                        StatusBadge(
                          text: goal.status.labelArabic,
                          color: goal.isReadyForPurchase
                              ? AppColors.champagneGold.withValues(alpha: 0.2)
                              : AppColors.forestGreen.withValues(alpha: 0.1),
                          textColor: goal.isReadyForPurchase
                              ? AppColors.champagneGold
                              : AppColors.forestGreen,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('المدخر حالياً', style: AppTypography.bodySecondary),
                            const SizedBox(height: 4),
                            Text(
                              goal.savedAmount.formatArabic(),
                              style: AppTypography.displayLarge.copyWith(
                                color: AppColors.forestGreen,
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('المستهدف', style: AppTypography.bodySecondary),
                            const SizedBox(height: 4),
                            Text(
                              goal.targetAmount.formatArabic(),
                              style: AppTypography.headingH2.copyWith(fontSize: 22),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 12,
                        backgroundColor: AppColors.surfaceSubtleLight,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          goal.isReadyForPurchase
                              ? AppColors.champagneGold
                              : AppColors.forestGreen,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${goal.progressPercentage.toStringAsFixed(1)}% منجز',
                          style: AppTypography.bodySecondary.copyWith(
                            fontWeight: FontWeight.bold,
                            color: goal.isReadyForPurchase
                                ? AppColors.champagneGold
                                : AppColors.forestGreen,
                          ),
                        ),
                        if (!goal.isReadyForPurchase && goal.status != GoalStatus.purchased)
                          Text(
                            'متبقي ${goal.remainingAmount.formatArabic()}',
                            style: AppTypography.bodySecondary,
                          ),
                      ],
                    ),
                    if (goal.description.isNotEmpty) ...[
                      const Divider(height: 24),
                      Text('الوصف والملاحظات:', style: AppTypography.bodySecondary),
                      const SizedBox(height: 4),
                      Text(goal.description, style: AppTypography.bodyPrimary),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Action Buttons Row
              if (goal.status != GoalStatus.purchased) ...[
                Row(
                  children: [
                    Expanded(
                      child: LuxuryButton(
                        label: 'تخصيص مبلغ',
                        icon: Icons.add_circle_outline,
                        onPressed: () => _showAllocationDialog(context, goal),
                      ),
                    ),
                    if (goal.savedAmount.isPositive) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: LuxuryButton(
                          label: 'استرداد',
                          type: LuxuryButtonType.secondary,
                          icon: Icons.remove_circle_outline,
                          onPressed: () => _showDeallocationDialog(context, goal),
                        ),
                      ),
                    ],
                  ],
                ),
                if (goal.isReadyForPurchase) ...[
                  const SizedBox(height: 12),
                  LuxuryButton(
                    label: 'تسجيل شراء الهدف الآن 🎯',
                    type: LuxuryButtonType.primary,
                    icon: Icons.shopping_bag_outlined,
                    onPressed: () => _showPurchaseConfirmationDialog(context, goal),
                  ),
                ],
                const SizedBox(height: 24),
              ],

              // Funding History Section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('سجل تمويل الهدف', style: AppTypography.headingH3),
                  Text(
                    '${state.selectedGoalFundingHistory.length} عملية',
                    style: AppTypography.bodySecondary,
                  ),
                ],
              ),
              const SizedBox(height: 12),

              if (state.selectedGoalFundingHistory.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(24),
                  child: Center(
                    child: Text(
                      'لا يوجد سجل تمويل أو حركات لهذا الهدف بعد',
                      style: AppTypography.bodySecondary,
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.selectedGoalFundingHistory.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final item = state.selectedGoalFundingHistory[index];
                    return LuxuryCard(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Icon(
                            item.isAllocation ? Icons.add_circle : Icons.remove_circle,
                            color: item.isAllocation ? AppColors.cashIn : AppColors.criticalRed,
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${item.isAllocation ? "تخصيص من" : "استرداد إلى"} ${item.sourceName}',
                                  style: AppTypography.bodyPrimary.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                Text(
                                  '${item.date.year}/${item.date.month.toString().padLeft(2, '0')}/${item.date.day.toString().padLeft(2, '0')}',
                                  style: AppTypography.bodySecondary.copyWith(fontSize: 11),
                                ),
                              ],
                            ),
                          ),
                          Text(
                            '${item.isAllocation ? '+' : '-'}${item.amount.formatArabic()}',
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: item.isAllocation ? AppColors.cashIn : AppColors.criticalRed,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

