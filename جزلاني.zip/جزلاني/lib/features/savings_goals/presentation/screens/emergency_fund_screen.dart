import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/finance/money.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/luxury_button.dart';
import '../../../../core/widgets/luxury_card.dart';
import '../../domain/entities/emergency_movement.dart';
import '../application/savings_goals_controller.dart';
import '../widgets/emergency_withdrawal_preview_sheet.dart';

/// شاشة صندوق الطوارئ المستقل (Independent Emergency Fund Screen)
class EmergencyFundScreen extends ConsumerWidget {
  const EmergencyFundScreen({super.key});

  void _showDepositDialog(BuildContext context, WidgetRef ref) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    final amountController = TextEditingController();
    final notesController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('تعزيز صندوق الطوارئ', style: AppTypography.headingH3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'المبلغ المضاف (ر.س) *',
                hintText: '0.00',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                prefixIcon: const Icon(Icons.attach_money_rounded),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notesController,
              decoration: InputDecoration(
                labelText: 'ملاحظات (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.forestGreen,
              foregroundColor: Colors.white,
            ),
            onPressed: () async {
              try {
                final amt = Money.parse(amountController.text.trim());
                final idpKey = 'deposit_ef_${DateTime.now().millisecondsSinceEpoch}';
                await controller.depositToEmergency(
                  amount: amt,
                  notes: notesController.text.trim().isEmpty ? null : notesController.text.trim(),
                  idempotencyKey: idpKey,
                );
                if (context.mounted) Navigator.pop(ctx);
              } catch (_) {}
            },
            child: const Text('إيداع وتعزيز'),
          ),
        ],
      ),
    );
  }

  void _showWithdrawalSheet(BuildContext context, WidgetRef ref, Money currentBalance) {
    final controller = ref.read(savingsGoalsControllerProvider.notifier);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surfaceLight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => EmergencyWithdrawalPreviewSheet(
        currentBalance: currentBalance,
        onConfirm: (amount, reason, compensationPlan) async {
          final idpKey = 'withdraw_ef_${DateTime.now().millisecondsSinceEpoch}';
          final success = await controller.withdrawFromEmergency(
            amount: amount,
            reason: reason,
            compensationPlan: compensationPlan,
            idempotencyKey: idpKey,
          );
          if (context.mounted && success) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('تم تنفيذ السحب الطارئ وتحديث الرصيد'),
                backgroundColor: AppColors.forestGreen,
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(savingsGoalsControllerProvider);
    final controller = ref.read(savingsGoalsControllerProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.canvasLight,
      appBar: AppBar(
        title: const Text('صندوق الطوارئ'),
        backgroundColor: AppColors.canvasLight,
        elevation: 0,
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () => controller.loadAll(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Hero Balance Card - Shield / Safety themed
              LuxuryCard(
                backgroundColor: const Color(0xFF1B2E28),
                borderColor: AppColors.champagneGold.withValues(alpha: 0.3),
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.criticalRed.withValues(alpha: 0.2),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: AppColors.criticalRed.withValues(alpha: 0.4),
                        ),
                      ),
                      child: const Icon(
                        Icons.shield_rounded,
                        color: AppColors.champagneGold,
                        size: 34,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'رصيد الأمان والطوارئ',
                      style: AppTypography.bodySecondary.copyWith(
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      state.emergencyFund.formatArabic(),
                      style: AppTypography.displayLarge.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => _showDepositDialog(context, ref),
                            icon: const Icon(Icons.add_shield_rounded, size: 18),
                            label: const Text('تعزيز الصندوق'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.forestGreen,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: state.emergencyFund.isPositive
                                ? () => _showWithdrawalSheet(context, ref, state.emergencyFund)
                                : null,
                            icon: const Icon(Icons.warning_amber_rounded, size: 18),
                            label: const Text('سحب طارئ'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppColors.criticalRed,
                              side: const BorderSide(color: AppColors.criticalRed),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Movements History Title
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('سجل حركات صندوق الطوارئ', style: AppTypography.headingH3),
                  Text(
                    '${state.emergencyMovements.length} حركة',
                    style: AppTypography.bodySecondary,
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Emergency Movements List
              if (state.emergencyMovements.isEmpty)
                LuxuryCard(
                  padding: const EdgeInsets.all(28),
                  child: Center(
                    child: Column(
                      children: [
                        Icon(
                          Icons.verified_user_outlined,
                          size: 40,
                          color: AppColors.slateMuted.withValues(alpha: 0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لم يتم تسجيل أي عمليات سحب أو تعزيز حتى الآن',
                          style: AppTypography.bodySecondary,
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: state.emergencyMovements.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    final m = state.emergencyMovements[index];
                    final isDeposit = m.type == EmergencyMovementType.deposit;

                    return LuxuryCard(
                      padding: const EdgeInsets.all(14),
                      borderColor: isDeposit
                          ? null
                          : AppColors.criticalRed.withValues(alpha: 0.2),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: isDeposit
                                  ? AppColors.cashIn.withValues(alpha: 0.12)
                                  : AppColors.criticalRed.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              isDeposit ? Icons.shield_outlined : Icons.report_problem_outlined,
                              color: isDeposit ? AppColors.cashIn : AppColors.criticalRed,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  m.reason,
                                  style: AppTypography.bodyPrimary.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '${m.date.year}/${m.date.month.toString().padLeft(2, '0')}/${m.date.day.toString().padLeft(2, '0')}',
                                  style: AppTypography.bodySecondary.copyWith(fontSize: 12),
                                ),
                                if (m.compensationPlan != null && m.compensationPlan!.isNotEmpty) ...[
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: AppColors.surfaceSubtleLight,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      'خطة التعويض: ${m.compensationPlan}',
                                      style: AppTypography.bodySecondary.copyWith(
                                        fontSize: 11,
                                        color: AppColors.forestGreen,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          Text(
                            '${isDeposit ? '+' : '-'}${m.amount.formatArabic()}',
                            style: AppTypography.bodyPrimary.copyWith(
                              fontWeight: FontWeight.bold,
                              color: isDeposit ? AppColors.cashIn : AppColors.criticalRed,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

