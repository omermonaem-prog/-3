/// نموذج إخفاقات النظام المعمارية
abstract class Failure {
  final String message;
  final String? code;

  const Failure(this.message, [this.code]);
}

class DatabaseFailure extends Failure {
  const DatabaseFailure(super.message, [super.code]);
}

class FinancialValidationFailure extends Failure {
  const FinancialValidationFailure(super.message, [super.code]);
}

class SecurityFailure extends Failure {
  const SecurityFailure(super.message, [super.code]);
}

class UnexpectedFailure extends Failure {
  const UnexpectedFailure([String? message])
      : super(message ?? 'حدث خطأ غير متوقع، يرجى المحاولة لاحقاً');
}

