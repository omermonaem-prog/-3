import 'package:flutter/material.dart';

/// إدارة اللغة والاتجاه العربي الأصيل (RTL Native)
class AppLocale {
  AppLocale._();

  static const Locale defaultLocale = Locale('ar', 'SA');

  static const List<Locale> supportedLocales = [
    Locale('ar', 'SA'),
    Locale('en', 'US'),
  ];

  static bool isRTL(BuildContext context) {
    return Directionality.of(context) == TextDirection.rtl;
  }
}

