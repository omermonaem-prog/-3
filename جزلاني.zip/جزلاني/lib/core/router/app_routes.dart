/// مسارات التنقل الثابتة لمشروع MyFinance
class AppRoutes {
  AppRoutes._();

  static const String dashboard = '/';
  static const String treasury = '/treasury';
  static const String monthEndClosing = '/treasury/close-month';
  static const String closedMonthsHistory = '/treasury/closed-history';
  static const String income = '/income';
  static const String recordSalary = '/income/salary';
  static const String recordAdditionalIncome = '/income/additional';
  static const String salaryAllocation = '/salary-allocation';
  static const String expenses = '/expenses';
  static const String addExpense = '/expenses/add';
  static const String budgets = '/budgets';
  static const String obligations = '/obligations';
  static const String addObligation = '/obligations/add';
  static const String savings = '/savings';
  static const String emergencyFund = '/emergency-fund';
  static const String goals = '/goals';
  static const String addGoal = '/goals/add';
  static const String goalDetail = '/goals/detail';
  static const String debts = '/debts';
  static const String addDebt = '/debts/add';
  static const String debtDetail = '/debts/detail';
  static const String assets = '/assets';
  static const String addAsset = '/assets/add';
  static const String netWorth = '/net-worth';
  static const String liabilitiesOverview = '/liabilities-overview';
  static const String analytics = '/analytics';
  static const String financialCalendar = '/analytics/calendar';
  static const String forecasts = '/analytics/forecasts';
  static const String monthlyReportDetail = '/analytics/report-detail';
  static const String settings = '/settings';
  static const String appLock = '/settings/lock';
  static const String backupManagement = '/settings/backup';
}
