import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/analytics/presentation/screens/analytics_dashboard_screen.dart';
import '../../features/analytics/presentation/screens/financial_calendar_screen.dart';
import '../../features/analytics/presentation/screens/forecasts_screen.dart';
import '../../features/analytics/presentation/screens/monthly_report_detail_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/expenses_budgets/presentation/screens/add_expense_screen.dart';
import '../../features/expenses_budgets/presentation/screens/budgets_overview_screen.dart';
import '../../features/expenses_budgets/presentation/screens/transaction_history_screen.dart';
import '../../features/income/presentation/screens/income_dashboard_screen.dart';
import '../../features/income/presentation/screens/record_additional_income_screen.dart';
import '../../features/income/presentation/screens/record_salary_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/add_asset_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/add_debt_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/add_obligation_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/assets_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/debt_detail_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/debts_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/liabilities_debts_overview_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/net_worth_screen.dart';
import '../../features/liabilities_debts_assets/presentation/screens/obligations_screen.dart';
import '../../features/savings_goals/presentation/screens/add_goal_screen.dart';
import '../../features/savings_goals/presentation/screens/emergency_fund_screen.dart';
import '../../features/savings_goals/presentation/screens/goal_detail_screen.dart';
import '../../features/savings_goals/presentation/screens/goals_list_screen.dart';
import '../../features/savings_goals/presentation/screens/savings_screen.dart';
import '../../features/security_backup/presentation/screens/app_lock_screen.dart';
import '../../features/security_backup/presentation/screens/backup_management_screen.dart';
import '../../features/security_backup/presentation/screens/settings_screen.dart';
import '../../features/treasury/presentation/screens/closed_months_history_screen.dart';
import '../../features/treasury/presentation/screens/month_end_closing_screen.dart';
import '../../features/treasury/presentation/screens/treasury_screen.dart';
import 'app_routes.dart';

/// مزود نظام التوجيه والتنقل (Router Provider)
final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: AppRoutes.dashboard,
    routes: [
      GoRoute(
        path: AppRoutes.dashboard,
        name: 'dashboard',
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: AppRoutes.treasury,
        name: 'treasury',
        builder: (context, state) => const TreasuryScreen(),
      ),
      GoRoute(
        path: AppRoutes.monthEndClosing,
        name: 'monthEndClosing',
        builder: (context, state) {
          final now = DateTime.now();
          final ym = '${now.year}-${now.month.toString().padLeft(2, '0')}';
          return MonthEndClosingScreen(periodYearMonth: ym);
        },
      ),
      GoRoute(
        path: AppRoutes.closedMonthsHistory,
        name: 'closedMonthsHistory',
        builder: (context, state) => const ClosedMonthsHistoryScreen(),
      ),
      GoRoute(
        path: AppRoutes.income,
        name: 'income',
        builder: (context, state) => const IncomeDashboardScreen(),
      ),
      GoRoute(
        path: AppRoutes.recordSalary,
        name: 'recordSalary',
        builder: (context, state) => const RecordSalaryScreen(),
      ),
      GoRoute(
        path: AppRoutes.recordAdditionalIncome,
        name: 'recordAdditionalIncome',
        builder: (context, state) => const RecordAdditionalIncomeScreen(),
      ),
      GoRoute(
        path: AppRoutes.expenses,
        name: 'expenses',
        builder: (context, state) => const TransactionHistoryScreen(),
      ),
      GoRoute(
        path: AppRoutes.addExpense,
        name: 'addExpense',
        builder: (context, state) => const AddExpenseScreen(),
      ),
      GoRoute(
        path: AppRoutes.budgets,
        name: 'budgets',
        builder: (context, state) => const BudgetsOverviewScreen(),
      ),
      GoRoute(
        path: AppRoutes.savings,
        name: 'savings',
        builder: (context, state) => const SavingsScreen(),
      ),
      GoRoute(
        path: AppRoutes.emergencyFund,
        name: 'emergencyFund',
        builder: (context, state) => const EmergencyFundScreen(),
      ),
      GoRoute(
        path: AppRoutes.goals,
        name: 'goals',
        builder: (context, state) => const GoalsListScreen(),
      ),
      GoRoute(
        path: AppRoutes.addGoal,
        name: 'addGoal',
        builder: (context, state) => const AddGoalScreen(),
      ),
      GoRoute(
        path: AppRoutes.goalDetail,
        name: 'goalDetail',
        builder: (context, state) {
          final goalId = state.extra as String? ?? '';
          return GoalDetailScreen(goalId: goalId);
        },
      ),
      GoRoute(
        path: AppRoutes.obligations,
        name: 'obligations',
        builder: (context, state) => const ObligationsScreen(),
      ),
      GoRoute(
        path: AppRoutes.addObligation,
        name: 'addObligation',
        builder: (context, state) => const AddObligationScreen(),
      ),
      GoRoute(
        path: AppRoutes.debts,
        name: 'debts',
        builder: (context, state) => const DebtsScreen(),
      ),
      GoRoute(
        path: AppRoutes.addDebt,
        name: 'addDebt',
        builder: (context, state) => const AddDebtScreen(),
      ),
      GoRoute(
        path: AppRoutes.debtDetail,
        name: 'debtDetail',
        builder: (context, state) {
          final debtId = state.extra as String? ?? '';
          return DebtDetailScreen(debtId: debtId);
        },
      ),
      GoRoute(
        path: AppRoutes.assets,
        name: 'assets',
        builder: (context, state) => const AssetsScreen(),
      ),
      GoRoute(
        path: AppRoutes.addAsset,
        name: 'addAsset',
        builder: (context, state) => const AddAssetScreen(),
      ),
      GoRoute(
        path: AppRoutes.netWorth,
        name: 'netWorth',
        builder: (context, state) => const NetWorthScreen(),
      ),
      GoRoute(
        path: AppRoutes.liabilitiesOverview,
        name: 'liabilitiesOverview',
        builder: (context, state) => const LiabilitiesDebtsOverviewScreen(),
      ),
      GoRoute(
        path: AppRoutes.analytics,
        name: 'analytics',
        builder: (context, state) => const AnalyticsDashboardScreen(),
      ),
      GoRoute(
        path: AppRoutes.financialCalendar,
        name: 'financialCalendar',
        builder: (context, state) => const FinancialCalendarScreen(),
      ),
      GoRoute(
        path: AppRoutes.forecasts,
        name: 'forecasts',
        builder: (context, state) => const ForecastsScreen(),
      ),
      GoRoute(
        path: AppRoutes.monthlyReportDetail,
        name: 'monthlyReportDetail',
        builder: (context, state) => const MonthlyReportDetailScreen(),
      ),
      GoRoute(
        path: AppRoutes.settings,
        name: 'settings',
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: AppRoutes.appLock,
        name: 'appLock',
        builder: (context, state) => const AppLockScreen(),
      ),
      GoRoute(
        path: AppRoutes.backupManagement,
        name: 'backupManagement',
        builder: (context, state) => const BackupManagementScreen(),
      ),
    ],
  );
});
