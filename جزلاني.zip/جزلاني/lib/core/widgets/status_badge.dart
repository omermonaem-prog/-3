import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_typography.dart';

/// شارة حالة مالية (Status Badge)
class StatusBadge extends StatelessWidget {
  final String text;
  final Color? color;
  final Color? textColor;

  const StatusBadge({
    super.key,
    required this.text,
    this.color,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final bg = color ?? AppColors.surfaceSubtleLight;
    final fg = textColor ?? AppColors.forestGreen;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: fg.withValues(alpha: 0.2), width: 0.8),
      ),
      child: Text(
        text,
        style: AppTypography.bodySecondary.copyWith(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: fg,
        ),
      ),
    );
  }
}

