import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// فتح اتصال محلي آمن مع ملف قاعدة بيانات SQLite
LazyDatabase openDatabaseConnection({bool inMemory = false}) {
  return LazyDatabase(() async {
    if (inMemory) {
      return NativeDatabase.memory();
    }
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'myfinance_local.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}

