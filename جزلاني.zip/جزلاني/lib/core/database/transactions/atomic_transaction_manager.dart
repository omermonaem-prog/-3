import 'package:drift/drift.dart';
import '../app_database.dart';

/// مدير المعاملات المالية الذرية (Atomic Financial Transaction Manager)
/// يضمن تنفيذ العمليات المركبة كوحدة واحدة لا تتجزأ مع التراجع التلقائي (Rollback) عند حدوث أي خطأ
class AtomicTransactionManager {
  final AppDatabase _db;

  AtomicTransactionManager(this._db);

  /// تنفيذ كتلة عمليات داخل معاملة ذرية واحدة
  Future<T> runAtomic<T>(Future<T> Function() action) async {
    return await _db.transaction(() async {
      try {
        return await action();
      } catch (e) {
        // يتم التراجع التلقائي (Rollback) بواسطة Drift عند رمي الاستثناء
        rethrow;
      }
    });
  }
}

