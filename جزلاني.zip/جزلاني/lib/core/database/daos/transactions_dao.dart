import 'package:drift/drift.dart';
import '../app_database.dart';

part 'transactions_dao.g.dart';

/// DAO المعاملات المالية — عمليات الحفظ والقراءة والأرشفة
@DriftAccessor(tables: [Transactions])
class TransactionsDao extends DatabaseAccessor<AppDatabase>
    with _$TransactionsDaoMixin {
  TransactionsDao(super.db);

  // ── قراءة ────────────────────────────────

  /// تدفق المعاملات النشطة (غير المحذوفة) لحساب معيّن
  Stream<List<TransactionEntry>> watchAccountTransactions(String accountId) =>
      (select(transactions)
            ..where((t) =>
                t.accountId.equals(accountId) & t.isDeleted.equals(false))
            ..orderBy([(t) => OrderingTerm.desc(t.transactionDate)]))
          .watch();

  /// المعاملات لفترة شهرية محددة (لاستعراض كشف الحساب الشهري)
  Future<List<TransactionEntry>> getTransactionsByMonth(
    String yearMonth, // '2026-10'
  ) async {
    final parts = yearMonth.split('-');
    final year = int.parse(parts[0]);
    final month = int.parse(parts[1]);
    final start = DateTime(year, month, 1);
    final end = DateTime(year, month + 1, 1);
    return (select(transactions)
          ..where((t) =>
              t.transactionDate.isBiggerOrEqualValue(start) &
              t.transactionDate.isSmallerThanValue(end) &
              t.isDeleted.equals(false))
          ..orderBy([(t) => OrderingTerm.desc(t.transactionDate)]))
        .get();
  }

  /// مجموع المصروفات لتصنيف معيّن في شهر محدد (بوحدة Minor Units)
  Future<int> getCategorySpentMinorUnits(
      String categoryId, String yearMonth) async {
    final parts = yearMonth.split('-');
    final year = int.parse(parts[0]);
    final month = int.parse(parts[1]);
    final start = DateTime(year, month, 1);
    final end = DateTime(year, month + 1, 1);

    final query = selectOnly(transactions)
      ..addColumns([transactions.amountMinorUnits.sum()])
      ..where(transactions.categoryId.equals(categoryId) &
          transactions.type.equals('expense') &
          transactions.isDeleted.equals(false) &
          transactions.transactionDate.isBiggerOrEqualValue(start) &
          transactions.transactionDate.isSmallerThanValue(end));
    final result = await query.getSingle();
    return result.read(transactions.amountMinorUnits.sum()) ?? 0;
  }

  // ── كتابة ────────────────────────────────

  Future<void> insertTransaction(TransactionsCompanion entry) =>
      into(transactions).insert(entry);

  /// الحذف الناعم للمعاملة (Soft Delete) — لا يُحذف الصف فعلياً أبداً
  Future<void> softDeleteTransaction(String id) =>
      (update(transactions)..where((t) => t.id.equals(id))).write(
        TransactionsCompanion(
          isDeleted: const Value(true),
          deletedAt: Value(DateTime.now()),
        ),
      );

  /// استعادة معاملة محذوفة ناعماً
  Future<void> restoreTransaction(String id) =>
      (update(transactions)..where((t) => t.id.equals(id))).write(
        const TransactionsCompanion(
          isDeleted: Value(false),
          deletedAt: Value(null),
        ),
      );

  /// المعاملات المحذوفة ناعماً القابلة للاستعادة (خلال 30 يوماً)
  Future<List<TransactionEntry>> getRestorableTransactions() {
    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    return (select(transactions)
          ..where((t) =>
              t.isDeleted.equals(true) &
              t.deletedAt.isBiggerOrEqualValue(cutoff)))
        .get();
  }
}

